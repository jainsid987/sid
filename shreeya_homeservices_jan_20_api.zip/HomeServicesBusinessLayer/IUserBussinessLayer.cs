﻿using HomeServicesEntities;
using System.Collections.Generic;


namespace HomeServicesBusinessLayer
{
    public interface IUserBussinessLayer
    {
        int CreatePost(TbServiceProvider serviceProvider);
        int AddUserDetail(TbUsers users);
        TbUsers LogIn(TbUsers users);
        int ResetPassword(int id, ResetPasswordCustomEntity resetPasswordCustomEntity);
        bool ValidatePassword(string newPassword, string confirmPassword);
        List<TbCustomCustomerHistory> CustomCustomerHistory(int userId);
        void Post(TbOrders tbOrders);
        void FindEmail(TbCustomCustomerDetail tbCustomCustomerDetail);
        bool NameValidation(string name);
        bool MobileValidator(string ContactNo);
        bool IsValidEmail(string _email);
        bool PasswordValidation(string password);
        string ComputeSha256Hash(string rawData);
        List<CustomManagePost> GetServiceProviders(int id);
        int UpdateProviderPost(int id, TbServiceProvider tbServiceProvider);
        int DeleteProviderPost(int id);
        int ValidateEmail(string email);
        bool UpdatePassword(ForgotPasswordCustomEntity forgotPasswordCustomEntity);
        int SendOTP(string email);
        bool ValidateOTP(ForgotPasswordCustomEntity forgotPasswordCustomEntity);


        List<TbCustomAvailServices> GetAvailableServices();
    }
}
