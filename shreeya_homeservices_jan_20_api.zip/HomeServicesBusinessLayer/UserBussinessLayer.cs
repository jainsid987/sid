﻿using HomeServicesDataAccessLayer;
using HomeServicesEntities;
using HomeServicesExceptions;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Security.Cryptography;
using System.Text;
using System.Net.Mail;
using System.Net;

namespace HomeServicesBusinessLayer
{
    public class UserBussinessLayer : IUserBussinessLayer
    {
        private readonly IUserDataAccessLayer _userDataAccessLayer;

        public UserBussinessLayer(IUserDataAccessLayer userDataAccessLayer)
        {
            _userDataAccessLayer = userDataAccessLayer;
        }

        static int otp = 0;
        static string EmailId = "";
        public int CreatePost(TbServiceProvider serviceProvider)
        {
            if (!(serviceProvider.Timings.ToLower().Trim().Equals("9am-12pm") || (serviceProvider.Timings.ToLower().Trim().Equals("12pm-6pm") || (serviceProvider.Timings.ToLower().Trim().Equals("6pm-9pm")))))
            {
                throw new TimingException("Please Enter only the available timings");
            }

            try
            { 
                return _userDataAccessLayer.CreatePost(serviceProvider);
            }
            catch(ServicePresentException ex)
            {
                throw new SomeErrorOccuredException("Service Already Present", ex);
            }
            catch (DataEntryException ex)
            {
                throw new SomeErrorOccuredException("Something Went Wrong Please Try Again Later", ex);
            }
        }
        public bool ValidatePassword(string newPassword, string confirmPassword)
        {
            bool flag1 = true;
            bool flag2 = true;
            bool flag3 = true;
            int count = 3; 
            if (newPassword != confirmPassword)
            {
                throw new InvalidUserPasswordException("Confirm and new Password is not same");
            }
            else if (newPassword.Length < 8 || newPassword.Length > 15)
            {
                throw new InvalidUserPasswordException("Length of password not be less than 8 and not greater than 15");
            }
            else
            {
                for (int i = 0; i < newPassword.Length; i++)
                {
                    if (newPassword[i] >= 48 && newPassword[i] <= 57 && flag1)
                    {
                        count--;
                        flag1 = false;
                    }
                    if (newPassword[i] >= 97 && newPassword[i] <= 122 && flag2)
                    {
                        count--;
                        flag2 = false;
                    }
                    if (newPassword[i] >= 65 && newPassword[i] <= 90 && flag3)
                    {
                        count--;
                        flag3 = false;
                    }
                }
                if (count == 0)
                {
                    return true;
                }
                else
                {
                    throw new InvalidUserPasswordException("Password Should contain one capital letter , one small letter and one digit");
                }
            }
        }

        public int AddUserDetail(TbUsers users)
        {
            if (_userDataAccessLayer.EmailValidation(users.Email))
            {
                return _userDataAccessLayer.AddUserDetail(users);
            }
            else
            {
                throw new InvalidUserCredentialsException("Invalid User Email");
            }
        }

        public TbUsers LogIn(TbUsers users)
        {
            
            try
            {
                string password=ComputeSha256Hash(users.UserPassword);
                users.UserPassword = password;
                TbUsers tbUsers = _userDataAccessLayer.GetUsersDetails(users);
                if (tbUsers.Email.ToLower().Equals(users.Email.ToLower()) && users.UserPassword.Equals(tbUsers.UserPassword))
                {
                    return tbUsers;
                }
                else
                {
                    throw new InvalidUserCredentialsException("Email Id or password is not correct");
                }
            }
            catch (InvalidUserCredentialsException ex)
            {
                throw new SomeErrorOccuredException("Invalid Email Id", ex);
            }
            catch (Exception ex)
            {
                throw new SomeErrorOccuredException("Invalid Email Id", ex);
            }
        }

        public int ResetPassword(int id, ResetPasswordCustomEntity resetPasswordCustomEntity)
        {
            resetPasswordCustomEntity.oldPassword =ComputeSha256Hash(resetPasswordCustomEntity.oldPassword);
            resetPasswordCustomEntity.newPassword = ComputeSha256Hash(resetPasswordCustomEntity.newPassword);
            resetPasswordCustomEntity.confirmPassword = ComputeSha256Hash(resetPasswordCustomEntity.confirmPassword);
            bool flag = _userDataAccessLayer.ValidatePassword(id, resetPasswordCustomEntity);
            if (flag)
            {
                int status = _userDataAccessLayer.ResetPassword(id, resetPasswordCustomEntity);
                return status;
            }
            else
            {
                throw new InvalidUserPasswordException("Old Pasword is Incorrect");
            }
        }

        public List<TbCustomCustomerHistory> CustomCustomerHistory(int userId)
        {


            List<TbCustomCustomerHistory> tbCustomCustomerHistory = _userDataAccessLayer.CustomCustomerHistory(userId);
            if (tbCustomCustomerHistory.Count == 0)
            {
                throw (new IdNotFoundException("Data Not Found"));
            }
            else
            {
                return tbCustomCustomerHistory;
            }


        }
        public bool MobileValidator(string ContactNo)
        {
            if(ContactNo[0]=='0')
            {
                throw new ContactNoNotValidException("Contact number is not valid");
            }
            string strRegex = @"(^[0-9]{10}$)|(^\+[0-9]{2}\s+[0-9] 
                {2}[0-9]{8}$)|(^[0-9]{3}-[0-9]{4}-[0-9]{4}$)";
            Regex re = new Regex(strRegex);
            if (re.IsMatch(ContactNo))
                return (true);
            else
                throw new ContactNoNotValidException("Contact number is not valid");
        }
        public bool IsValidEmail(string _email)
        {
            string strRegex = @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z";

            Regex re = new Regex(strRegex, RegexOptions.IgnoreCase);

            if (re.IsMatch(_email))
                return (true);
            else
                throw new InvalidUserCredentialsException("Email id is not in valid format");
        }
        public bool NameValidation(string name)
        {
            for (int i = 0; i < name.Length; i++)
            {
                if (!(name[i] >= 'A' && name[i] <= 'Z' || name[i] >= 'a' && name[i] <= 'z' || name[i].Equals(' ')))
                {
                    throw new NameNotValidException("Name is not correct");
                }
            }
            return true;

        }
        public bool PasswordValidation(string password)
        {
            int flag = 0;
            for (int i = 0; i < password.Length; i++)
            {
                if (password[i] >= 'A' && password[i] <= 'Z')
                {
                    flag = 1;
                    break;
                }
            }
            if (flag == 1)
            {
                flag = 0;
                for (int i = 0; i < password.Length; i++)
                {
                    if (password[i] >= 'a' && password[i] <= 'z')
                    {
                        flag = 1;
                        break;
                    }
                }
            }
            if (flag == 1)
            {
                flag = 0;
                for (int i = 0; i < password.Length; i++)
                {
                    if (password[i] > '0' && password[i] <= '9')
                    {
                        flag = 1;
                        break;
                    }
                }
            }
            if (flag == 1)
            {
                
                if (password.Length >= 8 && password.Length <= 15)
                {
                    return true;

                }
            }
            else
            {
                throw new InvalidUserPasswordException("Password should contain one capital,lower and one digit and should be between 8 to 15");
            }
            return true;

        }
        public string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));

                }
                return builder.ToString();
            }
        }

        public List<CustomManagePost> GetServiceProviders(int id)
        {
            return _userDataAccessLayer.GetServiceProviders(id);
        }

        public int UpdateProviderPost(int id, TbServiceProvider tbServiceProvider)
        {
            if (tbServiceProvider.Price <= 0 || tbServiceProvider.Price > 1000)
            {
                throw new PriceException("price should be greater than 0 and less than 1000");
            }
            else if(!(tbServiceProvider.Timings.ToLower().Trim().Equals("9am-12pm") || (tbServiceProvider.Timings.ToLower().Trim().Equals("12pm-6pm") || (tbServiceProvider.Timings.ToLower().Trim().Equals("6pm-9pm")))))
            {
                throw new TimingException("Please Enter only the available timings");
            }
            else
            {
                return _userDataAccessLayer.UpdateProviderPost(id, tbServiceProvider);
            }
           
        }

        public int DeleteProviderPost(int id)
        {
            return _userDataAccessLayer.DeleteProviderPost(id);
        }

        public List<TbCustomAvailServices> GetAvailableServices()
        {
            List<TbCustomAvailServices> tbCustomAvailServices;
            try
            { 
                tbCustomAvailServices = _userDataAccessLayer.GetAvailableServices();
                return tbCustomAvailServices;
            }
            catch(NoAvailableServicesException)
            {
                throw;
            }
           
        }
        public int ValidateEmail(string email)
        {
            if (_userDataAccessLayer.EmailValidation(email))
            {
                throw new InvalidUserCredentialsException("Invalid User Email");
            }
            else
            {
                return 1;
            }
        }
        public bool ValidateOTP(ForgotPasswordCustomEntity forgotPasswordCustomEntity)
        {
            if (forgotPasswordCustomEntity.OTP != otp || EmailId != forgotPasswordCustomEntity.email)
            {
                throw new InvalidOtpException("Invalid Credentials");
            }
            else
            {
                return true;
            }
        }

        public bool UpdatePassword(ForgotPasswordCustomEntity forgotPasswordCustomEntity)
        {
              bool flag = ValidatePassword(forgotPasswordCustomEntity.password, forgotPasswordCustomEntity.confirmPassword);
               if (flag)
                {
                    forgotPasswordCustomEntity.password = ComputeSha256Hash(forgotPasswordCustomEntity.password);
                }
            return _userDataAccessLayer.UpdatePassword(forgotPasswordCustomEntity);
        }
        public int SendOTP(string email)
        {
            try
            {
                IsValidEmail(email);
                Random random = new Random();
                int OTP = random.Next(1000, 9999);
                SmtpClient client = new SmtpClient("smtp.gmail.com", 587)
                {
                    EnableSsl = true,
                    Timeout = 10000,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential("servicesh598@gmail.com", "bestproject")
                };
                MailMessage msg = new MailMessage
                {
                    From = new MailAddress("servicesh598@gmail.com")
                };
                msg.To.Add(email);
                msg.Subject = "OTP for Reseting Password";
                msg.Body = "Hi!" + Environment.NewLine + Environment.NewLine +
                     "Use this OTP : " + OTP +
                     " for reseting your password" + Environment.NewLine +
                     "Disclaimer : This OTP is Confidential. For security reasons, DO NOT share the OTP with anyone." + Environment.NewLine + Environment.NewLine +
                     "Thanks And Regards," + Environment.NewLine + "Home Services";
                client.Send(msg);
                otp = OTP;
                EmailId = email;
                return OTP;
            }
            catch (Exception)
            {
                throw new SomeErrorOccuredException("Invalid Email Id");
            }
        }
    


        
        public void Post(TbOrders tbOrders)
        {
            _userDataAccessLayer.Post(tbOrders);
        }
        public void FindEmail(TbCustomCustomerDetail tbCustomCustomerDetail)
        {
          TbCustomEmail tbCustomEmail =  _userDataAccessLayer.FindEmail(tbCustomCustomerDetail);
            SendEmail(tbCustomEmail);
        }
        public void SendEmail(TbCustomEmail tbCustomEmail)
        {
            SmtpClient client = new SmtpClient("smtp.gmail.com", 587)
            {
                EnableSsl = true,
                Timeout = 10000,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential("servicesh598@gmail.com","bestproject")
            };
            MailMessage msg = new MailMessage
            {
                From = new MailAddress("servicesh598@gmail.com")
            };
            msg.To.Add(tbCustomEmail.ProviderEmail);
            msg.Subject = "Details of Customer";
            msg.Body = "Hi!" + Environment.NewLine +
                 "Name of the Customer:" + tbCustomEmail.CustomerName + " " + Environment.NewLine +
                 "Phone Number:" + tbCustomEmail.CustomerPhoneNumber + " " + Environment.NewLine +
                 "TimeOfService:" + tbCustomEmail.Time + " " + Environment.NewLine +
                 "City:" + tbCustomEmail.Location + " " + Environment.NewLine +
                 "Address:" + tbCustomEmail.Address + " " + Environment.NewLine +
                 "DateOfService:" + tbCustomEmail.DateOfService;
            client.Send(msg);
        }

       
    }
}