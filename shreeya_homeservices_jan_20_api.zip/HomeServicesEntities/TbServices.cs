﻿using System.Collections.Generic;

namespace HomeServicesEntities
{
    public partial class TbServices
    {
        public TbServices()
        {
            TbBridge = new HashSet<TbBridge>();
            TbOrders = new HashSet<TbOrders>();
            TbServiceProvider = new HashSet<TbServiceProvider>();
        }

        public int ServiceId { get; set; }
        public string ServiceName { get; set; }

        public ICollection<TbBridge> TbBridge { get; set; }
        public ICollection<TbOrders> TbOrders { get; set; }
        public ICollection<TbServiceProvider> TbServiceProvider { get; set; }
    }
}
