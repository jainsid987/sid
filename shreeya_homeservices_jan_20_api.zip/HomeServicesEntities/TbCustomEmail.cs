﻿using System;

namespace HomeServicesEntities
{
    public class TbCustomEmail
    {
        public string ProviderEmail { get; set; }
        public string CustomerName { get; set; }
        public string CustomerPhoneNumber { get; set; }
        public string Time { get; set; }
        public string Location { get; set; }
        public string Address { get; set; }
        public DateTime DateOfService { get; set; }
    }
}
