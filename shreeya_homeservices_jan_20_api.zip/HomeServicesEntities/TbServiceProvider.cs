﻿namespace HomeServicesEntities
{
    public partial class TbServiceProvider
    {

        public int Sno { get; set; }
        public int UserId { get; set; }
        public string Timings { get; set; }
        public int Price { get; set; }
        public int ServiceId { get; set; }
        public int LocationId { get; set; }
        public int Rating { get; set; }

        public TbLocation Location { get; set; }
        public TbServices Service { get; set; }
        public TbUsers User { get; set; }
    }
}
