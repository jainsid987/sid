﻿namespace HomeServicesEntities
{
    public partial class TbBridge
    {
        public int Sno { get; set; }
        public int LocationId { get; set; }
        public int ServiceId { get; set; }

        public TbLocation Location { get; set; }
        public TbServices Service { get; set; }
    }
}
