﻿namespace HomeServicesEntities
{
    public  class ResetPasswordCustomEntity
    {
        public int id { get; set; }
        public string oldPassword { get; set; }
        public string newPassword { get; set; }
        public string confirmPassword { get; set; }
    }
}
