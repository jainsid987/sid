﻿using System.Collections.Generic;

namespace HomeServicesEntities
{
    public partial class TbLocation
    {
        public TbLocation()
        {
            TbBridge = new HashSet<TbBridge>();
            TbServiceProvider = new HashSet<TbServiceProvider>();
        }

        public int LocationId { get; set; }
        public string LocationName { get; set; }

        public ICollection<TbBridge> TbBridge { get; set; }
        public ICollection<TbServiceProvider> TbServiceProvider { get; set; }
    }
}
