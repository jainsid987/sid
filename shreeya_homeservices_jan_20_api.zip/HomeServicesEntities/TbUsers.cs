﻿using System.Collections.Generic;

namespace HomeServicesEntities
{
    public partial class TbUsers
    {
        public TbUsers()
        {
            TbOrdersConsumer = new HashSet<TbOrders>();
            TbOrdersProvider = new HashSet<TbOrders>();
            TbServiceProvider = new HashSet<TbServiceProvider>();
        }

        public int UserId { get; set; }
        public string UserPassword { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string ContactNo { get; set; }

        public ICollection<TbOrders> TbOrdersConsumer { get; set; }
        public ICollection<TbOrders> TbOrdersProvider { get; set; }
        public ICollection<TbServiceProvider> TbServiceProvider { get; set; }
    }
}
