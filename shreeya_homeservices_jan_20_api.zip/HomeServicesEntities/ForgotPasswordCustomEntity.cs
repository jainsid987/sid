﻿namespace HomeServicesEntities
{
    public class ForgotPasswordCustomEntity
    {

        public int OTP { get; set; }
        public string email { get; set; }
        public string password { get; set; }

        public string confirmPassword { get; set; }
    }
}
