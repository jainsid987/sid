﻿using System;

namespace HomeServicesEntities
{
    public partial class TbOrders
    {
        public int OrderId { get; set; }
        public int ProviderId { get; set; }
        public int ConsumerId { get; set; }
        public int ServiceId { get; set; }
        public DateTime DateOfService { get; set; }
        public string Timings { get; set; }

        public TbUsers Consumer { get; set; }
        public TbUsers Provider { get; set; }
        public TbServices Service { get; set; }
    }
}
