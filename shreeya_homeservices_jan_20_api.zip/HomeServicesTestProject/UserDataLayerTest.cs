﻿using HomeServicesDataAccessLayer;
using HomeServicesEntities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;


using Microsoft.EntityFrameworkCore;
using Moq;
using HomeServicesExceptions;

namespace HomeServicesTestProject
{
    [TestClass]
    public class UserDataLayerTest
    {
        [TestMethod]
        public void GetUsersDetailsTest_Happy()
        {
            TbUsers tbUser = new TbUsers();
            tbUser.Email = "manishasharma13@gmail.com";
            tbUser.UserPassword = "Mani@123";
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId = 1,
                    UserPassword = "asbx@123",
                    Name = "Manisha",
                     Email = "abcd@gmail.com",
                    ContactNo = "1234567890"
                },
                 new TbUsers
                {
                    UserId = 2,
                    UserPassword = "asdgx@123",
                    Name = "sharan",
                     Email = "sharan@gmail.com",
                    ContactNo = "0987567890"
                },
                 new TbUsers
                 {
                    UserId = 3 ,
                    UserPassword = "Mani@123",
                    Name = "Mani",
                     Email = "manishasharma13@gmail.com",
                    ContactNo = "0987577890"
                 }
            }.AsQueryable();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers).Returns(mocTbUsers.Object);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            var result = dataObj.GetUsersDetails(tbUser);

            Assert.IsInstanceOfType(result, typeof(TbUsers));

        }

        [TestMethod]
        public void GetUsersDetailsTest_Sad()
        {
            TbUsers tbUser = new TbUsers();
            tbUser.Email = "manishajajra13@gmail.com";
            tbUser.UserPassword = "Mani@123";
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId = 1,
                    UserPassword = "asbx@123",
                    Name = "Manisha",
                     Email = "abcd@gmail.com",
                    ContactNo = "1234567890"
                },
                 new TbUsers
                {
                    UserId = 2,
                    UserPassword = "asdgx@123",
                    Name = "sharan",
                     Email = "sharan@gmail.com",
                    ContactNo = "0987567890"
                },
                 new TbUsers
                 {
                    UserId = 3 ,
                    UserPassword = "Mani@123",
                    Name = "Mani",
                     Email = "manishasharma13@gmail.com",
                    ContactNo = "0987577890"
                 }
            }.AsQueryable();
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers).Returns(mocTbUsers.Object);
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            Assert.ThrowsException<SomeErrorOccuredException>(() => dataObj.GetUsersDetails(tbUser));

        }

        [TestMethod]
        public void GetUsersDetailsTest_Bad()
        {
            TbUsers tbUser = new TbUsers();
            tbUser.Email = "manishajajra13@gmail.com";
            tbUser.UserPassword = "Mani@123";
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId = 1,
                    UserPassword = "asbx@123",
                    Name = "Manisha",
                     Email = "abcd@gmail.com",
                    ContactNo = "1234567890"
                },
                 new TbUsers
                {
                    UserId = 2,
                    UserPassword = "asdgx@123",
                    Name = "sharan",
                     Email = "sharan@gmail.com",
                    ContactNo = "0987567890"
                },
                 new TbUsers
                 {
                    UserId = 3 ,
                    UserPassword = "Mani@123",
                    Name = "Mani",
                     Email = "manishasharma13@gmail.com",
                    ContactNo = "0987577890"
                 }
            }.AsQueryable();
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers).Throws(new Exception());
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            Assert.ThrowsException<SomeErrorOccuredException>(() => dataObj.GetUsersDetails(tbUser));
        }


        [TestMethod]
        public void DAL_CreatePost_Happy()
        {
            TbServiceProvider tbServiceProvider = new TbServiceProvider();

            var dbContext = new Mock<Orchard2Context>();
            var mockTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();

            var tbServiceProviders = new List<TbServiceProvider>()
            {
                new TbServiceProvider
                {
                    UserId = 239,
                    Timings = "9am-12pm",
                    Price = 123,
                    ServiceId = 1,
                    LocationId = 1,
                    Rating = 3
                },
                 new TbServiceProvider
                {
                    UserId = 246,
                    Timings = "9am-12pm",
                    Price = 123,
                    ServiceId = 1,
                    LocationId = 1,
                    Rating = 3
                },
                 new TbServiceProvider
                {
                    UserId = 246,
                    Timings = "9am-12pm",
                    Price = 123,
                    ServiceId = 2,
                    LocationId = 2,
                    Rating = 3
                },

            }.AsQueryable();


            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbContext.Setup(db => db.TbServiceProvider).Returns(mockTbServiceProvider.Object);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbContext.Object);

            tbServiceProvider.UserId = 246;
            tbServiceProvider.Timings = "9am-12pm";
            tbServiceProvider.Price = 123;
            tbServiceProvider.ServiceId = 1;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Rating = 3;

            var result = dataObj.CreatePost(tbServiceProvider);

            Assert.IsInstanceOfType(result, typeof(int));
        }


        [TestMethod]
        public void DAL_CreatePost_Sad()
        {
            TbServiceProvider tbServiceProvider = new TbServiceProvider();

            var dbContext = new Mock<Orchard2Context>();
            var mockTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();

            var tbServiceProviders = new List<TbServiceProvider>()
            {
                new TbServiceProvider
                {
                    UserId = 239,
                    Timings = "9am-12pm",
                    Price = 123,
                    ServiceId = 1,
                    LocationId = 1,
                    Rating = 3
                },
                 new TbServiceProvider
                {
                    UserId = 246,
                    Timings = "9am-12pm",
                    Price = 123,
                    ServiceId = 1,
                    LocationId = 1,
                    Rating = 3
                },
                 new TbServiceProvider
                {
                    UserId = 246,
                    Timings = "9am-12pm",
                    Price = 123,
                    ServiceId = 2,
                    LocationId = 2,
                    Rating = 3
                },

            }.AsQueryable();


            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbContext.Setup(db => db.TbServiceProvider).Returns(mockTbServiceProvider.Object);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbContext.Object);

            tbServiceProvider.UserId = 246;
            tbServiceProvider.Timings = "9am-12pm";
            tbServiceProvider.Price = 123;
            tbServiceProvider.ServiceId = 2;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Rating = 3;

            Assert.ThrowsException<ServicePresentException>(() => dataObj.CreatePost(tbServiceProvider));

        }


        [TestMethod]
        public void DAL_CreatePost_Bad()
        {

            TbServiceProvider tbServiceProvider = new TbServiceProvider();

            var dbContext = new Mock<Orchard2Context>();
            var mockTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();

            var tbServiceProviders = new List<TbServiceProvider>()
            {
                new TbServiceProvider
                {
                    UserId = 239,
                    Timings = "9am-12pm",
                    Price = 123,
                    ServiceId = 1,
                    LocationId = 1,
                    Rating = 3
                },
                 new TbServiceProvider
                {
                    UserId = 246,
                    Timings = "9am-12pm",
                    Price = 123,
                    ServiceId = 1,
                    LocationId = 1,
                    Rating = 3
                },
                 new TbServiceProvider
                {
                    UserId = 246,
                    Timings = "9am-12pm",
                    Price = 123,
                    ServiceId = 2,
                    LocationId = 2,
                    Rating = 3
                },

            }.AsQueryable();


            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mockTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbContext.Setup(db => db.TbServiceProvider).Returns(mockTbServiceProvider.Object);


            dbContext.Setup(db => db.TbServiceProvider).Throws(new Exception());



            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbContext.Object);

            tbServiceProvider.UserId = 246;
            tbServiceProvider.Timings = "9am-12pm";
            tbServiceProvider.Price = 123;
            tbServiceProvider.ServiceId = 2;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Rating = 3;

            Assert.ThrowsException<Exception>(() => dataObj.CreatePost(tbServiceProvider));

        }

        [TestMethod]
        public void Happy_AddUsersDetailTest()
        {
            TbUsers user = new TbUsers();
            user.Name = "SATYAM";
            user.ContactNo = "9876543210";
            user.Email = "abuey@gmail.com";
            user.UserPassword = "ASQ11111";
            var context = new Mock<Orchard2Context>();
            context.Setup(r => r.TbUsers.Add(user));
            context.Setup(r => r.SaveChanges()).Returns(1);
            int expected = 1;
            UserDataAccessLayer userDataAccess = new UserDataAccessLayer(context.Object);
            int actual = userDataAccess.AddUserDetail(user);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void Sad_AddUsersDetail()
        {
            TbUsers user = new TbUsers();
            user.Name = "SATYAM";
            user.ContactNo = "9876543210";
            user.Email = "abuey@gmail.com";
            user.UserPassword = "ASQ11111";
            var context = new Mock<Orchard2Context>();
            context.Setup(r => r.TbUsers.Add(user));
            context.Setup(r => r.SaveChanges()).Returns(0);
            int expected = 0;
            UserDataAccessLayer userDataAccess = new UserDataAccessLayer(context.Object);
            int actual = userDataAccess.AddUserDetail(user);
            Assert.AreEqual(expected, actual);

        }
        [TestMethod]
        public void Bad_AddUsersDetail()
        {
            TbUsers user = new TbUsers();
            user.Name = "SATYAM";
            user.ContactNo = "9876543210";
            user.Email = "abuey@gmail.com";
            user.UserPassword = "ASQ11111";
            var context = new Mock<Orchard2Context>();
            context.Setup(r => r.TbUsers.Add(user)).Throws(new Exception());
            context.Setup(r => r.SaveChanges()).Returns(0);

            UserDataAccessLayer userDataAccess = new UserDataAccessLayer(context.Object);

            Assert.ThrowsException<Exception>(() => userDataAccess.AddUserDetail(user));

        }


        [TestMethod]
        public void DAL_AvailService_Happy()
        {
            TbCustomAvailServices tbCustomAvailServices = new TbCustomAvailServices();
            var dbContext = new Mock<Orchard2Context>();


        }

        [TestMethod]
        public void HappyCustomCustomerHistory()
        {

            var data = new List<TbOrders>() { new TbOrders { OrderId = 1, ProviderId = 146, ConsumerId = 145, ServiceId = 3, Timings = "5" } }.AsQueryable();

            var data1 = new List<TbServices> { new TbServices { ServiceId = 3, ServiceName = "Plumber" } }.AsQueryable();
            var data2 = new List<TbServiceProvider> { new TbServiceProvider { Sno = 1, UserId = 146, Timings = "5", Price = 250, ServiceId = 3, LocationId = 3, Rating = 5 } }.AsQueryable();
            var data3 = new List<TbUsers> { new TbUsers { UserId = 145, Name = "Snehal" }, new TbUsers { UserId = 146, Name = "Siddhant" } }.AsQueryable();
            var tborder = new Mock<DbSet<TbOrders>>();
            var tbservices = new Mock<DbSet<TbServices>>();
            var tbserviceprovider = new Mock<DbSet<TbServiceProvider>>();
            var tbusers = new Mock<DbSet<TbUsers>>();

            tborder.As<IQueryable<TbOrders>>().Setup(m => m.Provider).Returns(data.Provider);
            tborder.As<IQueryable<TbOrders>>().Setup(m => m.Expression).Returns(data.Expression);
            tborder.As<IQueryable<TbOrders>>().Setup(m => m.ElementType).Returns(data.ElementType);
            tborder.As<IQueryable<TbOrders>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            tbservices.As<IQueryable<TbServices>>().Setup(m => m.Provider).Returns(data1.Provider);
            tbservices.As<IQueryable<TbServices>>().Setup(m => m.Expression).Returns(data1.Expression);
            tbservices.As<IQueryable<TbServices>>().Setup(m => m.ElementType).Returns(data1.ElementType);
            tbservices.As<IQueryable<TbServices>>().Setup(m => m.GetEnumerator()).Returns(data1.GetEnumerator());

            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.Provider).Returns(data2.Provider);
            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.Expression).Returns(data2.Expression);
            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.ElementType).Returns(data2.ElementType);
            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.GetEnumerator()).Returns(data2.GetEnumerator());

            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.Provider).Returns(data3.Provider);
            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.Expression).Returns(data3.Expression);
            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.ElementType).Returns(data3.ElementType);
            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.GetEnumerator()).Returns(data3.GetEnumerator());
            var context = new Mock<Orchard2Context>();
            context.Setup(r => r.TbOrders).Returns(tborder.Object);
            context.Setup(r => r.TbServices).Returns(tbservices.Object);
            context.Setup(r => r.TbServiceProvider).Returns(tbserviceprovider.Object);
            context.Setup(r => r.TbUsers).Returns(tbusers.Object);

            var dal = new UserDataAccessLayer(context.Object);
            List<TbCustomCustomerHistory> tbCustomCustomerHistory = dal.CustomCustomerHistory(145);
            int expected = 1;
            Assert.AreEqual(expected, tbCustomCustomerHistory.Count);

        }
        [TestMethod]
        public void BadCustomCustomerHistory()
        {

            var data = new List<TbOrders>() { new TbOrders { OrderId = 1, ProviderId = 146, ConsumerId = 145, ServiceId = 3, Timings = "5" } }.AsQueryable();
            var data1 = new List<TbServices> { new TbServices { ServiceId = 3, ServiceName = "Plumber" } }.AsQueryable();
            var data2 = new List<TbServiceProvider> { new TbServiceProvider { Sno = 1, UserId = 146, Timings = "5", Price = 250, ServiceId = 3, LocationId = 3, Rating = 5 } }.AsQueryable();
            var data3 = new List<TbUsers> { new TbUsers { UserId = 145, Name = "Snehal" }, new TbUsers { UserId = 146, Name = "Siddhant" } }.AsQueryable();
            var tborder = new Mock<DbSet<TbOrders>>();
            var tbservices = new Mock<DbSet<TbServices>>();
            var tbserviceprovider = new Mock<DbSet<TbServiceProvider>>();
            var tbusers = new Mock<DbSet<TbUsers>>();

            tborder.As<IQueryable<TbOrders>>().Setup(m => m.Provider).Returns(data.Provider);
            tborder.As<IQueryable<TbOrders>>().Setup(m => m.Expression).Returns(data.Expression);
            tborder.As<IQueryable<TbOrders>>().Setup(m => m.ElementType).Returns(data.ElementType);
            tborder.As<IQueryable<TbOrders>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            tbservices.As<IQueryable<TbServices>>().Setup(m => m.Provider).Returns(data1.Provider);
            tbservices.As<IQueryable<TbServices>>().Setup(m => m.Expression).Returns(data1.Expression);
            tbservices.As<IQueryable<TbServices>>().Setup(m => m.ElementType).Returns(data1.ElementType);
            tbservices.As<IQueryable<TbServices>>().Setup(m => m.GetEnumerator()).Returns(data1.GetEnumerator());

            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.Provider).Returns(data2.Provider);
            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.Expression).Returns(data2.Expression);
            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.ElementType).Returns(data2.ElementType);
            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.GetEnumerator()).Returns(data2.GetEnumerator());

            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.Provider).Returns(data3.Provider);
            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.Expression).Returns(data3.Expression);
            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.ElementType).Returns(data3.ElementType);
            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.GetEnumerator()).Returns(data3.GetEnumerator());
            var context = new Mock<Orchard2Context>();
            context.Setup(r => r.TbOrders).Throws(new Exception());
            context.Setup(r => r.TbServices).Throws(new Exception());
            context.Setup(r => r.TbServiceProvider).Throws(new Exception());
            context.Setup(r => r.TbUsers).Throws(new Exception());

            var dal = new UserDataAccessLayer(context.Object);
            // var result = dal.CustomCustomerHistory(145);
            //List<TbCustomCustomerHistory> tbCustomCustomerHistory = dal.CustomCustomerHistory(2);
            Assert.ThrowsException<Exception>(() => dal.CustomCustomerHistory(145));
        }
        [TestMethod]
        public void SadCustomCustomerHistory()
        {

            var data = new List<TbOrders>() { new TbOrders { OrderId = 1, ProviderId = 146, ConsumerId = 145, ServiceId = 3, Timings = "5" } }.AsQueryable();

            var data1 = new List<TbServices> { new TbServices { ServiceId = 3, ServiceName = "Plumber" } }.AsQueryable();
            var data2 = new List<TbServiceProvider> { new TbServiceProvider { Sno = 1, UserId = 146, Timings = "5", Price = 250, ServiceId = 3, LocationId = 3, Rating = 5 } }.AsQueryable();
            var data3 = new List<TbUsers> { new TbUsers { UserId = 145, Name = "Snehal" }, new TbUsers { UserId = 146, Name = "Siddhant" } }.AsQueryable();
            var tborder = new Mock<DbSet<TbOrders>>();
            var tbservices = new Mock<DbSet<TbServices>>();
            var tbserviceprovider = new Mock<DbSet<TbServiceProvider>>();
            var tbusers = new Mock<DbSet<TbUsers>>();

            tborder.As<IQueryable<TbOrders>>().Setup(m => m.Provider).Returns(data.Provider);
            tborder.As<IQueryable<TbOrders>>().Setup(m => m.Expression).Returns(data.Expression);
            tborder.As<IQueryable<TbOrders>>().Setup(m => m.ElementType).Returns(data.ElementType);
            tborder.As<IQueryable<TbOrders>>().Setup(m => m.GetEnumerator()).Returns(data.GetEnumerator());

            tbservices.As<IQueryable<TbServices>>().Setup(m => m.Provider).Returns(data1.Provider);
            tbservices.As<IQueryable<TbServices>>().Setup(m => m.Expression).Returns(data1.Expression);
            tbservices.As<IQueryable<TbServices>>().Setup(m => m.ElementType).Returns(data1.ElementType);
            tbservices.As<IQueryable<TbServices>>().Setup(m => m.GetEnumerator()).Returns(data1.GetEnumerator());

            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.Provider).Returns(data2.Provider);
            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.Expression).Returns(data2.Expression);
            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.ElementType).Returns(data2.ElementType);
            tbserviceprovider.As<IQueryable<TbServiceProvider>>().Setup(m => m.GetEnumerator()).Returns(data2.GetEnumerator());

            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.Provider).Returns(data3.Provider);
            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.Expression).Returns(data3.Expression);
            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.ElementType).Returns(data3.ElementType);
            tbusers.As<IQueryable<TbUsers>>().Setup(m => m.GetEnumerator()).Returns(data3.GetEnumerator());
            var context = new Mock<Orchard2Context>();
            context.Setup(r => r.TbOrders).Returns(tborder.Object);
            context.Setup(r => r.TbServices).Returns(tbservices.Object);
            context.Setup(r => r.TbServiceProvider).Returns(tbserviceprovider.Object);
            context.Setup(r => r.TbUsers).Returns(tbusers.Object);

            var dal = new UserDataAccessLayer(context.Object);
            List<TbCustomCustomerHistory> tbCustomCustomerHistory = dal.CustomCustomerHistory(2);
            int expected = 0;
            Assert.AreEqual(expected, tbCustomCustomerHistory.Count);

        }

        [TestMethod]
        public void GetServiceProvidersTest_Happy()
        {
            int id = 132;
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();
            var mocTbLocation = new Mock<DbSet<TbLocation>>();
            var mocTbServices = new Mock<DbSet<TbServices>>();
            var tbServiceProviders = new List<TbServiceProvider>
            {
                new TbServiceProvider
                {
                    Sno=1,
                    UserId=132,
                    Timings="9am-12pm",
                    Price=500,
                    ServiceId=1,
                    LocationId=1,
                    Rating = 4
                },
                new TbServiceProvider
                {
                    Sno=2,
                    UserId=133,
                    Timings="12pm-6pm",
                    Price=600,
                    ServiceId=2,
                    LocationId=2,
                    Rating = 5
                },
                new TbServiceProvider
                {
                    Sno=3,
                    UserId=134,
                    Timings="6pm-9pm",
                    Price=800,
                    ServiceId=3,
                    LocationId=3,
                    Rating = 4
                }
            }.AsQueryable();

            var TbServices = new List<TbServices>
            {
                new TbServices
                {
                    ServiceId=1,
                    ServiceName="furniture"
                },
                new TbServices
                {
                    ServiceId=2,
                    ServiceName="GasService"
                },
                new TbServices
                {
                   ServiceId=3,
                    ServiceName="Stove"
                }
            }.AsQueryable();

            var tbLocations = new List<TbLocation>
            {
                new TbLocation
                {
                    LocationId=1,
                    LocationName="Bhubaneshawar"
                },
                new TbLocation
                {
                    LocationId=2,
                    LocationName="Bengaluru"
                },
                new TbLocation
                {
                   LocationId=3,
                    LocationName="Hyderabad"
                }
            }.AsQueryable();

            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbcontext.Setup(db => db.TbServiceProvider).Returns(mocTbServiceProvider.Object);


            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.Provider).Returns(TbServices.Provider);
            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.ElementType).Returns(TbServices.ElementType);
            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.Expression).Returns(TbServices.Expression);
            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.GetEnumerator()).Returns(TbServices.GetEnumerator());
            dbcontext.Setup(db => db.TbServices).Returns(mocTbServices.Object);

            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.Provider).Returns(tbLocations.Provider);
            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.ElementType).Returns(tbLocations.ElementType);
            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.Expression).Returns(tbLocations.Expression);
            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.GetEnumerator()).Returns(tbLocations.GetEnumerator());
            dbcontext.Setup(db => db.TbLocation).Returns(mocTbLocation.Object);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            var result = dataObj.GetServiceProviders(id);
            Assert.IsInstanceOfType(result, typeof(List<CustomManagePost>));
        }

        [TestMethod]
        public void GetServiceProvidersTest_Sad()
        {
            int id = 139;
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();
            var mocTbLocation = new Mock<DbSet<TbLocation>>();
            var mocTbServices = new Mock<DbSet<TbServices>>();
            var tbServiceProviders = new List<TbServiceProvider>
            {
                new TbServiceProvider
                {
                    Sno=1,
                    UserId=132,
                    Timings="9am-12pm",
                    Price=500,
                    ServiceId=1,
                    LocationId=1,
                    Rating = 4
                },
                new TbServiceProvider
                {
                    Sno=2,
                    UserId=133,
                    Timings="12pm-6pm",
                    Price=600,
                    ServiceId=2,
                    LocationId=2,
                    Rating = 5
                },
                new TbServiceProvider
                {
                    Sno=3,
                    UserId=134,
                    Timings="6pm-9pm",
                    Price=800,
                    ServiceId=3,
                    LocationId=3,
                    Rating = 4
                }
            }.AsQueryable();

            var TbServices = new List<TbServices>
            {
                new TbServices
                {
                    ServiceId=1,
                    ServiceName="furniture"
                },
                new TbServices
                {
                    ServiceId=2,
                    ServiceName="GasService"
                },
                new TbServices
                {
                   ServiceId=3,
                    ServiceName="Stove"
                }
            }.AsQueryable();

            var tbLocations = new List<TbLocation>
            {
                new TbLocation
                {
                    LocationId=1,
                    LocationName="Bhubaneshawar"
                },
                new TbLocation
                {
                    LocationId=2,
                    LocationName="Bengaluru"
                },
                new TbLocation
                {
                   LocationId=3,
                    LocationName="Hyderabad"
                }
            }.AsQueryable();

            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbcontext.Setup(db => db.TbServiceProvider).Returns(mocTbServiceProvider.Object);


            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.Provider).Returns(TbServices.Provider);
            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.ElementType).Returns(TbServices.ElementType);
            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.Expression).Returns(TbServices.Expression);
            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.GetEnumerator()).Returns(TbServices.GetEnumerator());
            dbcontext.Setup(db => db.TbServices).Returns(mocTbServices.Object);

            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.Provider).Returns(tbLocations.Provider);
            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.ElementType).Returns(tbLocations.ElementType);
            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.Expression).Returns(tbLocations.Expression);
            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.GetEnumerator()).Returns(tbLocations.GetEnumerator());
            dbcontext.Setup(db => db.TbLocation).Returns(mocTbLocation.Object);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            //  var result = dataObj.GetServiceProviders(id);
            Assert.ThrowsException<SomeErrorOccuredException>(() => dataObj.GetServiceProviders(id));
        }

        [TestMethod]
        public void GetServiceProvidersTest_Bad()
        {
            int id = 139;
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();
            var mocTbLocation = new Mock<DbSet<TbLocation>>();
            var mocTbServices = new Mock<DbSet<TbServices>>();
            var tbServiceProviders = new List<TbServiceProvider>
            {
                new TbServiceProvider
                {
                    Sno=1,
                    UserId=132,
                    Timings="9am-12pm",
                    Price=500,
                    ServiceId=1,
                    LocationId=1,
                    Rating = 4
                },
                new TbServiceProvider
                {
                    Sno=2,
                    UserId=133,
                    Timings="12pm-6pm",
                    Price=600,
                    ServiceId=2,
                    LocationId=2,
                    Rating = 5
                },
                new TbServiceProvider
                {
                    Sno=3,
                    UserId=134,
                    Timings="6pm-9pm",
                    Price=800,
                    ServiceId=3,
                    LocationId=3,
                    Rating = 4
                }
            }.AsQueryable();

            var TbServices = new List<TbServices>
            {
                new TbServices
                {
                    ServiceId=1,
                    ServiceName="furniture"
                },
                new TbServices
                {
                    ServiceId=2,
                    ServiceName="GasService"
                },
                new TbServices
                {
                   ServiceId=3,
                    ServiceName="Stove"
                }
            }.AsQueryable();

            var tbLocations = new List<TbLocation>
            {
                new TbLocation
                {
                    LocationId=1,
                    LocationName="Bhubaneshawar"
                },
                new TbLocation
                {
                    LocationId=2,
                    LocationName="Bengaluru"
                },
                new TbLocation
                {
                   LocationId=3,
                    LocationName="Hyderabad"
                }
            }.AsQueryable();

            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbcontext.Setup(db => db.TbServiceProvider).Throws(new Exception());


            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.Provider).Returns(TbServices.Provider);
            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.ElementType).Returns(TbServices.ElementType);
            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.Expression).Returns(TbServices.Expression);
            mocTbServices.As<IQueryable<TbServices>>().Setup(u => u.GetEnumerator()).Returns(TbServices.GetEnumerator());
            dbcontext.Setup(db => db.TbServices).Returns(mocTbServices.Object);

            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.Provider).Returns(tbLocations.Provider);
            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.ElementType).Returns(tbLocations.ElementType);
            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.Expression).Returns(tbLocations.Expression);
            mocTbLocation.As<IQueryable<TbLocation>>().Setup(u => u.GetEnumerator()).Returns(tbLocations.GetEnumerator());
            dbcontext.Setup(db => db.TbLocation).Returns(mocTbLocation.Object);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            //  var result = dataObj.GetServiceProviders(id);
            Assert.ThrowsException<SomeErrorOccuredException>(() => dataObj.GetServiceProviders(id));
        }

        [TestMethod]
        public void UpdateProviderPost_Happy()
        {
            int id = 1;
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            tbServiceProvider.Sno = 1;
            tbServiceProvider.UserId = 132;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Price = 800;
            tbServiceProvider.Timings = "9am-12pm";
            tbServiceProvider.ServiceId = 2;
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();
            var tbServiceProviders = new List<TbServiceProvider>
            {
                new TbServiceProvider
                {
                    Sno=1,
                    UserId=132,
                    Timings="9am-12pm",
                    Price=500,
                    ServiceId=1,
                    LocationId=1,
                    Rating = 4
                },
                new TbServiceProvider
                {
                    Sno=2,
                    UserId=133,
                    Timings="12pm-6pm",
                    Price=600,
                    ServiceId=2,
                    LocationId=2,
                    Rating = 5
                },
                new TbServiceProvider
                {
                    Sno=3,
                    UserId=134,
                    Timings="6pm-9pm",
                    Price=800,
                    ServiceId=3,
                    LocationId=3,
                    Rating = 4
                }
            }.AsQueryable();

            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbcontext.Setup(db => db.TbServiceProvider).Returns(mocTbServiceProvider.Object);

            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            var result = dataObj.UpdateProviderPost(id, tbServiceProvider);
            Assert.AreEqual(result, 1);
        }

        [TestMethod]
        public void UpdateProviderPost_Sad()
        {
            int id = 4;
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            tbServiceProvider.Sno = 1;
            tbServiceProvider.UserId = 132;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Price = 800;
            tbServiceProvider.Timings = "9am-12pm";
            tbServiceProvider.ServiceId = 2;
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();
            var tbServiceProviders = new List<TbServiceProvider>
            {
                new TbServiceProvider
                {
                    Sno=1,
                    UserId=132,
                    Timings="9am-12pm",
                    Price=500,
                    ServiceId=1,
                    LocationId=1,
                    Rating = 4
                },
                new TbServiceProvider
                {
                    Sno=2,
                    UserId=133,
                    Timings="12pm-6pm",
                    Price=600,
                    ServiceId=2,
                    LocationId=2,
                    Rating = 5
                },
                new TbServiceProvider
                {
                    Sno=3,
                    UserId=134,
                    Timings="6pm-9pm",
                    Price=800,
                    ServiceId=3,
                    LocationId=3,
                    Rating = 4
                }
            }.AsQueryable();

            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbcontext.Setup(db => db.TbServiceProvider).Returns(mocTbServiceProvider.Object);

            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            Assert.ThrowsException<SomeErrorOccuredException>(() => dataObj.UpdateProviderPost(id, tbServiceProvider));
        }


        [TestMethod]
        public void UpdateProviderPost_Bad()
        {
            int id = 4;
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            tbServiceProvider.Sno = 1;
            tbServiceProvider.UserId = 132;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Price = 800;
            tbServiceProvider.Timings = "9am-12pm";
            tbServiceProvider.ServiceId = 2;
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();
            var tbServiceProviders = new List<TbServiceProvider>
            {
                new TbServiceProvider
                {
                    Sno=1,
                    UserId=132,
                    Timings="9am-12pm",
                    Price=500,
                    ServiceId=1,
                    LocationId=1,
                    Rating = 4
                },
                new TbServiceProvider
                {
                    Sno=2,
                    UserId=133,
                    Timings="12pm-6pm",
                    Price=600,
                    ServiceId=2,
                    LocationId=2,
                    Rating = 5
                },
                new TbServiceProvider
                {
                    Sno=3,
                    UserId=134,
                    Timings="6pm-9pm",
                    Price=800,
                    ServiceId=3,
                    LocationId=3,
                    Rating = 4
                }
            }.AsQueryable();

            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbcontext.Setup(db => db.TbServiceProvider).Throws(new Exception());

            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            Assert.ThrowsException<SomeErrorOccuredException>(() => dataObj.UpdateProviderPost(id, tbServiceProvider));
        }

        [TestMethod]
        public void DeleteProviderPost_Happy()
        {
            int Sno = 1;
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();
            var tbServiceProviders = new List<TbServiceProvider>
            {
                new TbServiceProvider
                {
                    Sno=1,
                    UserId=132,
                    Timings="9am-12pm",
                    Price=500,
                    ServiceId=1,
                    LocationId=1,
                    Rating = 4
                },
                new TbServiceProvider
                {
                    Sno=2,
                    UserId=133,
                    Timings="12pm-6pm",
                    Price=600,
                    ServiceId=2,
                    LocationId=2,
                    Rating = 5
                },
                new TbServiceProvider
                {
                    Sno=3,
                    UserId=134,
                    Timings="6pm-9pm",
                    Price=800,
                    ServiceId=3,
                    LocationId=3,
                    Rating = 4
                }
            }.AsQueryable();
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            tbServiceProvider.Sno = 1;
            tbServiceProvider.UserId = 132;
            tbServiceProvider.LocationId = 1;
            tbServiceProvider.Price = 500;
            tbServiceProvider.Timings = "9am-12pm";
            tbServiceProvider.ServiceId = 1;
            tbServiceProvider.Rating = 4;

            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbcontext.Setup(db => db.TbServiceProvider.Find(It.IsAny<int>())).Returns(tbServiceProvider);

            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            var result = dataObj.DeleteProviderPost(Sno);
            Assert.AreEqual(result, 1);
        }


        [TestMethod]
        public void DeleteProviderPost_Sad()
        {
            int Sno = 4;
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();
            var tbServiceProviders = new List<TbServiceProvider>
            {
                new TbServiceProvider
                {
                    Sno=1,
                    UserId=132,
                    Timings="9am-12pm",
                    Price=500,
                    ServiceId=1,
                    LocationId=1,
                    Rating = 4
                },
                new TbServiceProvider
                {
                    Sno=2,
                    UserId=133,
                    Timings="12pm-6pm",
                    Price=600,
                    ServiceId=2,
                    LocationId=2,
                    Rating = 5
                },
                new TbServiceProvider
                {
                    Sno=3,
                    UserId=134,
                    Timings="6pm-9pm",
                    Price=800,
                    ServiceId=3,
                    LocationId=3,
                    Rating = 4
                }
            }.AsQueryable();
            TbServiceProvider tbServiceProvider = null;
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbcontext.Setup(db => db.TbServiceProvider.Find(It.IsAny<int>())).Returns(tbServiceProvider);

            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            Assert.ThrowsException<SomeErrorOccuredException>(() => dataObj.DeleteProviderPost(Sno));
        }

        [TestMethod]
        public void DeleteProviderPost_Bad()
        {
            int Sno = 4;
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbServiceProvider = new Mock<DbSet<TbServiceProvider>>();
            var tbServiceProviders = new List<TbServiceProvider>
            {
                new TbServiceProvider
                {
                    Sno=1,
                    UserId=132,
                    Timings="9am-12pm",
                    Price=500,
                    ServiceId=1,
                    LocationId=1,
                    Rating = 4
                },
                new TbServiceProvider
                {
                    Sno=2,
                    UserId=133,
                    Timings="12pm-6pm",
                    Price=600,
                    ServiceId=2,
                    LocationId=2,
                    Rating = 5
                },
                new TbServiceProvider
                {
                    Sno=3,
                    UserId=134,
                    Timings="6pm-9pm",
                    Price=800,
                    ServiceId=3,
                    LocationId=3,
                    Rating = 4
                }
            }.AsQueryable();
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Provider).Returns(tbServiceProviders.Provider);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.ElementType).Returns(tbServiceProviders.ElementType);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.Expression).Returns(tbServiceProviders.Expression);
            mocTbServiceProvider.As<IQueryable<TbServiceProvider>>().Setup(u => u.GetEnumerator()).Returns(tbServiceProviders.GetEnumerator());
            dbcontext.Setup(db => db.TbServiceProvider.Find(It.IsAny<int>())).Throws(new Exception());

            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            Assert.ThrowsException<SomeErrorOccuredException>(() => dataObj.DeleteProviderPost(Sno));
        }


        [TestMethod]
        public void ValidatePassword_Happy()
        {
            ResetPasswordCustomEntity resetPasswordCustomEntity = new ResetPasswordCustomEntity();
            resetPasswordCustomEntity.id = 1;
            resetPasswordCustomEntity.oldPassword = "Siddhant@12";
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId=1,
                    UserPassword= "Siddhant@12",
                }
            }.AsQueryable();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers).Returns(mocTbUsers.Object);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            var result = dataObj.ValidatePassword(1, resetPasswordCustomEntity);
            Assert.AreEqual(result, true);

        }
        [TestMethod]
        public void ValidatePassword_Sad()
        {
            ResetPasswordCustomEntity resetPasswordCustomEntity = new ResetPasswordCustomEntity();
            resetPasswordCustomEntity.id = 1;
            resetPasswordCustomEntity.oldPassword = "Siddhant@13";
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId=1,
                    UserPassword= "Siddhant@14",
                }
            }.AsQueryable();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers).Returns(mocTbUsers.Object);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            var result = dataObj.ValidatePassword(1, resetPasswordCustomEntity);
            Assert.AreEqual(result, false);

        }

        [TestMethod]
        public void ValidatePassword_Bad()
        {
            ResetPasswordCustomEntity resetPasswordCustomEntity = new ResetPasswordCustomEntity();
            resetPasswordCustomEntity.id = 1;
            resetPasswordCustomEntity.oldPassword = "Siddhant@12";
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId=1,
                    UserPassword= "Siddhant@12",
                }
            }.AsQueryable();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());

            dbcontext.Setup(db => db.TbUsers).Throws(new Exception());

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);

            Assert.ThrowsException<Exception>(() => dataObj.ValidatePassword(1, resetPasswordCustomEntity));

        }
        [TestMethod]
        public void Happy_ResetPassword()
        {
            int id = 1;
            ResetPasswordCustomEntity resetPasswordCustomEntity = new ResetPasswordCustomEntity();
            resetPasswordCustomEntity.confirmPassword = "Siddhant@12";
            resetPasswordCustomEntity.newPassword = "Siddhant@12";
            resetPasswordCustomEntity.oldPassword = "Siddhant@13";

            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();

            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId = 1,
                    UserPassword = "Siddhant@12",
                    Name ="Siddhant",
                    Email = "jainsid987@gmail.com",
                    ContactNo = "9897661941"
                }
            }.AsQueryable();

            TbUsers tbUser = new TbUsers();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers).Returns(mocTbUsers.Object);
            dbcontext.Setup(db => db.TbUsers.Update(tbUser));
            dbcontext.Setup(db => db.SaveChanges()).Returns(1);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            var result = dataObj.ResetPassword(id, resetPasswordCustomEntity);
            Assert.AreEqual(result, 1);
        }

        [TestMethod]
        public void Sad_ResetPassword()
        {
            int id = 1;
            ResetPasswordCustomEntity resetPasswordCustomEntity = new ResetPasswordCustomEntity();
            resetPasswordCustomEntity.confirmPassword = "Siddhant@12";
            resetPasswordCustomEntity.newPassword = "Siddhant@12";
            resetPasswordCustomEntity.oldPassword = "Siddhant@13";

            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();

            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId = 1,
                    UserPassword = "Siddhant@13",
                    Name ="Siddhant",
                    Email = "jainsid987@gmail.com",
                    ContactNo = "9897661941"
                }
            }.AsQueryable();

            TbUsers tbUser = new TbUsers();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers).Returns(mocTbUsers.Object);
            dbcontext.Setup(db => db.TbUsers.Update(tbUser));
            dbcontext.Setup(db => db.SaveChanges()).Returns(0);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            var result = dataObj.ResetPassword(id, resetPasswordCustomEntity);
            Assert.AreEqual(result, 1);
        }
        [TestMethod]
        public void Bad_ResetPassword()
        {
            int id = 1;
            ResetPasswordCustomEntity resetPasswordCustomEntity = new ResetPasswordCustomEntity();
            resetPasswordCustomEntity.confirmPassword = "Siddhant@12";
            resetPasswordCustomEntity.newPassword = "Siddhant@12";
            resetPasswordCustomEntity.oldPassword = "Siddhant@13";

            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();

            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId = 1,
                    UserPassword = "Siddhant@12",
                    Name ="Siddhant",
                    Email = "jainsid987@gmail.com",
                    ContactNo = "9897661941"
                }
            }.AsQueryable();

            TbUsers tbUser = new TbUsers();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());

            dbcontext.Setup(db => db.TbUsers).Throws(new Exception());

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            Assert.ThrowsException<Exception>(() => dataObj.ResetPassword(id, resetPasswordCustomEntity));
        }
        [TestMethod]
        public void Happy_EmailValidation()
        {
            string Email = "jainsid@gmail.com";

            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId = 1,
                    UserPassword = "asbx@123",
                    Name = "Manisha",
                     Email = "jainsid987@gmail.com",
                    ContactNo = "1234567890"
                }
            }.AsQueryable();
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers).Returns(mocTbUsers.Object);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            var result = dataObj.EmailValidation(Email);
            Assert.AreEqual(result, true);
        }

        [TestMethod]
        public void SAD_EmailValidation()
        {
            string Email = "jainsid987@gmail.com";

            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId = 1,
                    UserPassword = "asbx@123",
                    Name = "Manisha",
                     Email = "jainsid987@gmail.com",
                    ContactNo = "1234567890"
                }
            }.AsQueryable();
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers).Returns(mocTbUsers.Object);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            var result = dataObj.EmailValidation(Email);
            Assert.AreEqual(result, false);
        }
        [TestMethod]
        public void BAD_EmailValidation()
        {
            string Email = "jainsid987@gmail.com";

            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId = 1,
                    UserPassword = "asbx@123",
                    Name = "Manisha",
                     Email = "jainsid98@gmail.com",
                    ContactNo = "1234567890"
                }
            }.AsQueryable();
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());

            dbcontext.Setup(db => db.TbUsers).Throws(new Exception());

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            Assert.ThrowsException<Exception>(() => dataObj.EmailValidation(Email));
        }
        [TestMethod]
        public void Happy_UpdatePassword()
        {
            ForgotPasswordCustomEntity forgotPasswordCustomEntity = new ForgotPasswordCustomEntity();
            forgotPasswordCustomEntity.password = "Siddhant@12";
            forgotPasswordCustomEntity.confirmPassword = "Siddhant@12";
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId=1,
                    UserPassword= "Siddhant@12",
                }
            }.AsQueryable();


            TbUsers tbUser = new TbUsers();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());

            dbcontext.Setup(db => db.TbUsers).Returns(mocTbUsers.Object);
            dbcontext.Setup(db => db.TbUsers.Update(tbUser));
            dbcontext.Setup(db => db.SaveChanges()).Returns(1);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            var result = dataObj.UpdatePassword(forgotPasswordCustomEntity);
            Assert.AreEqual(result, true);
        }

        [TestMethod]
        public void Sad_UpdatePassword()
        {
            ForgotPasswordCustomEntity forgotPasswordCustomEntity = new ForgotPasswordCustomEntity();
            forgotPasswordCustomEntity.password = "Siddhant@12";
            forgotPasswordCustomEntity.confirmPassword = "Siddhant@12";
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId=1,
                    UserPassword= "Siddhant@12",
                }
            }.AsQueryable();


            TbUsers tbUser = new TbUsers();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());

            dbcontext.Setup(db => db.TbUsers).Returns(mocTbUsers.Object);
            dbcontext.Setup(db => db.TbUsers.Update(tbUser));
            dbcontext.Setup(db => db.SaveChanges()).Returns(0);

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            var result = dataObj.UpdatePassword(forgotPasswordCustomEntity);
            Assert.AreEqual(result, true);
        }
        [TestMethod]
        public void Bad_UpdatePassword()
        {

            ForgotPasswordCustomEntity forgotPasswordCustomEntity = new ForgotPasswordCustomEntity();
            forgotPasswordCustomEntity.email = "@@";
            forgotPasswordCustomEntity.password = "Siddhant@12";
            forgotPasswordCustomEntity.confirmPassword = "Siddhant@12";
            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();
            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId=1,
                    UserPassword= "Siddhant@12",
                }
            }.AsQueryable();
            TbUsers tbUser = new TbUsers();
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers).Throws(new Exception());
            dbcontext.Setup(db => db.TbUsers.Update(tbUser));
            dbcontext.Setup(db => db.SaveChanges()).Returns(0);
            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            Assert.ThrowsException<InvalidUserCredentialsException>(() => dataObj.UpdatePassword(forgotPasswordCustomEntity));
        }

        [TestMethod]
        public void Happy_UpdateUserPassword()
        {
            string newPassword = "Siddhant@12";
            TbUsers tbUser = new TbUsers();

            tbUser.Email = "jainsid987@gmail.com";
            tbUser.ContactNo = "9897661943";

            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();

            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserPassword= "Siddhant@12",
                }
            }.AsQueryable();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers.Update(tbUser));
            dbcontext.Setup(db => db.SaveChanges()).Returns(1);


            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            var result = dataObj.UpdateUserPassword(tbUser, newPassword);
            Assert.AreEqual(result, true);
        }

        [TestMethod]
        public void Sad_UpdateUserPassword()
        {

            string newPassword = "";
            TbUsers tbUser = new TbUsers();

            tbUser.Email = "jainsid987@gmail.com";
            tbUser.ContactNo = "9897661943";

            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();

            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserPassword= "Siddhant@12",
                }
            }.AsQueryable();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());
            dbcontext.Setup(db => db.TbUsers.Update(tbUser));
            dbcontext.Setup(db => db.SaveChanges()).Returns(0);


            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            var result = dataObj.UpdateUserPassword(tbUser, newPassword);
            Assert.AreEqual(result, true);
        }

        [TestMethod]
        public void Bad_UpdateUserPassword()
        {
            TbUsers tbUser = new TbUsers();
            string newPassword = "Siddhant@12";



            var dbcontext = new Mock<Orchard2Context>();
            var mocTbUsers = new Mock<DbSet<TbUsers>>();

            var tbUsers = new List<TbUsers>
            {
                new TbUsers
                {
                    UserId = 1,
                    UserPassword = "Siddhant@12",
                    Name ="Siddhant",
                    Email = "jainsid987@gmail.com",
                    ContactNo = "9897661941"
                }
            }.AsQueryable();

            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Provider).Returns(tbUsers.Provider);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.ElementType).Returns(tbUsers.ElementType);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.Expression).Returns(tbUsers.Expression);
            mocTbUsers.As<IQueryable<TbUsers>>().Setup(u => u.GetEnumerator()).Returns(tbUsers.GetEnumerator());

            dbcontext.Setup(db => db.TbUsers).Throws(new Exception());

            UserDataLayerTest testObj = new UserDataLayerTest();
            UserDataAccessLayer dataObj = new UserDataAccessLayer(dbcontext.Object);
            Assert.ThrowsException<Exception>(() => dataObj.UpdateUserPassword(tbUser, newPassword));
        }

    }

}
