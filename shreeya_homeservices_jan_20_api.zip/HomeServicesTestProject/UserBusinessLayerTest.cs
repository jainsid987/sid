using HomeServicesBusinessLayer;
using HomeServicesDataAccessLayer;
using HomeServicesEntities;
using HomeServicesExceptions;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace HomeServicesTestProject
{
    [TestClass]
    public class UserBusinessLayerTest
    {
        [TestMethod]
        public void LogInTest_Happy()
        {
            TbUsers tbUser = new TbUsers();
            tbUser.Email = "manishasharma13@gmail.com";
            tbUser.UserPassword = "Mani@123";
            TbUsers user = new TbUsers()
            {
                UserId = 3,
                UserPassword = "Mani@123",
                Name = "Mani",
                Email = "manishasharma13@gmail.com",
                ContactNo = "0987577890"
            };

            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.GetUsersDetails(tbUser)).Returns(user);
            UserBussinessLayer userBussiness = new UserBussinessLayer(mockDal.Object);
            user.UserPassword = userBussiness.ComputeSha256Hash(user.UserPassword);
            //   tbUser.UserPassword=userBussiness.ComputeSha256Hash(tbUser.UserPassword);

            var result = userBussiness.LogIn(tbUser);
            Assert.IsInstanceOfType(result, typeof(TbUsers));
        }

        [TestMethod]
        public void LogInTest_Sad()
        {
            TbUsers tbUser = new TbUsers();
            tbUser.Email = "manisha13@gmail.com";
            tbUser.UserPassword = "Mani@123";
            TbUsers user = new TbUsers()
            {
                UserId = 3,
                UserPassword = "Mani@123",
                Name = "Mani",
                Email = "manishasharma13@gmail.com",
                ContactNo = "0987577890"
            };

            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.GetUsersDetails(tbUser)).Returns(user);
            UserBussinessLayer userBussiness = new UserBussinessLayer(mockDal.Object);

            Assert.ThrowsException<SomeErrorOccuredException>(() => userBussiness.LogIn(tbUser));


        }


        [TestMethod]
        public void LogInTest_Bad()
        {
            TbUsers tbUser = new TbUsers();
            tbUser.Email = "manisha13@gmail.com";
            tbUser.UserPassword = "Mani@123";
            TbUsers user = new TbUsers()
            {
                UserId = 3,
                UserPassword = "Mani@123",
                Name = "Mani",
                Email = "manishasharma13@gmail.com",
                ContactNo = "0987577890"
            };

            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.GetUsersDetails(tbUser)).Throws(new Exception());
            UserBussinessLayer userBussiness = new UserBussinessLayer(mockDal.Object);

            Assert.ThrowsException<SomeErrorOccuredException>(() => userBussiness.LogIn(tbUser));

        }
        [TestMethod]
        public void Bal_CreatePost_Happy()
        {
            TbServiceProvider tbServiceProvider = new TbServiceProvider();

            tbServiceProvider.UserId = 246;
            tbServiceProvider.Timings = "12pm-6pm";
            tbServiceProvider.Price = 123;
            tbServiceProvider.ServiceId = 1;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Rating = 3;

            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.CreatePost(tbServiceProvider)).Returns(1);

            UserBussinessLayer userBussiness = new UserBussinessLayer(mockDal.Object);
            var result = userBussiness.CreatePost(tbServiceProvider);
            Assert.IsInstanceOfType(result, typeof(int));

        }


        [TestMethod]
        public void Bal_CreatePost_Sad()
        {
            TbServiceProvider tbServiceProvider = new TbServiceProvider();

            tbServiceProvider.UserId = 246;
            tbServiceProvider.Timings = "10am";
            tbServiceProvider.Price = 123;
            tbServiceProvider.ServiceId = 1;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Rating = 3;

            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.CreatePost(tbServiceProvider)).Returns(0);
            UserBussinessLayer userBussiness = new UserBussinessLayer(mockDal.Object);

            Assert.ThrowsException<TimingException>(() => userBussiness.CreatePost(tbServiceProvider));

        }



        [TestMethod]
        public void Bal_CreatePost_Bad()
        {
            TbServiceProvider tbServiceProvider = new TbServiceProvider();

            tbServiceProvider.UserId = 246;
            tbServiceProvider.Timings = "12pm-6pm";
            tbServiceProvider.Price = 123;
            tbServiceProvider.ServiceId = 1;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Rating = 3;

            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.CreatePost(tbServiceProvider)).Throws(new Exception());
            UserBussinessLayer userBussiness = new UserBussinessLayer(mockDal.Object);

            Assert.ThrowsException<Exception>(() => userBussiness.CreatePost(tbServiceProvider));

        }
        [TestMethod]
        public void Happy_AddUserDetailTest()
        {
            TbUsers user = new TbUsers();
            user.Name = "SATYAM";
            user.ContactNo = "9876543210";
            user.Email = "abuey@gmail.com";
            user.UserPassword = "ASQ11111";
            var dal = new Mock<IUserDataAccessLayer>();
            dal.Setup(x => x.AddUserDetail(user)).Returns(1);
            dal.Setup(y => y.EmailValidation(user.Email)).Returns(true);
            int expected = 1;
            var bal = new UserBussinessLayer(dal.Object);
            int actual = bal.AddUserDetail(user);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Sad_AddUserDetail()
        {
            TbUsers user = new TbUsers();
            user.Name = "SATYAM";
            user.ContactNo = "9876543210";
            user.Email = "abuey@gmail.com";
            user.UserPassword = "ASQ11111";
            var dal = new Mock<IUserDataAccessLayer>();
            dal.Setup(x => x.AddUserDetail(user)).Returns(0);
            dal.Setup(y => y.EmailValidation(user.Email)).Returns(false);

            var bal = new UserBussinessLayer(dal.Object);
            //int actual = bal.AddUserDetail(user);
            //Assert.AreEqual(expected, actual);

            Assert.ThrowsException<InvalidUserCredentialsException>(() => bal.AddUserDetail(user));
        }
        [TestMethod]
        public void Bad_AddUserDetail()
        {
            TbUsers user = new TbUsers();
            user.Name = "SATYAM";
            user.ContactNo = "9876543210";
            user.Email = "abuey@gmail.com";
            user.UserPassword = "ASQ11111";
            var dal = new Mock<IUserDataAccessLayer>();
            dal.Setup(x => x.AddUserDetail(user)).Throws(new Exception());
            dal.Setup(y => y.EmailValidation(user.Email)).Returns(true);

            var bal = new UserBussinessLayer(dal.Object);

            Assert.ThrowsException<Exception>(() => bal.AddUserDetail(user));
        }

        [TestMethod]
        public void Happy_IsValidEmailTest()
        {
            string email = "satyam@gmail.com";
            var dal = new Mock<IUserDataAccessLayer>();

            bool expected = true;
            var bal = new UserBussinessLayer(dal.Object);
            bool actual = bal.IsValidEmail(email);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Bad_IsValidEmailTest()
        {
            string email = "satyamgmail.com";
            var dal = new Mock<IUserDataAccessLayer>();
            var bal = new UserBussinessLayer(dal.Object);
            Assert.ThrowsException<InvalidUserCredentialsException>(() => bal.IsValidEmail(email));
        }


        [TestMethod]
        public void Happy_MobileValidatorTest()
        {
            string contactNo = "9876543210";
            var dal = new Mock<IUserDataAccessLayer>();

            bool expected = true;
            var bal = new UserBussinessLayer(dal.Object);
            bool actual = bal.MobileValidator(contactNo);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Bad_MobileValidatorTest()
        {
            string contactNo = "98765432";
            var dal = new Mock<IUserDataAccessLayer>();

            var bal = new UserBussinessLayer(dal.Object);
            Assert.ThrowsException<ContactNoNotValidException>(() => bal.MobileValidator(contactNo));
        }
        [TestMethod]
        public void Happy_PasswordValidationTest()
        {
            string password = "ASq11111";
            var dal = new Mock<IUserDataAccessLayer>();

            bool expected = true;
            var bal = new UserBussinessLayer(dal.Object);
            bool actual = bal.PasswordValidation(password);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Bad_PasswordValidationTest()
        {
            string password = "ASQ11";
            var dal = new Mock<IUserDataAccessLayer>();
            var bal = new UserBussinessLayer(dal.Object);
            Assert.ThrowsException<InvalidUserPasswordException>(() => bal.PasswordValidation(password));
        }
        [TestMethod]
        public void Happy_NameValidationTest()
        {
            string name = "Satyam";
            var dal = new Mock<IUserDataAccessLayer>();

            bool expected = true;
            var bal = new UserBussinessLayer(dal.Object);
            bool actual = bal.NameValidation(name);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Bad_NameValidationTest()
        {
            string name = "Satyam12";
            var dal = new Mock<IUserDataAccessLayer>();
            var bal = new UserBussinessLayer(dal.Object);
            Assert.ThrowsException<NameNotValidException>(() => bal.NameValidation(name));
        }

        [TestMethod]
        public void GetServiceProviders_Happy()
        {
            var tbCustomManagePost = new List<CustomManagePost>()
            {
                new CustomManagePost
                {
                     sNo = 1,
                    UserId = 132,
                    Timings = "9am-12pm",
                    Price = 800,
                    Service = "furniture",
                    Location = "Bengaluru",
                    Rating=5
                },
                new CustomManagePost
                {
                     sNo = 2,
                    UserId = 133,
                    Timings = "9am-12pm",
                    Price = 800,
                    Service = "furniture",
                    Location = "Bengaluru",
                    Rating=5
                }
            };
            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.GetServiceProviders(1)).Returns(tbCustomManagePost);
            var mockBal = new UserBussinessLayer(mockDal.Object);
            List<CustomManagePost> result = mockBal.GetServiceProviders(1);
            Assert.AreEqual(2, result.Count);
        }

        [TestMethod]
        public void GetServiceProviders_Sad()
        {
            var tbCustomManagePost = new List<CustomManagePost>();
            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.GetServiceProviders(1)).Returns(tbCustomManagePost);
            var mockBal = new UserBussinessLayer(mockDal.Object);
            List<CustomManagePost> result = mockBal.GetServiceProviders(1);
            Assert.AreEqual(0, result.Count);
        }

        [TestMethod]
        public void GetServiceProviders_Bad()
        {
            var tbCustomManagePost = new List<CustomManagePost>();
            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.GetServiceProviders(1)).Throws(new Exception());
            var mockBal = new UserBussinessLayer(mockDal.Object);
            Assert.ThrowsException<Exception>(() => mockBal.GetServiceProviders(1));
        }

        [TestMethod]
        public void UpdateProviderPost_Happy()
        {
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            tbServiceProvider.Sno = 1;
            tbServiceProvider.UserId = 132;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Price = 800;
            tbServiceProvider.Timings = "9am-12pm";
            tbServiceProvider.ServiceId = 2;

            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.UpdateProviderPost(1, tbServiceProvider)).Returns(1);
            var mockBal = new UserBussinessLayer(mockDal.Object);
            var result = mockBal.UpdateProviderPost(1, tbServiceProvider);
            Assert.AreEqual(result, 1);
        }

        [TestMethod]
        public void UpdateProviderPost_Sad()
        {
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            tbServiceProvider.Sno = 1;
            tbServiceProvider.UserId = 132;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Price = 800;
            tbServiceProvider.Timings = "9am-12pm";
            tbServiceProvider.ServiceId = 2;

            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.UpdateProviderPost(1, tbServiceProvider)).Returns(1);
            var mockBal = new UserBussinessLayer(mockDal.Object);
            var result = mockBal.UpdateProviderPost(1, tbServiceProvider);
            Assert.AreEqual(result, 1);
        }


        [TestMethod]
        public void UpdateProviderPost_Bad()
        {
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            tbServiceProvider.Sno = 1;
            tbServiceProvider.UserId = 132;
            tbServiceProvider.LocationId = 2;
            tbServiceProvider.Price = 800;
            tbServiceProvider.Timings = "9am-12pm";
            tbServiceProvider.ServiceId = 2;

            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.UpdateProviderPost(1, tbServiceProvider)).Throws(new Exception());
            var mockBal = new UserBussinessLayer(mockDal.Object);
            Assert.ThrowsException<Exception>(() => mockBal.UpdateProviderPost(1, tbServiceProvider));
        }

        [TestMethod]
        public void DeleteProviderPost_Happy()
        {
            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.DeleteProviderPost(1)).Returns(1);
            var mockBal = new UserBussinessLayer(mockDal.Object);
            var result = mockBal.DeleteProviderPost(1);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void DeleteProviderPost_Sad()
        {
            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.DeleteProviderPost(1)).Returns(1);
            var mockBal = new UserBussinessLayer(mockDal.Object);
            var result = mockBal.DeleteProviderPost(1);
            Assert.AreEqual(1, result);
        }

        [TestMethod]
        public void DeleteProviderPost_Bad()
        {
            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.DeleteProviderPost(1)).Throws(new Exception());
            var mockBal = new UserBussinessLayer(mockDal.Object);
            Assert.ThrowsException<Exception>(() => mockBal.DeleteProviderPost(1));
        }

        [TestMethod]
        public void Haappy_ValidatePasword()
        {
            string newPassword = "Siddhant@12";
            string oldPassword = "Siddhant@12";

            var dal = new Mock<IUserDataAccessLayer>();

            bool expected = true;
            var bal = new UserBussinessLayer(dal.Object);
            bool actual = bal.ValidatePassword(newPassword, oldPassword);
            Assert.AreEqual(expected, actual);
        }
        [TestMethod]
        public void Bad_ValidatePassword()
        {
            string newPassword = "Siddhant@14";
            string oldPassword = "";
            var dal = new Mock<IUserDataAccessLayer>();

            var bal = new UserBussinessLayer(dal.Object);
            Assert.ThrowsException<InvalidUserPasswordException>(() => bal.ValidatePassword(newPassword, oldPassword));
        }

        [TestMethod]
        public void Happy_ValidateEmail()
        {
            string email = "jainsid987@gmail.com";

            var MockDal = new Mock<IUserDataAccessLayer>();
            MockDal.Setup(u => u.EmailValidation(email)).Returns(false);
            UserBussinessLayer userBussiness = new UserBussinessLayer(MockDal.Object);
            var result = userBussiness.ValidateEmail(email);
            Assert.AreEqual(result, 1);
        }
        [TestMethod]
        public void Bad_ValiadteEmail()
        {
            string email = "jainsid987@gmail.com";

            var dal = new Mock<IUserDataAccessLayer>();
            dal.Setup(x => x.EmailValidation(email)).Returns(true);
            var bal = new UserBussinessLayer(dal.Object);
            Assert.ThrowsException<InvalidUserCredentialsException>(() => bal.ValidateEmail(email));
        }
        [TestMethod]
        public void Happy_UpdatePassword()
        {
            ForgotPasswordCustomEntity forgotPasswordCustomEntity = new ForgotPasswordCustomEntity();
            forgotPasswordCustomEntity.confirmPassword = "Siddhant@12";
            forgotPasswordCustomEntity.password = "Siddhant@12";
            var dal = new Mock<IUserDataAccessLayer>();
            dal.Setup(x => x.UpdatePassword(forgotPasswordCustomEntity)).Returns(true);
            UserBussinessLayer userBussiness = new UserBussinessLayer(dal.Object);
            var result = userBussiness.UpdatePassword(forgotPasswordCustomEntity);
            Assert.AreEqual(result, true);
        }

        [TestMethod]
        public void Sad_UpdatePassword()
        {
            ForgotPasswordCustomEntity forgotPasswordCustomEntity = new ForgotPasswordCustomEntity();
            forgotPasswordCustomEntity.confirmPassword = "Siddhant@12";
            forgotPasswordCustomEntity.password = "Siddhant@12";
            var dal = new Mock<IUserDataAccessLayer>();
            dal.Setup(x => x.UpdatePassword(forgotPasswordCustomEntity)).Returns(false);
            UserBussinessLayer userBussiness = new UserBussinessLayer(dal.Object);
            var result = userBussiness.UpdatePassword(forgotPasswordCustomEntity);
            Assert.AreEqual(result, false);
        }
        [TestMethod]

        public void Happy_ValidateOTP()
        {
            ForgotPasswordCustomEntity forgotPasswordCustomEntity = new ForgotPasswordCustomEntity();
            forgotPasswordCustomEntity.OTP = 0;
            var dal = new Mock<IUserDataAccessLayer>();
            forgotPasswordCustomEntity.email = "";
            var bal = new UserBussinessLayer(dal.Object);
            bool actual = bal.ValidateOTP(forgotPasswordCustomEntity);
            Assert.AreEqual(actual, true);
        }
        [TestMethod]
        public void Bad_ValidateOTP()
        {
            ForgotPasswordCustomEntity forgotPasswordCustomEntity = new ForgotPasswordCustomEntity();
            forgotPasswordCustomEntity.OTP = 1234;
            var dal = new Mock<IUserDataAccessLayer>();
            forgotPasswordCustomEntity.email = "jainsid987@gmail.com";
            var bal = new UserBussinessLayer(dal.Object);
            Assert.ThrowsException<InvalidOtpException>(() => bal.ValidateOTP(forgotPasswordCustomEntity));
        }

        [TestMethod]
        public void Happy_ResetPassword()
        {
            int id = 1;
            ResetPasswordCustomEntity resetPasswordCustomEntity = new ResetPasswordCustomEntity();
            resetPasswordCustomEntity.confirmPassword = "Siddhant12";
            resetPasswordCustomEntity.newPassword = "Siddhant12";
            resetPasswordCustomEntity.oldPassword = "Siddhant@11";

            var MockDal = new Mock<IUserDataAccessLayer>();
            MockDal.Setup(u => u.ValidatePassword(id, resetPasswordCustomEntity)).Returns(true);
            MockDal.Setup(u => u.ResetPassword(id, resetPasswordCustomEntity)).Returns(1);
            UserBussinessLayer userBussiness = new UserBussinessLayer(MockDal.Object);
            var result = userBussiness.ResetPassword(id, resetPasswordCustomEntity);
            Assert.AreEqual(result, 1);
        }

        [TestMethod]
        public void Sad_ResetPassword()
        {

            int id = 1;
            ResetPasswordCustomEntity resetPasswordCustomEntity = new ResetPasswordCustomEntity();
            resetPasswordCustomEntity.confirmPassword = "Siddhant12";
            resetPasswordCustomEntity.newPassword = "Siddhant12";
            resetPasswordCustomEntity.oldPassword = "Siddhant@11";

            var MockDal = new Mock<IUserDataAccessLayer>();
            MockDal.Setup(u => u.ValidatePassword(id, resetPasswordCustomEntity)).Returns(true);
            MockDal.Setup(u => u.ResetPassword(id, resetPasswordCustomEntity)).Returns(0);
            UserBussinessLayer userBussiness = new UserBussinessLayer(MockDal.Object);
            var result = userBussiness.ResetPassword(id, resetPasswordCustomEntity);
            Assert.AreEqual(result, 0);
        }


        [TestMethod]
        public void Bad_ResetPassword()
        {

            int id = 1;
            ResetPasswordCustomEntity resetPasswordCustomEntity = new ResetPasswordCustomEntity();
            resetPasswordCustomEntity.confirmPassword = "Siddhant12";
            resetPasswordCustomEntity.newPassword = "Siddhant12";
            resetPasswordCustomEntity.oldPassword = "Siddhant@11";
            var MockDal = new Mock<IUserDataAccessLayer>();
            MockDal.Setup(u => u.ValidatePassword(id, resetPasswordCustomEntity)).Returns(false);
            MockDal.Setup(u => u.ResetPassword(id, resetPasswordCustomEntity)).Returns(0);
            UserBussinessLayer userBussiness = new UserBussinessLayer(MockDal.Object);
            Assert.ThrowsException<InvalidUserPasswordException>(() => userBussiness.ResetPassword(id, resetPasswordCustomEntity));
        }

       
        [TestMethod]
        public void Bal_AvailServices_sad()
        {
            var tbCustomAvailServices = new List<TbCustomAvailServices>();
            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.GetAvailableServices()).Returns(tbCustomAvailServices);
            var mockBal = new UserBussinessLayer(mockDal.Object);
            List<TbCustomAvailServices> result = mockBal.GetAvailableServices();
            Assert.AreEqual(0, result.Count);


        }

        [TestMethod]
        public void Bal_AvailServices_Bad()
        {
            var tbCustomAvailServices = new List<TbCustomAvailServices>();
            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.GetAvailableServices()).Throws(new Exception());
            var mockBal = new UserBussinessLayer(mockDal.Object);
            Assert.ThrowsException<Exception>(() => mockBal.GetAvailableServices());
        }



        [TestMethod]
        public void Bal_AvailServices_Happy()
        {
            var tbCustomAvailServices = new List<TbCustomAvailServices>()
            {
                new TbCustomAvailServices
                {
                     Sno = 1,
                     UserId = 132,
                     Timings = "9am-12pm",
                     Price = 800,
                     ServiceId = 1,
                     LocationId = 1,
                     Rating = 5,
                     ProvidersName = "sharan",
                     LocationName = "Bengaluru",
                     ServiceName = "furniture",
                     ContactNo = "990129242"
                },
                new TbCustomAvailServices
                {
                     Sno = 1,
                     UserId = 132,
                     Timings = "9am-12pm",
                     Price = 800,
                     ServiceId = 1,
                     LocationId = 1,
                     Rating = 5,
                     ProvidersName = "sharan",
                     LocationName = "Bengaluru",
                     ServiceName = "furniture",
                     ContactNo = "990129242"
                }
            };


            var mockDal = new Mock<IUserDataAccessLayer>();
            mockDal.Setup(u => u.GetAvailableServices()).Returns(tbCustomAvailServices);
            var mockBal = new UserBussinessLayer(mockDal.Object);
            List<TbCustomAvailServices> result = mockBal.GetAvailableServices();
            Assert.AreEqual(2, result.Count);
        }
    }

}

