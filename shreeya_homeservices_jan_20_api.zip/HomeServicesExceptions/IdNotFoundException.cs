﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class IdNotFoundException : Exception
    {
        public IdNotFoundException(string Message)
            : base(Message)
        { }
        protected IdNotFoundException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
