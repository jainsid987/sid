﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class SomeErrorOccuredException : Exception
    {

        public SomeErrorOccuredException(string Message)
            : base(Message)
        { }

        public SomeErrorOccuredException(string Message, Exception ex)
           : base(Message, ex)
        { }

        protected SomeErrorOccuredException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
