﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class NameNotValidException : Exception
    {
        public NameNotValidException(string message) : base(message)
        {

        }
        protected NameNotValidException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
