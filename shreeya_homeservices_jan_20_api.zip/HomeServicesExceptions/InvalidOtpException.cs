﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class InvalidOtpException : Exception
    {

        public InvalidOtpException(string message) : base(message)
        {

        }
        protected InvalidOtpException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }

}
