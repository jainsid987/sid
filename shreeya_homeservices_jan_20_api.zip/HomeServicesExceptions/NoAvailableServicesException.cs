﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class NoAvailableServicesException: Exception
    {
        public NoAvailableServicesException(string message): base(message)
        {
                
        }
        protected NoAvailableServicesException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
