﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class InvalidUserPasswordException : Exception
    {
        public InvalidUserPasswordException(string message) : base(message)
        {

        }
        protected InvalidUserPasswordException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }

}
