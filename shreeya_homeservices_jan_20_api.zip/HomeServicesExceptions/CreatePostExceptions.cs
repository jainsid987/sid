﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class PriceException : Exception
    {
        public PriceException(string message): base(message)
        {

        }
        protected PriceException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
    [Serializable]
    public class DataEntryException : Exception
    {
        public DataEntryException(string msg) : base(msg)
        {

        }
        protected DataEntryException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
    [Serializable]
    public class ServicePresentException : Exception
    {
        public ServicePresentException(string msg) : base(msg)
        {

        }
        protected ServicePresentException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
    [Serializable]
    public class TimingException : Exception
    {
        public TimingException(string msg) : base(msg)
        {

        }
        protected TimingException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }

}
