﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class InvalidServiceIdException : Exception
    {
        public InvalidServiceIdException(string message) : base(message)
        {
        }
        protected InvalidServiceIdException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
