﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class SNoNotFoundException : Exception
    {
        public SNoNotFoundException(string message) : base(message)
        {
        }
        protected SNoNotFoundException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
