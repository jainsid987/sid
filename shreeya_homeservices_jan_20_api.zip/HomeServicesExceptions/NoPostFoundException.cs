﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class NoPostFoundException : Exception
    {
        public NoPostFoundException(string message) : base(message)
        {
        }
        protected NoPostFoundException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
