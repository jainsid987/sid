﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class UserNotFoundException : Exception
    {
        public UserNotFoundException(string message) : base(message)
        {
        }
        protected UserNotFoundException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
