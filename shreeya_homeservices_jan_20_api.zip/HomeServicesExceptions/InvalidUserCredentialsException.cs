﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class InvalidUserCredentialsException : Exception
    {
        public InvalidUserCredentialsException(string message) : base(message)
        {
        }

        protected InvalidUserCredentialsException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
