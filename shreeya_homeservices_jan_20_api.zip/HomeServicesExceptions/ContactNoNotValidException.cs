﻿using System;
using System.Runtime.Serialization;

namespace HomeServicesExceptions
{
    [Serializable]
    public class ContactNoNotValidException : Exception
    {
        public ContactNoNotValidException(string message) : base(message)
        {

        }
        protected ContactNoNotValidException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }

}
