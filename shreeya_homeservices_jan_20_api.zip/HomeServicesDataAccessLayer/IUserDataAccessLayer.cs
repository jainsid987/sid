﻿using HomeServicesEntities;
using System.Collections.Generic;

namespace HomeServicesDataAccessLayer
{
    public interface IUserDataAccessLayer
    {
        int AddUserDetail(TbUsers users);
        TbUsers GetUsersDetails(TbUsers users);
        int CreatePost(TbServiceProvider serviceProvider);
        int ResetPassword(int id,ResetPasswordCustomEntity resetPasswordCustomEntity);
        bool ValidatePassword(int id , ResetPasswordCustomEntity resetPasswordCustomEntity);
        bool EmailValidation(string email);
        List<TbCustomCustomerHistory> CustomCustomerHistory(int id);
        List<CustomManagePost> GetServiceProviders(int id);
        int UpdateProviderPost(int id, TbServiceProvider tbServiceProvider);
        int DeleteProviderPost(int id);

       
        void Post(TbOrders tbOrders);
        TbCustomEmail FindEmail(TbCustomCustomerDetail tbCustomCustomerDetail);
        bool UpdatePassword(ForgotPasswordCustomEntity forgotPasswordCustomEntity);

        List<TbCustomAvailServices> GetAvailableServices();
    }
}