﻿using HomeServicesEntities;
using HomeServicesExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace HomeServicesDataAccessLayer
{
    public class UserDataAccessLayer : IUserDataAccessLayer
    {
        private readonly Orchard2Context _context;
        public UserDataAccessLayer(Orchard2Context context)
        {
            _context = context;
        }

        public List<TbCustomCustomerHistory> CustomCustomerHistory(int id)
        {
            List<TbCustomCustomerHistory> tbOrders = new List<TbCustomCustomerHistory>();
            var orders = (from tborder in _context.TbOrders
                          join tbusers in _context.TbUsers on tborder.ProviderId equals tbusers.UserId
                          join services in _context.TbServices on tborder.ServiceId equals services.ServiceId
                          where tborder.ConsumerId == id
                          select new
                          {
                              services.ServiceName,
                              tborder.DateOfService,
                              tborder.Timings,
                              tbusers.Name

                          }).ToList();


            foreach (var data in orders)
            {
                TbCustomCustomerHistory tbCustomCustomerHistory = new TbCustomCustomerHistory();
                tbCustomCustomerHistory.ServiceName = data.ServiceName;
                tbCustomCustomerHistory.ServiceDate = data.DateOfService.ToShortDateString();
                tbCustomCustomerHistory.SerivceTime = data.Timings;
                tbCustomCustomerHistory.ServiceProvideName = data.Name;

                tbOrders.Add(tbCustomCustomerHistory);


            }
            return tbOrders;
        }
        public bool UpdateUserPassword(TbUsers tbUsers, string newPassword)
        {
            bool flag = false;
            tbUsers.UserPassword = newPassword;
            _context.TbUsers.Update(tbUsers);
            try
            {
                _context.SaveChanges();
                flag = true;
            }
            catch (DbUpdateException)
            {
                flag = false;
            }
            return flag;

        }
        public bool ValidatePassword(int id, ResetPasswordCustomEntity resetPasswordCustomEntity)
        {
            bool flag = true;
            TbUsers tbUsers = _context.TbUsers.First(x => x.UserId == id);
            string password = tbUsers.UserPassword;
            if (password != resetPasswordCustomEntity.oldPassword)
            {
                flag = false;
            }
            else
            {
                flag = true;
            }
            return flag;
        }
        public int ResetPassword(int id, ResetPasswordCustomEntity resetPasswordCustomEntity)
        {
            bool flag = true;
            TbUsers tbUsers = _context.TbUsers.First(x => x.UserId == id);
            flag = UpdateUserPassword(tbUsers, resetPasswordCustomEntity.newPassword);
            if (flag)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }


        public int CreatePost(TbServiceProvider serviceProvider)
        {

            TbServiceProvider exists = _context.TbServiceProvider.Where(x => x.UserId == serviceProvider.UserId && x.Timings.Equals(serviceProvider.Timings) && x.LocationId == serviceProvider.LocationId  && x.ServiceId == serviceProvider.ServiceId).FirstOrDefault();
            if(exists != null)
            {
                throw new ServicePresentException("Service Already Exists");
            }


            try
            { 
            _context.TbServiceProvider.Add(serviceProvider);
             return _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw (new SomeErrorOccuredException("Something went wrong! Please try again later", ex));
            }
        }



        public int AddUserDetail(TbUsers users)
        {
            _context.TbUsers.Add(users);
            return _context.SaveChanges();
        }
            
        public TbUsers GetUsersDetails(TbUsers users)
        {
            TbUsers tbUsers = null;
            try
            {
                tbUsers = _context.TbUsers.Where(u => u.Email.ToLower().Equals(users.Email.ToLower())).FirstOrDefault();
                if (tbUsers != null)
                {
                    return tbUsers;
                }
                else
                {
                    throw new UserNotFoundException("User does not exist");
                }
            }
            catch (Exception ex)
            {
                throw (new SomeErrorOccuredException("User does not exist", ex));
            }
        }

        public bool EmailValidation(string email)
        {
            TbUsers user = _context.TbUsers.Where(x => x.Email == email).FirstOrDefault();
            if (user == null)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public List<CustomManagePost> GetServiceProviders(int id)
        {
            try
            {
                List<CustomManagePost> tbServiceProviders = new List<CustomManagePost>();
                var tbServiceProvider = (from tbprovider in _context.TbServiceProvider
                                                             join service in _context.TbServices on tbprovider.ServiceId equals service.ServiceId
                                                             where tbprovider.UserId == id
                                                             join location in _context.TbLocation on tbprovider.LocationId equals location.LocationId
                                                             orderby tbprovider.UserId
                                                             select new
                                                             {
                                                                 tbprovider.Sno,
                                                                 tbprovider.UserId,
                                                                 tbprovider.Timings,
                                                                 tbprovider.Price,
                                                                 service.ServiceName,
                                                                 location.LocationName,
                                                                 tbprovider.Rating
                                                             }).ToList();

                foreach (var data in tbServiceProvider)
                {
                    CustomManagePost customManagePost = new CustomManagePost();
                    customManagePost.sNo = data.Sno;
                    customManagePost.UserId = data.UserId;
                    customManagePost.Timings = data.Timings;
                    customManagePost.Price = data.Price;
                    customManagePost.Location = data.LocationName;
                    customManagePost.Service = data.ServiceName;
                    customManagePost.Rating = data.Rating;
                    tbServiceProviders.Add(customManagePost);
                }


                if (tbServiceProvider.Count != 0)
                {
                    return tbServiceProviders;
                }
                else
                {
                    throw new NoPostFoundException("No posts are available");
                }
            }
            catch (Exception ex)
            {
                throw (new SomeErrorOccuredException("No posts are available", ex));
            }

        }

        public int UpdateProviderPost(int id, TbServiceProvider tbServiceProvider)
        {
            try
            {
                TbServiceProvider serviceProvider = _context.TbServiceProvider.Where(c => c.Sno == id).FirstOrDefault();
                if (serviceProvider != null)
                {
                    serviceProvider.LocationId = tbServiceProvider.LocationId;
                    serviceProvider.Price = tbServiceProvider.Price;
                    serviceProvider.Timings = tbServiceProvider.Timings;
                    serviceProvider.ServiceId = tbServiceProvider.ServiceId;
                    _context.SaveChanges();
                    return 1;
                }
                else
                {
                    throw new InvalidServiceIdException("Post not found");
                }
            }
            catch (Exception ex)
            {
                throw (new SomeErrorOccuredException("Somethinng went wrong! Please tr again", ex));
            }


        }
         
        public int DeleteProviderPost(int id)
        {
            try
            {
                TbServiceProvider tbServiceProvider = _context.TbServiceProvider.Find(id);
                if(tbServiceProvider != null)
                {
                    _context.TbServiceProvider.Remove(tbServiceProvider);
                    _context.SaveChanges();
                    return 1;
                }
                else
                {
                    throw new SNoNotFoundException("Post with given id does not exist");
                }
            
            }
            catch (Exception ex)
            {
                throw (new SomeErrorOccuredException("Somethinng went wrong! Please tr again", ex));
            }
        }


        public List<TbCustomAvailServices> GetAvailableServices()
        {
            List<TbCustomAvailServices> tbCustomAvailServicesList = new List<TbCustomAvailServices>();
            var providerDetail = (from Tbserviceprovider in _context.TbServiceProvider
                                  join TbUsers in _context.TbUsers on Tbserviceprovider.UserId equals TbUsers.UserId
                                  join TbLocation in _context.TbLocation on Tbserviceprovider.LocationId equals TbLocation.LocationId
                                  join TbServices in _context.TbServices on Tbserviceprovider.ServiceId equals TbServices.ServiceId
                                  orderby Tbserviceprovider.Rating descending
                                  select new
                                  {
                                      Tbserviceprovider.Sno,
                                      Tbserviceprovider.UserId,
                                      Tbserviceprovider.ServiceId,
                                      Tbserviceprovider.LocationId,
                                      Tbserviceprovider.Price,
                                      Tbserviceprovider.Rating,
                                      Tbserviceprovider.Timings,
                                      TbUsers.Name,
                                      TbLocation.LocationName,
                                      TbServices.ServiceName,
                                      TbUsers.ContactNo
                                  }).ToList();

            if(providerDetail.Count == 0)
            {
                throw new NoAvailableServicesException("No Available service Providers");
            }

            foreach (var data in providerDetail)
            {
                TbCustomAvailServices tbCustomAvailServices = new TbCustomAvailServices();
                tbCustomAvailServices.Sno = data.Sno;
                tbCustomAvailServices.UserId = data.UserId;
                tbCustomAvailServices.ServiceId = data.ServiceId;
                tbCustomAvailServices.LocationId = data.LocationId;
                tbCustomAvailServices.Price = data.Price;
                tbCustomAvailServices.Rating = data.Rating;
                tbCustomAvailServices.Timings = data.Timings;
                tbCustomAvailServices.ProvidersName = data.Name;
                tbCustomAvailServices.LocationName = data.LocationName;
                tbCustomAvailServices.ServiceName = data.ServiceName;
                tbCustomAvailServices.ContactNo = data.ContactNo;
                tbCustomAvailServicesList.Add(tbCustomAvailServices);
            }
            return tbCustomAvailServicesList;

        }
        public bool UpdatePassword(ForgotPasswordCustomEntity forgotPasswordCustomEntity)
        {
            bool flag;
            try
            {
                TbUsers tbUsers = _context.TbUsers.First(x => x.Email == forgotPasswordCustomEntity.email);
                tbUsers.UserPassword = forgotPasswordCustomEntity.password;
                _context.TbUsers.Update(tbUsers);
                _context.SaveChanges();
                flag = true;
            }
            catch (Exception)
            {
                throw (new InvalidUserCredentialsException("InValid Credentials"));
            }
            return flag;
        }
        public void Post(TbOrders tbOrders)
        {
            _context.TbOrders.Add(tbOrders);
            _context.SaveChanges();
        }
        public TbCustomEmail FindEmail(TbCustomCustomerDetail tbCustomCustomerDetail)
        {
            TbCustomEmail tbCustomEmail = new TbCustomEmail();
            tbCustomEmail.Time = tbCustomCustomerDetail.Time;
            tbCustomEmail.Location = tbCustomCustomerDetail.Location;
            tbCustomEmail.Address = tbCustomCustomerDetail.Address;
            tbCustomEmail.DateOfService = tbCustomCustomerDetail.DateOfService;
            TbUsers tbUsers = _context.TbUsers.First(x => x.UserId == tbCustomCustomerDetail.ServiceProviderId);
            tbCustomEmail.ProviderEmail = tbUsers.Email;
            TbUsers user = _context.TbUsers.First(x => x.UserId == tbCustomCustomerDetail.ConsumerId);
            tbCustomEmail.CustomerName = user.Name;
            tbCustomEmail.CustomerPhoneNumber = user.ContactNo;
            return tbCustomEmail;
        }
    }
}


