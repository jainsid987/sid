﻿using Microsoft.EntityFrameworkCore;
using HomeServicesEntities;
namespace HomeServicesDataAccessLayer
{
    public partial class Orchard2Context : DbContext
    {
        public Orchard2Context()
        {
        }

        public Orchard2Context(DbContextOptions<Orchard2Context> options)
            : base(options)
        {
        }

        public virtual DbSet<TbBridge> TbBridge { get; set; }
        public virtual DbSet<TbLocation> TbLocation { get; set; }
        public virtual DbSet<TbOrders> TbOrders { get; set; }
        public virtual DbSet<TbServiceProvider> TbServiceProvider { get; set; }
        public virtual DbSet<TbServices> TbServices { get; set; }
        public virtual DbSet<TbUsers> TbUsers { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer("Server=orchardsqlserver.database.windows.net;Database=Orchard2;User Id=sqluser2;Password=pwd#Login2");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TbBridge>(entity =>
            {
                entity.HasKey(e => e.Sno);

                entity.ToTable("tbBridge");

                entity.Property(e => e.Sno).HasColumnName("SNo");

                entity.HasOne(d => d.Location)
                    .WithMany(p => p.TbBridge)
                    .HasForeignKey(d => d.LocationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tbBridge__Locati__6AC5C326");

                entity.HasOne(d => d.Service)
                    .WithMany(p => p.TbBridge)
                    .HasForeignKey(d => d.ServiceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tbBridge__Servic__6BB9E75F");
            });

            modelBuilder.Entity<TbLocation>(entity =>
            {
                entity.HasKey(e => e.LocationId);

                entity.ToTable("tbLocation");

                entity.Property(e => e.LocationName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbOrders>(entity =>
            {
                entity.HasKey(e => e.OrderId);

                entity.ToTable("tbOrders");

                entity.Property(e => e.DateOfService).HasColumnType("date");

                entity.Property(e => e.Timings)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.HasOne(d => d.Consumer)
                    .WithMany(p => p.TbOrdersConsumer)
                    .HasForeignKey(d => d.ConsumerId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tbOrders__Consum__6CAE0B98");

                entity.HasOne(d => d.Provider)
                    .WithMany(p => p.TbOrdersProvider)
                    .HasForeignKey(d => d.ProviderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tbOrders__Provid__6DA22FD1");

                entity.HasOne(d => d.Service)
                    .WithMany(p => p.TbOrders)
                    .HasForeignKey(d => d.ServiceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tbOrders__Servic__6E96540A");
            });

            modelBuilder.Entity<TbServiceProvider>(entity =>
            {
                entity.HasKey(e => e.Sno);

                entity.ToTable("tbServiceProvider");

                entity.Property(e => e.Sno).HasColumnName("SNO");

                entity.Property(e => e.Timings)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.Location)
                    .WithMany(p => p.TbServiceProvider)
                    .HasForeignKey(d => d.LocationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tbService__Locat__6F8A7843");

                entity.HasOne(d => d.Service)
                    .WithMany(p => p.TbServiceProvider)
                    .HasForeignKey(d => d.ServiceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tbService__Servi__707E9C7C");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.TbServiceProvider)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__tbService__UserI__7172C0B5");
            });

            modelBuilder.Entity<TbServices>(entity =>
            {
                entity.HasKey(e => e.ServiceId);

                entity.ToTable("tbServices");

                entity.Property(e => e.ServiceName)
                    .IsRequired()
                    .HasMaxLength(100)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<TbUsers>(entity =>
            {
                entity.HasKey(e => e.UserId);

                entity.ToTable("tbUsers");

                entity.Property(e => e.ContactNo)
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);

                entity.Property(e => e.UserPassword)
                    .IsRequired()
                    .HasMaxLength(255)
                    .IsUnicode(false);
            });
        }
    }
}
