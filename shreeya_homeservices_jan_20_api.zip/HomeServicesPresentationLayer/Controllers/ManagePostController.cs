﻿using System;
using System.Collections.Generic;
using HomeServicesExceptions;
using HomeServicesPresentationLayer.Models;
using Microsoft.AspNetCore.Mvc;

namespace HomeServicesPresentationLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ManagePostController : ControllerBase
    {
        private readonly IModelManager _modelManager;
        public ManagePostController(IModelManager modelManager)
        {
            _modelManager = modelManager;
        }

        [HttpGet]
        [Route("GetServiceProviders/{id}")]
        public ActionResult<List<CustomManagePostModel>> GetServiceProviders(int id)
        {
            try
            {
                return Ok(_modelManager.GetServiceProviders(id));
            }
            catch(NoPostFoundException ex)
            {
                return BadRequest(ex.Message);
            }
            catch(Exception)
            {
                return BadRequest("Something went wrong please try again!");
            }
        }

        [HttpPut]
        [Route("UpdateProviderPost/{id}")]
        public ActionResult<int> UpdateProviderPost(int id, [FromBody] TbServiceProviderModel tbServiceProviderModel)
        {
            try
            {
                return Ok(_modelManager.UpdateProviderPost(id, tbServiceProviderModel));
            }
            catch (InvalidServiceIdException ex)
            {
                return BadRequest(ex.Message);
            }
            catch(Exception)
            {
                return BadRequest("Something went wrong please try again!");
            }
            
        }

        [HttpDelete]
        [Route("DeleteProviderPost/{id}")]
        public ActionResult<int> DeleteProviderPost(int id)
        {
            try
            {
                return Ok(_modelManager.DeleteProviderPost(id));
            }
            catch(SNoNotFoundException sn)
            {
                return BadRequest(sn.Message);
            }
            catch(Exception)
            {
                return BadRequest("Something went wrong please try again!");
            }
        }
    }
}