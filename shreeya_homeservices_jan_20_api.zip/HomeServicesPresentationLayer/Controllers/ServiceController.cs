﻿using System;
using System.Collections.Generic;
using HomeServicesExceptions;
using HomeServicesPresentationLayer.Models;
using Microsoft.AspNetCore.Mvc;

namespace HomeServicesPresentationLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ServiceController : ControllerBase
    {
        private readonly IModelManager _modelManager;
        public ServiceController(IModelManager modelManager)
        {
            _modelManager = modelManager;
        }


        [HttpGet]
        [Route("GetAvailableServices")]
        public IActionResult GetAvailableServices()
        {
            List<TbCustomAvailServicesModel> tbCustomAvailServicesModelsList;

            try
            {
                tbCustomAvailServicesModelsList = _modelManager.GetAvailableServices();
                return Ok(tbCustomAvailServicesModelsList);
            }
            catch(NoAvailableServicesException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception)
            {
                return BadRequest("something Went Wrong Please try again later");
            }

        }
    }

    
}