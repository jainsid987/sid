﻿using System;
using HomeServicesPresentationLayer.Models;
using Microsoft.AspNetCore.Mvc;
using HomeServicesExceptions;

namespace HomeServicesPresentationLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IModelManager _managerModel;
        public AuthController(IModelManager managerModel)
        {
            _managerModel = managerModel;
        }
        [HttpPost]
        public IActionResult LogIn(UsersModel usersModel)
        {

            UsersModel authorizedUser = null;
            if(usersModel == null)
            {
                return BadRequest("Please enter username and password");
            }
            try
            {
                authorizedUser = _managerModel.LogIn(usersModel);
                return Ok(authorizedUser);
            }
            catch(InvalidUserCredentialsException iuce)
            {
                return BadRequest(iuce.Message);
            }
            catch(UserNotFoundException ufe)
            {
                return BadRequest(ufe.Message);
            }
            catch(SomeErrorOccuredException soe)
            {
                return BadRequest(soe.Message);
            }
            catch(Exception)
            {
                return BadRequest("something went wrong! Please try again");
            }
            
        }
        [HttpGet]
        [Route("CheckEmail")]
        public ActionResult CheckEmail(string email)
        {
            try
            {
                _managerModel.ValidateEmail(email);
                return Ok("Email Address found");
            }
            catch (InvalidUserCredentialsException iuc)
            {
                return BadRequest(iuc.Message);
            }
        }
        [HttpGet]
        [Route("SendMail")]
        public ActionResult SendMail(string mail)
        {
            try
            {
                int otp = _managerModel.SendMail(mail);
                return Ok(otp);
            }
            catch (SomeErrorOccuredException ex)
            {
                return BadRequest(ex.Message);
            }

        }
        [HttpPut]
        [Route("UpdatePassword")]
        public ActionResult UpdatePassword(ForgotPasswordCustomEntityModel forgotPasswordCustomEntityModel)
        {
            try
            {
                _managerModel.UpdatePassword(forgotPasswordCustomEntityModel);
                return Ok("Password updated Successfully");
            }
            catch (InvalidUserPasswordException ex)
            {
                return BadRequest(ex.Message);
            }
            catch(InvalidOtpException ex)
            {
                return BadRequest(ex.Message);
            }
            catch(InvalidUserCredentialsException ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}