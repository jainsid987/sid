﻿using System;
using Microsoft.AspNetCore.Mvc;
using HomeServicesPresentationLayer.Models;
using HomeServicesExceptions;

namespace HomeServicesPresentationLayer.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IModelManager _modelManager;
        public UserController(IModelManager modelManager)
        {
            _modelManager =modelManager;
        }
       [HttpPost]
        public IActionResult AddUserDetail(TbUsersModel usersModelEntity)
        {
            try
            {
                int check = _modelManager.AddUserDetail(usersModelEntity);
                if (check > 0)
                {
                    return Ok();
                }
                else
                {
                    return BadRequest("Enter value correctly");
                }
            }
            catch (InvalidUserPasswordException iup)
            {
                return BadRequest(iup.Message);
            }
            catch (InvalidUserCredentialsException iuc)
            {
                return BadRequest(iuc.Message);
            }
            catch (ContactNoNotValidException cnnf)
            {
                return BadRequest(cnnf.Message);
            }
            catch (NameNotValidException nnve)
            {
                return BadRequest(nnve.Message);
            }
            catch (Exception)
            {
                return BadRequest("Enter value correctly");
            }

        }
        [HttpPost]
        [Route("createpost")]
        public IActionResult CreatePost(TbServiceProviderModel serviceProvider)
        {
            try
            {
                int check = _modelManager.CreatePost(serviceProvider);
                if (check > 0)
                {
                    return Ok("added successfully");
                }
                else
                {
                    return BadRequest("Enter Correctly");
                }
            }
            catch(PriceException ex)
            {
                return BadRequest(ex.Message);
            }
            catch(SomeErrorOccuredException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception)
            {
                return BadRequest("Something went Wrong Try again Later");
            }
        }

        [HttpPut]
        [Route("ResetPassword")]
        public IActionResult ResetPassword([FromBody] ResetPasswordCustomModel resetPasswordCustomModel)
        {
            int id = resetPasswordCustomModel.id;
            try
            {
                _modelManager.ResetPassword(id, resetPasswordCustomModel);
                return Ok("Password Reset Successfully");
            }
            catch(InvalidUserPasswordException ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}