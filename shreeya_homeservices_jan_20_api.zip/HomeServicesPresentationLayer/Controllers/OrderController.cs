﻿using System.Collections.Generic;
using HomeServicesPresentationLayer.Models;
using Microsoft.AspNetCore.Mvc;
using HomeServicesExceptions;
using System;

namespace HomeServicesPresentationLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {

        private readonly IModelManager _managerModel;
        public OrderController(IModelManager managerModel)
        {
            _managerModel = managerModel;
        }





        [HttpGet]
        public IActionResult Get(int userid)
        {
            try
            {
                List<TbCustomCustomerHistoryModel> tbCustomCustomerHistoryModels = _managerModel.CustomCustomerHistory(userid);
                return Ok(tbCustomCustomerHistoryModels);
            }
            catch (IdNotFoundException)
            {
                return BadRequest("Data not found");
            }

            catch (Exception)
            {
                return BadRequest("something went wrong! Please try again");
            }
        }
        [HttpPost]
        [Route("Email")]
       
        public void Email([FromBody] TbCustomCustomerDetailModel tbCustomCustomerDetailModel)
        {
            _managerModel.Post(tbCustomCustomerDetailModel);
            _managerModel.FindEmail(tbCustomCustomerDetailModel);
            
        }
       
        
       
    }
}
