﻿using HomeServicesBusinessLayer;
using HomeServicesEntities;
using HomeServicesExceptions;
using System;
using System.Collections.Generic;

namespace HomeServicesPresentationLayer.Models
{
    public class ManagerModel: IModelManager
    {
        private readonly IUserBussinessLayer _userBusinessLayer;
        public ManagerModel(IUserBussinessLayer userBusinessLayer)
        {
            _userBusinessLayer = userBusinessLayer;
        }
        public int AddUserDetail(TbUsersModel usersModelEntity)
        {
            TbUsers user = new TbUsers();
            if (_userBusinessLayer.NameValidation(usersModelEntity.Name.Trim()))
            {
                user.Name = usersModelEntity.Name;
            }
            if (_userBusinessLayer.PasswordValidation(usersModelEntity.UserPassword))
            {
                string encryptPassword = _userBusinessLayer.ComputeSha256Hash(usersModelEntity.UserPassword);
                user.UserPassword = encryptPassword;
            }

            if (_userBusinessLayer.IsValidEmail(usersModelEntity.Email))
            {
                user.Email = usersModelEntity.Email.Trim();
            }
            if (_userBusinessLayer.MobileValidator(usersModelEntity.ContactNo))
            {
                user.ContactNo = usersModelEntity.ContactNo;
            }


            return _userBusinessLayer.AddUserDetail(user);
        }
        public int CreatePost(TbServiceProviderModel serviceProviderModelEntity)
        {
            TbServiceProvider serviceProvider = new TbServiceProvider();
            serviceProvider.UserId = serviceProviderModelEntity.UserId;
            serviceProvider.Timings = serviceProviderModelEntity.Timings;
            serviceProvider.Price = serviceProviderModelEntity.Price;
            serviceProvider.ServiceId = serviceProviderModelEntity.ServiceId;
            serviceProvider.LocationId = serviceProviderModelEntity.LocationId;
            serviceProvider.Rating = new Random().Next(1, 6);

            if(serviceProvider.Price <= 0 || serviceProvider.Price > 1000)
            {
                throw new PriceException("price should be greater than 0 and less than 1000");
            }
            try
            { 
                 return _userBusinessLayer.CreatePost(serviceProvider);
            }
            catch (ServicePresentException ex)
            {
                throw (new SomeErrorOccuredException("Service Already Present", ex));
            }
            catch (TimingException e)
            {
                throw (new SomeErrorOccuredException("Please Enter Only Available Timings", e));
            }
            catch (DataEntryException exe)
            {
                throw (new SomeErrorOccuredException("Somethinng went wrong! Please tr again", exe));
            }
        }
        public UsersModel LogIn(UsersModel usersModel)
        {

            TbUsers users = new TbUsers();
            TbUsers authorizedUser = null;
            if (_userBusinessLayer.IsValidEmail(usersModel.Email))
            {
                users.Email = usersModel.Email.Trim();
            }
            users.UserPassword = usersModel.UserPassword;
            try
            {
                authorizedUser = _userBusinessLayer.LogIn(users);
            }
            catch (InvalidUserCredentialsException exe)
            {
                throw (new SomeErrorOccuredException("Somethinng went wrong! Please tr again", exe));
            }
            catch (Exception exe)
            {
                throw (new SomeErrorOccuredException("Somethinng went wrong! Please tr again", exe));
            }
            UsersModel authorizedUsersModel = new UsersModel();
            authorizedUsersModel.UserId = authorizedUser.UserId;
            return authorizedUsersModel;
        }
        public int ResetPassword(int id, ResetPasswordCustomModel resetPasswordCustomModel)
        {
            ResetPasswordCustomEntity resetPasswordCustomEntity = new ResetPasswordCustomEntity();
            resetPasswordCustomEntity.oldPassword = resetPasswordCustomModel.oldPassword;
            resetPasswordCustomEntity.newPassword = resetPasswordCustomModel.newPassword;
            resetPasswordCustomEntity.confirmPassword = resetPasswordCustomModel.confirmPassword;
            bool flag = _userBusinessLayer.ValidatePassword(resetPasswordCustomEntity.newPassword, resetPasswordCustomEntity.confirmPassword);
            if (flag)
            {
                int status = _userBusinessLayer.ResetPassword(id, resetPasswordCustomEntity);
                return status;
            }
            else
            {
                return 0;
            }
        }
      
        public List<TbCustomCustomerHistoryModel> CustomCustomerHistory(int id)
        {
            List<TbCustomCustomerHistory> list = _userBusinessLayer.CustomCustomerHistory(id);
            List<TbCustomCustomerHistoryModel> list1 = new List<TbCustomCustomerHistoryModel>();
            foreach(TbCustomCustomerHistory item in list)
            {
                TbCustomCustomerHistoryModel tbCustomCustomerHistoryModel = new TbCustomCustomerHistoryModel();
                tbCustomCustomerHistoryModel.ServiceName = item.ServiceName;
                tbCustomCustomerHistoryModel.ServiceDate = item.ServiceDate;
                tbCustomCustomerHistoryModel.SerivceTime = item.SerivceTime;
                tbCustomCustomerHistoryModel.ServiceProvideName = item.ServiceProvideName;

                list1.Add(tbCustomCustomerHistoryModel);
            }
            return list1;
        }

        public List<CustomManagePostModel> GetServiceProviders(int id)
        {
            List<CustomManagePost> tbServiceProviders = _userBusinessLayer.GetServiceProviders(id);
            List<CustomManagePostModel> serviceProviderModels = new List<CustomManagePostModel>();
            foreach(CustomManagePost tbServiceProvider in tbServiceProviders)
            {
                CustomManagePostModel tbServiceProviderModel = new CustomManagePostModel();
                tbServiceProviderModel.sNo = tbServiceProvider.sNo;
                tbServiceProviderModel.UserId = tbServiceProvider.UserId;
                tbServiceProviderModel.Service = tbServiceProvider.Service;
                tbServiceProviderModel.Location = tbServiceProvider.Location;
                tbServiceProviderModel.Price = tbServiceProvider.Price;
                tbServiceProviderModel.Rating = tbServiceProvider.Rating;
                tbServiceProviderModel.Timings = tbServiceProvider.Timings;
                serviceProviderModels.Add(tbServiceProviderModel);
            }

            return serviceProviderModels;
        }

        public int UpdateProviderPost(int id, TbServiceProviderModel tbServiceProviderModel)
        {
            TbServiceProvider tbServiceProvider = new TbServiceProvider();
            tbServiceProvider.LocationId = tbServiceProviderModel.LocationId;
            tbServiceProvider.Price = tbServiceProviderModel.Price;
            tbServiceProvider.Timings = tbServiceProviderModel.Timings;
            tbServiceProvider.ServiceId = tbServiceProviderModel.ServiceId;
            int ch = _userBusinessLayer.UpdateProviderPost(id, tbServiceProvider);
            return ch;
        }

        public int DeleteProviderPost(int id)
        {
            return _userBusinessLayer.DeleteProviderPost(id);
        }


        public List<TbCustomAvailServicesModel> GetAvailableServices()
        {
            List<TbCustomAvailServices> tbCustomAvailServicesList;
            List<TbCustomAvailServicesModel> tbCustomAvailServicesModelList = new List<TbCustomAvailServicesModel>();

            try
            {
                tbCustomAvailServicesList = _userBusinessLayer.GetAvailableServices();
            }
            catch (NoAvailableServicesException exe)
            {
                throw (new SomeErrorOccuredException("Somethinng went wrong! Please tr again", exe));
            }


            foreach (TbCustomAvailServices services in tbCustomAvailServicesList)
            {
                TbCustomAvailServicesModel servicesModel = new TbCustomAvailServicesModel();

                servicesModel.Sno = services.Sno;
                servicesModel.UserId = services.UserId;
                servicesModel.ServiceId = services.ServiceId;
                servicesModel.LocationId = services.LocationId;
                servicesModel.Timings = services.Timings;
                servicesModel.Price = services.Price;
                servicesModel.Rating = services.Rating;
                servicesModel.ProvidersName = services.ProvidersName;
                servicesModel.LocationName = services.LocationName;
                servicesModel.ServiceName = services.ServiceName;
                servicesModel.ContactNo = services.ContactNo;

                tbCustomAvailServicesModelList.Add(servicesModel);

            }

            return tbCustomAvailServicesModelList;
        }

        public bool UpdatePassword(ForgotPasswordCustomEntityModel forgotPasswordCustomEntityModel)
        {
            ForgotPasswordCustomEntity forgotPasswordCustomEntity = new ForgotPasswordCustomEntity();
            forgotPasswordCustomEntity.confirmPassword = forgotPasswordCustomEntityModel.confirmPassword;
            forgotPasswordCustomEntity.OTP = forgotPasswordCustomEntityModel.otp;
            forgotPasswordCustomEntity.email = forgotPasswordCustomEntityModel.email;
            forgotPasswordCustomEntity.password = forgotPasswordCustomEntityModel.password;
            bool flag = _userBusinessLayer.ValidateOTP(forgotPasswordCustomEntity);
            if (flag)
            {
                return _userBusinessLayer.UpdatePassword(forgotPasswordCustomEntity);
            }
            else
            {
                return flag;
            }
        }


        public int SendMail(string email)
        {
            return _userBusinessLayer.SendOTP(email);

        }

        public int ValidateEmail(string email)
        {
            return _userBusinessLayer.ValidateEmail(email);
        }
        public void Post(TbCustomCustomerDetailModel tbCustomCustomerDetailModel)
        {
            TbOrders tbOrders = new TbOrders();
            tbOrders.ProviderId = tbCustomCustomerDetailModel.ServiceProviderId;
            tbOrders.ConsumerId = tbCustomCustomerDetailModel.ConsumerId;
            tbOrders.ServiceId = tbCustomCustomerDetailModel.ServiceId;
            tbOrders.DateOfService = tbCustomCustomerDetailModel.DateOfService;
            tbOrders.Timings = tbCustomCustomerDetailModel.Time;

            _userBusinessLayer.Post(tbOrders);
        }
        public void FindEmail(TbCustomCustomerDetailModel tbCustomCustomerDetailModel)
        {
            TbCustomCustomerDetail tbCustomCustomerDetail = new TbCustomCustomerDetail();
            tbCustomCustomerDetail.ServiceProviderId = tbCustomCustomerDetailModel.ServiceProviderId;
            tbCustomCustomerDetail.ConsumerId = tbCustomCustomerDetailModel.ConsumerId;
            tbCustomCustomerDetail.ServiceId = tbCustomCustomerDetailModel.ServiceId;
            tbCustomCustomerDetail.DateOfService = tbCustomCustomerDetailModel.DateOfService;
            tbCustomCustomerDetail.Time = tbCustomCustomerDetailModel.Time;
            tbCustomCustomerDetail.Address = tbCustomCustomerDetailModel.Address;
            tbCustomCustomerDetail.Location = tbCustomCustomerDetailModel.Location;

            _userBusinessLayer.FindEmail(tbCustomCustomerDetail);
            
        }
    }
}
