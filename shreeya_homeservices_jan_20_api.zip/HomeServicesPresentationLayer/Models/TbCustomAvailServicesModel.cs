﻿namespace HomeServicesPresentationLayer.Models
{
    public class TbCustomAvailServicesModel
    {
        public int Sno { get; set; }
        public int UserId { get; set; }
        public string Timings { get; set; }
        public int Price { get; set; }
        public int ServiceId { get; set; }
        public int LocationId { get; set; }
        public int Rating { get; set; }
        public string ProvidersName { get; set; }
        public string LocationName { get; set; }
        public string ServiceName { get; set; }

        public string ContactNo { get; set; }
    }
}
