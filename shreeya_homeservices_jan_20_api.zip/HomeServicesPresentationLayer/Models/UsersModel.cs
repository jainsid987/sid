﻿namespace HomeServicesPresentationLayer.Models
{
    public class UsersModel
    {
        public int UserId { get; set; }
        public string UserPassword { get; set; }
        public string Email { get; set; }
    }
}