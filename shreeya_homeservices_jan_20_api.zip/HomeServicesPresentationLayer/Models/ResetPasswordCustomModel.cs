﻿namespace HomeServicesPresentationLayer.Models
{
    public class ResetPasswordCustomModel
    {
        public int id { get; set; }
        public string oldPassword { get; set; }
        public string newPassword { get; set; }
        public string confirmPassword { get; set; }
    }
}
