﻿namespace HomeServicesPresentationLayer.Models
{
    public class ForgotPasswordCustomEntityModel
    {

        public int otp { get; set; }
        public string email { get; set; }
        public string password { get; set; }

        public string confirmPassword { get; set; }
    }
}
