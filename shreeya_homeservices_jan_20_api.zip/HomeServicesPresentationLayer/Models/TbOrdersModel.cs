﻿using System;

namespace HomeServicesPresentationLayer.Models
{
    public class TbOrdersModel
    {
        public int ProviderId { get; set; }
        public int ConsumerId { get; set; }
        public int ServiceId { get; set; }
        public DateTime DateOfService { get; set; }
        public string Timings { get; set; }

    }
}
