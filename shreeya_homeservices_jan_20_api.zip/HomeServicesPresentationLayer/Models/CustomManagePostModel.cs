﻿namespace HomeServicesPresentationLayer.Models
{
    public class CustomManagePostModel
    {
        public int sNo { get; set; }
        public int UserId { get; set; }
        public string Timings { get; set; }
        public int Price { get; set; }
        public string Service { get; set; }
        public string Location { get; set; }
        public int Rating { get; set; }
    }
}
