﻿using System;

namespace HomeServicesPresentationLayer.Models
{
    public class TbCustomCustomerDetailModel
    {
        public int ConsumerId { get; set; }
        public int ServiceId { get; set; }
        public DateTime DateOfService { get; set; }
        public string Time { get; set; }
        public int ServiceProviderId { get; set; }
        public string Location { get; set; }
        public string Address { get; set; }

    }
}
