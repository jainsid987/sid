﻿namespace HomeServicesPresentationLayer.Models
{
    public class TbCustomCustomerHistoryModel
    {
        public string ServiceName { get; set; }
        public string ServiceDate { get; set; }
        public string SerivceTime { get; set; }
        public string ServiceProvideName { get; set; }

    }
}
