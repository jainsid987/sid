﻿namespace HomeServicesPresentationLayer.Models
{
    public class TbServiceProviderModel
    {
        public int Sno { get; set; }
        public int UserId { get; set; }
        public string Timings { get; set; }
        public int Price { get; set; }
        public int ServiceId { get; set; }
        public int LocationId { get; set; }
        public int Rating { get; set; }
    }
}
