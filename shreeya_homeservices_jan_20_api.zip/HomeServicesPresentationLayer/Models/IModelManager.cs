﻿using System.Collections.Generic;

namespace HomeServicesPresentationLayer.Models
{
    public interface IModelManager
    {
     
        List<TbCustomCustomerHistoryModel> CustomCustomerHistory(int id);
        int AddUserDetail(TbUsersModel usersModelEntity);
        UsersModel LogIn(UsersModel usersModel);
        int CreatePost(TbServiceProviderModel serviceProviderModelEntity);
        int ResetPassword(int id, ResetPasswordCustomModel resetPasswordCustomModel);
        List<CustomManagePostModel> GetServiceProviders(int id);
        int UpdateProviderPost(int id, TbServiceProviderModel tbServiceProviderModel);
        int DeleteProviderPost(int id);
        int ValidateEmail(string email);
        bool UpdatePassword(ForgotPasswordCustomEntityModel forgotPasswordCustomEntityModel);
        int SendMail(string email);

        List<TbCustomAvailServicesModel> GetAvailableServices();
        void Post(TbCustomCustomerDetailModel tbCustomCustomerDetailModel);
        void FindEmail(TbCustomCustomerDetailModel tbCustomCustomerDetailModel);
    }
}