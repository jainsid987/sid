export const environment = {
  // postUrl: 'https://shreeya-homeservices-jan-20-dev-api.azurewebsites.net/api/',
 postUrl: 'https://shreeya-homeservices-jan-20-qa-api.azurewebsites.net/api/',
  development: false
};
