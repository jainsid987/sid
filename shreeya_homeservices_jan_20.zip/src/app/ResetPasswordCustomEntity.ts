export class ResetPassword {
id: number;
oldPassword: string;
newPassword: string;
confirmPassword: string;
}
