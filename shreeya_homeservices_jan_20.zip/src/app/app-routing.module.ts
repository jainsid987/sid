import { CustomerDetailComponent } from './Modules/customer/customer-detail/customer-detail.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LogInUserComponent } from '../app/Modules/log-in/log-in-user/log-in-user.component';
import { ManagePostComponent } from '../app/Modules/post/manage-post/manage-post.component';

import { LoggedInHomeComponent } from 'src/app/Modules/home-page/logged-in-home/logged-in-home.component';
import { CreatePostComponent } from 'src/app/Modules/post/create-post/create-post.component';
import { HomeComponent } from 'src/app/Modules/home-page/home/home.component';
import {CustomerHistoryComponent} from 'src/app/Modules/customer/customer-history/customer-history.component';
import { SignUpComponent } from 'src/app/Modules/log-in/sign-up/sign-up.component';
import {ResetPasswordComponent} from 'src/app/Modules/log-in/reset-password/reset-password.component';
import { FiltersComponent } from 'src/app/Modules/customer/avail-services/filters/filters.component';
import { AuthGuard } from './auth.guard';
import { ServiceListComponent } from '../app/Modules/customer/avail-services/service-list/service-list.component';
import {AboutComponent } from '../app/Modules/home-page/about/about.component';


const routes: Routes =
[
  {
    path: '', component: HomeComponent
  },

  {
    path: 'DisplayCreatePost', component: CreatePostComponent, canActivate: [AuthGuard]
  },
  {
    path: 'DisplayCustomerHistory', component: CustomerHistoryComponent, canActivate: [AuthGuard]
  },
  {
    path: 'DisplayLogIn', component: LogInUserComponent
  },
  {
    path: 'DisplaySignUp', component: SignUpComponent
  },
  {
    path: 'DisplayResetPassword', component: ResetPasswordComponent, canActivate: [AuthGuard]
  },
  {
    path: 'DisplayLoggedHomePage', component: LoggedInHomeComponent, canActivate: [AuthGuard]
  },
  {
    path: 'ManagePost', component: ManagePostComponent, canActivate: [AuthGuard]
  },
  {
    path: 'DisplayAvailServicePage', component: FiltersComponent
  },
  {
    // tslint:disable-next-line:max-line-length
    path: 'DisplayAvailableServices/DisplayAvailServicePage/DisplayCustomerDetail', component: CustomerDetailComponent,  canActivate: [AuthGuard]
  },
  {
    // tslint:disable-next-line:max-line-length
    path: 'DisplayAvailServicePage/DisplayCustomerDetail', component: CustomerDetailComponent,  canActivate: [AuthGuard]
  },
  {
    path: 'DisplayAvailableServices/DisplayAvailServicePage', component: FiltersComponent
  },
  {
    path: 'DisplayAvailableServices', component: ServiceListComponent
  },
  {
    path: 'AboutUs', component: AboutComponent
  }

];
@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
