import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GuestBarComponent } from './guest-bar.component';

describe('GuestBarComponent', () => {
  let component: GuestBarComponent;
  let fixture: ComponentFixture<GuestBarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GuestBarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GuestBarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
