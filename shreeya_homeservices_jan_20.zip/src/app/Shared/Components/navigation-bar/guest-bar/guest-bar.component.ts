import { Component, OnInit } from '@angular/core';
import { LogInUserComponent } from 'src/app/Modules/log-in/log-in-user/log-in-user.component';
import {MatDialog, MatDialogRef } from '@angular/material/dialog';
import {LogInService} from 'src/app/Modules/log-in/log-in.service';
import { ResetPasswordComponent } from '../../../../Modules/log-in/reset-password/reset-password.component';
import {SignUpComponent} from 'src/app/Modules/log-in/sign-up/sign-up.component';

@Component({
  selector: 'app-guest-bar',
  templateUrl: './guest-bar.component.html',
  styleUrls: ['./guest-bar.component.css']
})
export class GuestBarComponent implements OnInit {

  loginDiagRef: MatDialogRef<LogInUserComponent>;
  resetDiagRef: MatDialogRef<ResetPasswordComponent>;
   singUpDiagRef: MatDialogRef<SignUpComponent>;

  loggedIn() {
    return this.Navservice.LoggedIn();
  }

  constructor(private dialog: MatDialog, private Navservice: LogInService) { }

  ngOnInit() {
  }

  openLogInDialog() {
    this.loginDiagRef = this.dialog.open(LogInUserComponent, {
      height: '500px',
      width: '350px',
    }
  );
}

  openResetPopUp() {
    this.resetDiagRef = this.dialog.open(ResetPasswordComponent, {
      height: '500px',
      width: '350px',
  }
  );
}

openSignUpPopUp() {
  alert('please register yourself to work with us');
  this.singUpDiagRef = this.dialog.open(SignUpComponent, {
    height: '500px',
    width: '350px',
}
);
}

onselectlocation(id: number) {
  localStorage.locationid1 = JSON.stringify(id);

}
status() {
  if (localStorage.getItem('locationstatus') === '1') {
    return false;
  } else {
    return true;
  }
}

}
