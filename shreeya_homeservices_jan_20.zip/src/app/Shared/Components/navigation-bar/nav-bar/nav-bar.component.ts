import { Component, OnInit } from '@angular/core';
import {MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ResetPasswordComponent } from 'src/app/Modules/log-in/reset-password/reset-password.component';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  loginDiagRef: MatDialogRef<ResetPasswordComponent>;

  constructor(private dialog: MatDialog) { }

  ngOnInit() {
  }

  ResetPasswordPopUp() {
    this.loginDiagRef = this.dialog.open(ResetPasswordComponent, {
      height: '500px',
      width: '350px',
    }
  );

  }


}
