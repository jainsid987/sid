export class CustomEmail{
    consumerId: number;
    serviceId: number;
    dateofService: any;
    time: string;
    serviceproviderId: number;
    location: string;
    address: string;
}