export class CustomTbAvailServices {
  sno: number;
  userId: number;
  timings: string;
  price: number;
  serviceId: number;
  locationId: number;
  rating: number;
  providersName: string;
  locationName: string;
  serviceName: string;
  contactNo: string;
}
