export class TbLocation {
  locationId: number;
  locationName: string;
}
