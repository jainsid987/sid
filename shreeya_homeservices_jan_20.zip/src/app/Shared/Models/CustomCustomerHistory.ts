export class CustomCustomerHistory {
    serviceName: string;
    sericeDate: string;
    serviceTime: string;
    serviceproviderName: string;
}
