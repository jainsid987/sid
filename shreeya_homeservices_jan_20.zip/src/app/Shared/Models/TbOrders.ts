export class TbOrders {
  orderId: number;
  providerId: number;
  consumerId: number;
  serviceId: number;
  dateOfService: Date;
  timings: string;
}
