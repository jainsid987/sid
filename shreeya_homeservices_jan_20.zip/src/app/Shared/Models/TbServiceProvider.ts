export class TbServiceProvider {
  sNo: number;
  userId: number;
  timings: string;
  price: number;
  serviceId: number;
  locationId: number;
  rating: number;
}
