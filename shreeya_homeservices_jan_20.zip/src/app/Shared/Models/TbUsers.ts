export class TbUsers {
  userId: number;
  userPassword: string;
  name: string;
  email: string;
  contactNo: string;
}
