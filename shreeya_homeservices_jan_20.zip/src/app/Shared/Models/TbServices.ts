export class TbServices {
  serviceId: number;
  serviceName: string;
}
