import { Component, OnInit } from '@angular/core';
import { CustomTbAvailServices } from '../../../../Shared/Models/CustomTbAvailServices';
import { CustomerService } from 'src/app/Modules/customer/customer.service';

@Component({
  selector: 'app-provider-list',
  templateUrl: './provider-list.component.html',
  styleUrls: ['./provider-list.component.css']
})
export class ProviderListComponent implements OnInit {

  customAvailServices: CustomTbAvailServices[];

  constructor(private customerService: CustomerService) { }

  ngOnInit() {
    this.customerService.GetAvailableServices().subscribe((data) => this.customAvailServices = data);
  }

}
