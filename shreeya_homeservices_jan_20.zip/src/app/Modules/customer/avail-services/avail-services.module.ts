import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FiltersComponent } from './filters/filters.component';
import { ProviderListComponent } from './provider-list/provider-list.component';
import { ServiceListComponent } from './service-list/service-list.component';



@NgModule({
  declarations: [FiltersComponent, ProviderListComponent, ServiceListComponent],
  imports: [
    CommonModule
  ]
})
export class AvailServicesModule { }
