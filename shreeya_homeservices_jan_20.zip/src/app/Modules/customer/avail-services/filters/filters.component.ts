import { isEmpty } from 'rxjs/internal/operators';
import { Component, OnInit } from '@angular/core';
import { CustomTbAvailServices } from '../../../../Shared/Models/CustomTbAvailServices';
import { CustomerService } from 'src/app/Modules/customer/customer.service';
import { FormControl } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ActivatedRoute} from '@angular/router';
import { MatDialogRef, MatDialog} from '@angular/material/dialog';
import { LogInUserComponent } from '../../../log-in/log-in-user/log-in-user.component';
import { LogInService } from '../../../log-in/log-in.service';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'app-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.css']
})
export class FiltersComponent implements OnInit {
  logInDiagref: MatDialogRef<LogInUserComponent>;
k: number;
userId: number;
isEmpty = false;
time1: string; time2: string; time3: string;
resultsubcateg = [];
date = new FormControl(new Date());
serializedDate = new FormControl((new Date()).toISOString());
dateSelected: any;
customAvailServices: CustomTbAvailServices[];
timing: string;
serviceId: number;
locationId: number;
providerpricemin: number;
providerpricemax: number;
isListNull: boolean;
copyList: CustomTbAvailServices[];
copyList1: CustomTbAvailServices[];
copyList2: CustomTbAvailServices[];
minDate = new Date();
maxDate = new Date();
rangeValue: any;
categories: CustomTbAvailServices[];
formatLabel(value: number) {
  if (value >= 1000) {
    return Math.round(value / 1000) + 'k';
  }

  return value;
}

onTimingSubmit(time: string, event) {
  this.time1 = null;
  this.time2 = null;
  this.time3 = null;
  if (localStorage.getItem('Time1') != null) {
    localStorage.removeItem('Time1');
  }
  if (localStorage.getItem('Time2') != null) {
    localStorage.removeItem('Time2');
  }
  if (localStorage.getItem('Time3') != null) {
    localStorage.removeItem('Time3');
  }
  const checked = event.checked;
  if (checked) {
    this.resultsubcateg.push(time);
  } else {
    const index = this.resultsubcateg.indexOf(time);
    this.resultsubcateg.splice(index, 1);
  }
  for (const val of this.resultsubcateg) {
    if (val === '9am-12pm') {
      console.log(val);
      this.time1 = val;
      localStorage.Time1 = JSON.stringify(this.time1);
    }
    if (val === '12pm-6pm') {
      console.log(val);
      this.time2 = val;
      localStorage.Time2 = JSON.stringify(this.time2);
    }
    if (val === '6pm-9pm') {
      console.log(val);
      this.time3 = val;
      localStorage.Time3 = JSON.stringify(this.time3);
    }

  }
  if (localStorage.getItem('locationid') !== null && localStorage.getItem('answer') !== null && localStorage.getItem('pricemin') !== null) {
    this.locationId = JSON.parse(localStorage.locationid);
    this.serviceId = JSON.parse(localStorage.answer);
    this.providerpricemin =  JSON.parse(localStorage.pricemin);
    this.providerpricemax =  JSON.parse(localStorage.pricemax);

    this.copyList1 = this.categories.filter(res => {
        return res.locationId === this.locationId && res.serviceId === this.serviceId
        && res.price <= this.providerpricemax && res.price >= this.providerpricemin;
      });

    this.customAvailServices = this.ReturnList(this.customAvailServices, this.copyList1, this.time1, this.time2, this.time3);
  } else if (localStorage.getItem('locationid') !== null && localStorage.getItem('answer') !== null
  && localStorage.getItem('pricemin') === null) {
    this.locationId = JSON.parse(localStorage.locationid);
    this.serviceId = JSON.parse(localStorage.answer);
    this.copyList1 = this.categories.filter(res => {
      return res.locationId === this.locationId && res.serviceId === this.serviceId;
    });
    this.customAvailServices = this.ReturnList(this.customAvailServices, this.copyList1, this.time1, this.time2, this.time3);
    }
}

ReturnList(customAvailServices, categories, time1, time2, time3) {
  if (!(categories != null)) {
    categories = this.customAvailServices;

  }
  if (time1 != null && time2 != null && time3 != null) {
    customAvailServices = categories.filter(res => {
    return res.timings === time1 || res.timings === time2 || res.timings === time3;

  });

} else if (time1 === null && time2 === null && time3 != null) {
  customAvailServices = categories.filter(res => {
    return res.timings === time3;

  });
} else if (time1 === null && time2 != null && time3 === null) {
  customAvailServices = categories.filter(res => {
    return res.timings === time2;

  });
} else if (time1 === null && time2 != null && time3 != null) {
  customAvailServices = categories.filter(res => {
    return res.timings === time2 || res.timings === time3;
  });
} else if (time1 != null && time2 === null && time3 === null) {
  customAvailServices = categories.filter(res => {
    return res.timings === time1;

  });
} else if (time1 != null && time2 === null && time3 != null) {
  customAvailServices = categories.filter(res => {
    return res.timings === time1 || res.timings === time3;

  });
} else if (time1 != null && time2 != null && time3 === null) {
  customAvailServices = categories.filter(res => {
    return res.timings === time1 || res.timings === time2;

  });
} else if (time1 === null && time2 === null && time3 === null) {
  customAvailServices = categories;
}
  return customAvailServices;
}



onPriceSubmit(min: number, max: number) {
  console.log(min); console.log(max);
  if (localStorage.getItem('locationid') !== null && localStorage.getItem('answer') !== null &&
  (localStorage.getItem('Time1') !== null || localStorage.getItem('Time2') !== null || localStorage.getItem('Time3') !== null)) {
    this.locationId = JSON.parse(localStorage.locationid);
    this.serviceId = JSON.parse(localStorage.answer);
    this.copyList1 = this.categories.filter(res => {
      return res.locationId === this.locationId && res.serviceId === this.serviceId;
    });
    this.copyList1 = this.ReturnList(this.customAvailServices, this.copyList1, this.time1, this.time2, this.time3);
    this.customAvailServices = this.copyList1.filter(res => {
      return res.price <= max && res.price >= min;
    });
  } else if (localStorage.getItem('locationid') !== null && localStorage.getItem('answer') !== null) {
    this.locationId = JSON.parse(localStorage.locationid);
    this.serviceId = JSON.parse(localStorage.answer);
    this.copyList1 = this.categories.filter(res => {
      return res.locationId === this.locationId && res.serviceId === this.serviceId;
    });
    this.customAvailServices = this.copyList1.filter(res => {
      return res.price <= max && res.price >= min;
    });
  }
  localStorage.pricemin = JSON.stringify(min);
  localStorage.pricemax = JSON.stringify(max);
//   alert(this.customAvailServices.length);
//   if (this.customAvailServices.length === 0) {
//   this.isEmpty = true;
// }
}
toggle(event) {
  console.log(event.value);
}


onServiceSubmit(id: number) {
  console.log(id);
  if (localStorage.getItem('locationid') !== null && localStorage.getItem('pricemin') !== null &&
  (localStorage.getItem('Time1') !== null || localStorage.getItem('Time2') !== null || localStorage.getItem('Time3') !== null)) {

    this.locationId = JSON.parse(localStorage.locationid);
    this.providerpricemin =  JSON.parse(localStorage.pricemin);
    this.providerpricemax =  JSON.parse(localStorage.pricemax);
    if (this.locationId !== null) {
      this.copyList1 = this.categories.filter(res => {
        return res.locationId === this.locationId && res.price <= this.providerpricemax && res.price >= this.providerpricemin;
      });

      this.customAvailServices = this.ReturnList(this.customAvailServices, this.copyList1, this.time1, this.time2, this.time3);
      this.customAvailServices = this.customAvailServices.filter(res => {
        return res.serviceId === id;
      });
    }
   } else if (localStorage.getItem('locationid') !== null && localStorage.getItem('pricemin') !== null &&
  localStorage.getItem('pricemax') !== null) {

    this.locationId = JSON.parse(localStorage.locationid);
    this.providerpricemin =  JSON.parse(localStorage.pricemin);
    this.providerpricemax =  JSON.parse(localStorage.pricemax);
    if (this.locationId !== null) {
      this.copyList1 = this.categories.filter(res => {
        return res.locationId === this.locationId && res.price <= this.providerpricemax && res.price >= this.providerpricemin;
      });

      this.customAvailServices = this.copyList1.filter(res => {
        return res.serviceId === id;
      });
    }
  } else if (localStorage.getItem('locationid') !== null &&
  (localStorage.getItem('Time1') !== null || localStorage.getItem('Time2') !== null || localStorage.getItem('Time3') !== null)) {

    this.locationId = JSON.parse(localStorage.locationid);
    if (this.locationId !== null) {
      this.copyList1 = this.categories.filter(res => {
        return res.locationId === this.locationId;
      });

      this.customAvailServices = this.ReturnList(this.customAvailServices, this.copyList1, this.time1, this.time2, this.time3);
      this.customAvailServices = this.customAvailServices.filter(res => {
        return res.serviceId === id;
      });
    }
   } else if (localStorage.getItem('locationid') !== null ) {
     this.locationId = JSON.parse(localStorage.locationid);
     if (this.locationId !== null) {
      this.copyList1 = this.categories.filter(res => {
        return res.locationId === this.locationId;
      });

      this.customAvailServices = this.copyList1.filter(res => {
        return res.serviceId === id;
      });
    }
   } else {
    if (!(this.categories != null)) {
      this.categories = this.customAvailServices;

    }


    this.customAvailServices = this.categories.filter(res => {
      return res.serviceId === id;

    });
  }
  localStorage.answer = JSON.stringify(id);
  localStorage.sid = JSON.stringify(id);
}
onLocationSubmit(id: number) {
  console.log(id);
  if (localStorage.getItem('answer') !== null && localStorage.getItem('pricemin') !== null &&
  localStorage.getItem('pricemax') !== null && (localStorage.getItem('Time1') !== null ||
   localStorage.getItem('Time2') !== null || localStorage.getItem('Time3') !== null)) {

    this.serviceId = JSON.parse(localStorage.answer);
    this.providerpricemin =  JSON.parse(localStorage.pricemin);
    this.providerpricemax =  JSON.parse(localStorage.pricemax);
    if (this.serviceId !== null) {
      this.copyList1 = this.categories.filter(res => {
        return res.serviceId === this.serviceId && res.price <= this.providerpricemax && res.price >= this.providerpricemin;
      });

      this.customAvailServices = this.ReturnList(this.customAvailServices, this.copyList1, this.time1, this.time2, this.time3);
      this.customAvailServices = this.customAvailServices.filter(res => {
        return res.locationId === id;
      });
    }
   } else if (localStorage.getItem('answer') !== null && localStorage.getItem('pricemin') !== null &&
  localStorage.getItem('pricemax') !== null) {

    this.serviceId = JSON.parse(localStorage.answer);
    this.providerpricemin =  JSON.parse(localStorage.pricemin);
    this.providerpricemax =  JSON.parse(localStorage.pricemax);
    if (this.serviceId !== null) {
      this.copyList1 = this.categories.filter(res => {
        return res.serviceId === this.serviceId && res.price <= this.providerpricemax && res.price >= this.providerpricemin;
      });

      this.customAvailServices = this.copyList1.filter(res => {
        return res.locationId === id;
      });
    }
   } else if (localStorage.getItem('answer') !== null && (localStorage.getItem('Time1') !== null ||
        localStorage.getItem('Time2') !== null || localStorage.getItem('Time3') !== null)) {
         this.serviceId = JSON.parse(localStorage.answer);
         this.copyList1 = this.ReturnList(this.customAvailServices, this.categories, this.time1, this.time2, this.time3);
         this.customAvailServices = this.copyList1.filter(res => {
             return res.locationId === id && res.serviceId === this.serviceId;
           });
          } else if (localStorage.getItem('answer') !== null) {
         this.serviceId = JSON.parse(localStorage.answer);
         if (this.serviceId !== null) {
           this.customAvailServices = this.categories.filter(res => {
             return res.serviceId === this.serviceId && res.locationId === id;
           });
         }
        } else {
  if (!(this.categories != null)) {
    this.categories = this.customAvailServices;
  }


  this.customAvailServices = this.categories.filter(res => {
    return res.locationId === id;
  });
}
  localStorage.locationid = JSON.stringify(id);
  localStorage.locationid1 = JSON.stringify(id);
  // this.copyList = this.customAvailServices;
}


  // tslint:disable-next-line:max-line-length
  constructor(private customerService: CustomerService, private datePipe: DatePipe, private route: ActivatedRoute, private diag: MatDialog, private logInService: LogInService, private SpinnerService: NgxSpinnerService) { }

  ngOnInit() {
    this.SpinnerService.show();
    localStorage.setItem('locationstatus' , '1');
    this.maxDate.setDate(this.maxDate.getDate() + 30);
    // this.k = Number(this.route.snapshot.paramMap.get('id'));
    this.customerService.GetAvailableServices().subscribe((data) =>  {
      this.customAvailServices = data;
      this.SpinnerService.hide();
      this.FirstTimeDisplay();
    },
      error => {
        this.isListNull = true;
        this.SpinnerService.hide();
      }
    ) ;

    if (localStorage.getItem('pricemin') !== null) {
      localStorage.removeItem('pricemin'); localStorage.removeItem('pricemax');
    }
    if (localStorage.getItem('answer') !== null) {
      localStorage.removeItem('answer');
    }
    if (localStorage.getItem('locationId') !== null) {
    localStorage.removeItem('locationid');
     }
    if (localStorage.getItem('Time1') !== null) {
      localStorage.removeItem('Time1');
     }
    if (localStorage.getItem('Time2') !== null) {
      localStorage.removeItem('Time2');
     }
    if (localStorage.getItem('Time3') !== null) {
      localStorage.removeItem('Time3');
     }
  }

  openLogInPopUp() {
alert('please logIn to avail a service');
this.diag.open(LogInUserComponent, {
height: '500px',
width: '350px'
});
  }

  loggedIn() {
    return this.logInService.LoggedIn();
  }

  ServiceDetails(service) {
    if (this.dateSelected !== undefined) {
      this.customerService.ServiceDetails(service, this.dateSelected);
    } else {
      this.customerService.ServiceDetails(service, this.minDate);
  }
  }

  OnDateChange(selectedDate) {
    this.dateSelected = selectedDate;
  }
  FirstTimeDisplay() {
    if (localStorage.getItem('token') !== null) {
      this.userId = JSON.parse(localStorage.token);
    } else {
      this.userId = 0;
    }
    if (localStorage.getItem('sid') != null) {
    this.k = JSON.parse(localStorage.sid);
    localStorage.answer =  JSON.stringify(this.k);
    }

    if (localStorage.getItem('locationid1') !== null && localStorage.getItem('answer') !== null ) {
    this.locationId = JSON.parse(localStorage.locationid1);
    this.serviceId = JSON.parse(localStorage.answer);
    localStorage.locationid = JSON.stringify(this.locationId);
    localStorage.answer = JSON.stringify(this.serviceId);
    if (!(this.categories != null)) {
      this.categories = this.customAvailServices.filter(res => {
        return res.userId !== this.userId;
      });
    }
    this.customAvailServices = this.categories.filter(res => {
      return res.locationId === this.locationId && res.serviceId === this.serviceId;
    });
    } else if (localStorage.getItem('locationid1') === null && localStorage.getItem('answer') !== null ) {
      this.serviceId = JSON.parse(localStorage.answer);
      localStorage.locationid = JSON.stringify(1);
      this.locationId = 1;
      localStorage.answer = JSON.stringify(this.serviceId);
      if (!(this.categories != null)) {
      this.categories = this.customAvailServices.filter(res => {
        return res.userId !== this.userId;
      });

    }
      this.customAvailServices = this.categories.filter(res => {
      return res.serviceId === this.serviceId && res.locationId === this.locationId;
    });
    }
  }

  IsEmpty() {
    try {
        if (this.customAvailServices.length === 0) {
          return false;
        } else {
          return true;
        }
      } catch (e) {

      }
  }

}


