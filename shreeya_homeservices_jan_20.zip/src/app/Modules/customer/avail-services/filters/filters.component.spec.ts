import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { MatSelectModule, MatDrawer, MatDatepicker } from '@angular/material';
import { FiltersComponent } from './filters.component';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCardModule, MatDatepickerModule } from '@angular/material';
import {MatInputModule} from '@angular/material/input';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { RouterModule } from '@angular/router';
import {MatSidenavModule} from '@angular/material/sidenav';
import { HttpClientModule } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MatNativeDateModule} from '@angular/material';
import { CustomTbAvailServices} from 'src/app/Shared/Models/CustomTbAvailServices';
import { CustomerService } from 'src/app/Modules/customer/customer.service';
import { of } from '../../../../../../node_modules/rxjs/internal/observable/of';

describe('FiltersComponent', () => {
  let component: FiltersComponent;
  let fixture: ComponentFixture<FiltersComponent>;
  // tslint:disable-next-line:prefer-const
  let customerService: CustomerService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        MatCheckboxModule,
        MatFormFieldModule,
        MatSelectModule,
        MatCardModule,
        MatInputModule,
        MatDatepickerModule,
        FormsModule,
        ReactiveFormsModule,
        RouterModule,
        MatSidenavModule,
        HttpClientModule,
        RouterModule.forRoot([]),
        BrowserAnimationsModule,
        MatNativeDateModule

],
      declarations: [ FiltersComponent ],
      providers: [DatePipe]
    })
    .compileComponents();
    customerService = TestBed.get(CustomerService);
  }));
  beforeEach(() => {
    fixture = TestBed.createComponent(FiltersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    localStorage.sid = JSON.stringify(1);
    localStorage.locationid1 = JSON.stringify(1);
    component.customAvailServices = [{sno: 2, userId: 2,  providersName: 'satyam',
    timings: '9am-12pm', price: 500, serviceId: 1, locationId: 1, rating: 5, locationName: 'bhubanwshwar',
    serviceName: 'furniture', contactNo: '9876543210'}, {sno: 3, userId: 2,  providersName: 'satyam',
    timings: '9am-12pm', price: 500, serviceId: 1, locationId: 2, rating: 5, locationName: 'bhubanwshwar',
    serviceName: 'furniture', contactNo: '9876543210'}];
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });



  it ('it should display provider list for the first time when clicked on avail service', () => {
    const allproviderlist: CustomTbAvailServices[] = [{sno: 2, userId: 2,  providersName: 'satyam',
    timings: '9am-12pm', price: 500, serviceId: 1, locationId: 1, rating: 5, locationName: 'bhubanwshwar',
    serviceName: 'furniture', contactNo: '9876543210'}];
    component.FirstTimeDisplay();
    expect(component.customAvailServices).toEqual(allproviderlist);
  });

  it ('it should display filtered provider list based on location', () => {
    const allproviderlist: CustomTbAvailServices[] = [{sno: 2, userId: 2,  providersName: 'satyam',
    timings: '9am-12pm', price: 500, serviceId: 1, locationId: 1, rating: 5, locationName: 'bhubanwshwar',
    serviceName: 'furniture', contactNo: '9876543210'}];
    component.onLocationSubmit(1);
    expect(component.customAvailServices).toEqual(allproviderlist);
  });
  it ('it should display filtered provider list based on price , location and service type', () => {
    const allproviderlist: CustomTbAvailServices[] = [{sno: 2, userId: 2,  providersName: 'satyam',
    timings: '9am-12pm', price: 500, serviceId: 1, locationId: 1, rating: 5, locationName: 'bhubanwshwar',
    serviceName: 'furniture', contactNo: '9876543210'}];
    component.FirstTimeDisplay();
    component.onPriceSubmit(300, 600);
    expect(component.customAvailServices).toEqual(allproviderlist);
  });
  it ('it should display filtered provider list based on Time , location and service type', () => {
    const allproviderlist: CustomTbAvailServices[] = [{sno: 2, userId: 2,  providersName: 'satyam',
    timings: '9am-12pm', price: 500, serviceId: 1, locationId: 1, rating: 5, locationName: 'bhubanwshwar',
    serviceName: 'furniture', contactNo: '9876543210'}];
    component.FirstTimeDisplay();
    component.onTimingSubmit('9am-12pm', 'checked');
    expect(component.customAvailServices).toEqual(allproviderlist);
  });
  it ('it should display filtered provider list based service type and location', () => {
    const allproviderlist: CustomTbAvailServices[] = [{sno: 2, userId: 2,  providersName: 'satyam',
    timings: '9am-12pm', price: 500, serviceId: 1, locationId: 1, rating: 5, locationName: 'bhubanwshwar',
    serviceName: 'furniture', contactNo: '9876543210'}];
    component.FirstTimeDisplay();
    component.onServiceSubmit(1);
    expect(component.customAvailServices).toEqual(allproviderlist);
  });
  it ('it should return filtered provider list based on timing', () => {
    const allproviderlist: CustomTbAvailServices[] = [{sno: 2, userId: 2,  providersName: 'satyam',
    timings: '9am-12pm', price: 500, serviceId: 1, locationId: 1, rating: 5, locationName: 'bhubanwshwar',
    serviceName: 'furniture', contactNo: '9876543210'}];
    component.ReturnList(component.customAvailServices, component.customAvailServices,
    '9am-12pm', '12pm-6pm', null);
    expect(component.customAvailServices).toEqual(component.customAvailServices);
  });

  it('should return the available services', () => {
    const customServiceDetails: CustomTbAvailServices[] = [
      // tslint:disable-next-line:max-line-length
      { sno: 1, userId: 1, timings: '9AM-12PM', price: 500, serviceId: 1, locationId: 1, rating: 5, providersName: 'sharan', locationName: 'banglore', serviceName: 'furniture', contactNo: '9901292427'}
    ];

    spyOn(customerService, 'GetAvailableServices').and.returnValue(of(customServiceDetails));
    component.ngOnInit();
    expect(component.customAvailServices).toEqual(customServiceDetails);
  });
});
