import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { CustomEmail } from './../../../Shared/Models/CustomEmail';
import { CustomerService } from 'src/app/Modules/customer/customer.service';
import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router } from '../../../../../node_modules/@angular/router';


@Component({
  selector: 'app-customer-detail',
  templateUrl: './customer-detail.component.html',
  styleUrls: ['./customer-detail.component.css']
})
export class CustomerDetailComponent implements OnInit {
  formEmail: FormGroup;
  city: string;
  closeResult: string;
  place: any;
  constructor(public apiservice: CustomerService, private modalService: NgbModal, private route: Router) {
    this.formEmail = new FormGroup(
      {
        address: new FormControl('', Validators.required),
        location: new FormControl(this.apiservice.serviceInfo.locationName)
      }
    );
   }
      email = new CustomEmail();
      msg: CustomEmail;
      ngOnInit() {
        }

      onSubmit() {
        this.email = this.formEmail.value;
        this.email.consumerId = Number(localStorage.getItem('token'));
        this.email.serviceId = this.apiservice.serviceInfo.serviceId;
        this.email.dateofService = this.apiservice.selectedDate;
        this.email.time = this.apiservice.serviceInfo.timings;
        this.email.serviceproviderId = this.apiservice.serviceInfo.userId;
        this.email.location = this.apiservice.serviceInfo.locationName;
        this.apiservice.AddCustomerAddress(this.email).subscribe(data => this.msg = data);
        this.formEmail.reset();
    }

    open(content) {
      this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }
    private getDismissReason(reason: any): string {
      this.route.navigate(['']);
      if (reason === ModalDismissReasons.ESC) {
        return 'by pressing ESC';
      } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
        return 'by clicking on a backdrop';
      } else {
        return  `with: ${reason}`;
      }
    }
    }
