import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NavigationBarModule } from './../../Shared/Components/navigation-bar/navigation-bar.module';
import { NavBarComponent } from './../../Shared/Components/navigation-bar/nav-bar/nav-bar.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomerDetailComponent } from './customer-detail/customer-detail.component';
import { CustomerHistoryComponent } from './customer-history/customer-history.component';


@NgModule({
  declarations: [CustomerDetailComponent, CustomerHistoryComponent, NavBarComponent],
  imports: [
    CommonModule,
    NgbModule
  ]
})
export class CustomerModule { }
