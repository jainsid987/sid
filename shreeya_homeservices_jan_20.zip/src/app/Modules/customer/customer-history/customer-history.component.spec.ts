import { FooterComponent } from 'src/app/Shared/Components/footer/footer.component';
import { CustomCustomerHistory } from './../../../Shared/Models/CustomCustomerHistory';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CustomerService } from './../customer.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomerHistoryComponent } from './customer-history.component';
import { of } from '../../../../../node_modules/rxjs';

describe('CustomerHistoryComponent', () => {
 let component: CustomerHistoryComponent;
 let fixture: ComponentFixture<CustomerHistoryComponent>;
 let service: CustomerService;

 beforeEach(async(() => {
 TestBed.configureTestingModule({
 declarations: [ CustomerHistoryComponent, FooterComponent ],
 imports: [HttpClientTestingModule],
 providers: [CustomerService]
 })
 .compileComponents();
 service = TestBed.get(CustomerService);
 }));

 beforeEach(() => {
 fixture = TestBed.createComponent(CustomerHistoryComponent);
 component = fixture.componentInstance;
 fixture.detectChanges();
 });

 it('should create', () => {
 expect(component).toBeTruthy();
 });

 it('Customer History should receive a list', () => {
 // tslint:disable-next-line:max-line-length
 const dummy: CustomCustomerHistory[] = [{serviceName: 'Plumber', sericeDate: '28-04-2020', serviceTime: '5', serviceproviderName: 'Sidhant'}];
 spyOn(service, 'CustomerDetails').and.returnValue(of(dummy));
 component.ngOnInit();
 expect(component.customers).toEqual(dummy);
 });
});
