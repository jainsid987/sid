import { CustomCustomerHistory } from './../../../Shared/Models/CustomCustomerHistory';
import { CustomerService } from './../customer.service';
import { TbOrders } from './../../../Shared/Models/TbOrders';
import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { NgxSpinnerService } from "ngx-spinner";  
@Component({
  selector: 'app-customer-history',
  templateUrl: './customer-history.component.html',
  styleUrls: ['./customer-history.component.css']
})
export class CustomerHistoryComponent implements OnInit {
customers: CustomCustomerHistory[];
isListNull: boolean;
  constructor(private service: CustomerService, private SpinnerService: NgxSpinnerService) { }
  id = Number(localStorage.getItem('token'));
  ngOnInit() {
    this.SpinnerService.show(); 
    this.service.CustomerDetails(this.id).subscribe((data) => {
      this.customers = data;this.SpinnerService.hide()
    },
    error =>{
      this.isListNull = true;
      this.SpinnerService.hide();
    }
  
  ) ;
  }
    // var datePipe = new DatePipe();
    // this.setDob = datePipe.transform(userdate, 'dd/MM/yyyy');  
  }


