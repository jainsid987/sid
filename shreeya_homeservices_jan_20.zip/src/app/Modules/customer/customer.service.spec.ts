import { CustomEmail } from './../../Shared/Models/CustomEmail';
import { TestBed } from '@angular/core/testing';
import { CustomerService } from './customer.service';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {CustomTbAvailServices} from 'src/app/Shared/Models/CustomTbAvailServices';
import {environment } from 'src/environments/environment.dev';

describe('CustomerService', () => {
  let availService: CustomerService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
  TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [CustomerService],
  });

  availService = TestBed.get(CustomerService);
  httpMock = TestBed.get(HttpTestingController);
});

  it('should get service details', () => {
    // tslint:disable-next-line:max-line-length
    const dummy: CustomTbAvailServices[] = [{sno: 1, userId: 1, timings: '9am-12pm', price: 500, serviceId: 1, locationId: 1, rating: 5, providersName: 'sharan', locationName: 'bengaluru', serviceName: 'furniture', contactNo: '9901292427'}];

    availService.GetAvailableServices().subscribe(data => {
    expect(data.length).toBe(1);
    expect(data).toEqual(dummy);
  });

    const req2 = httpMock.expectOne( environment.postUrl + 'Service/GetAvailableServices');

    expect(req2.request.method).toBe('GET');
    req2.flush(dummy);

  });

  it('should create order', () => {
    // tslint:disable-next-line:max-line-length
    const dummy: CustomEmail = {consumerId: 1, serviceId: 2, dateofService: '28-04-2020', time: '5', serviceproviderId: 3, location: 'Bhubaneshwar', address: 'Bengaluru'};
    availService.AddCustomerAddress(dummy).subscribe((Response) => {
     expect(Response.serviceId).toEqual(2);
   });
    const req2 = httpMock.expectOne( environment.postUrl + 'Order/Email');
    expect(req2.request.method).toBe('POST');
    req2.flush(dummy);

   });
  });


