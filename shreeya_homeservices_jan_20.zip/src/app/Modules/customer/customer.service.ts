import { CustomEmail } from './../../Shared/Models/CustomEmail';
import { CustomCustomerHistory } from './../../Shared/Models/CustomCustomerHistory';
import { CustomTbAvailServices } from './../../Shared/Models/CustomTbAvailServices';
import { TbOrders } from './../../Shared/Models/TbOrders';
import { Injectable } from '@angular/core';
import {environment } from 'src/environments/environment.dev';
import {HttpClientModule, HttpClient} from '@angular/common/http';
import { Observable } from '../../../../node_modules/rxjs';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  serviceInfo: CustomTbAvailServices;
  selectedDate: any;

  [x: string]: any;
  hosturl: string;

  constructor(private http: HttpClient) {

    this.hosturl = environment.postUrl;
  //  this.ServiceDetails('snehal','2008-02-02');
  }
  public CustomerDetails(id: number) {
     return this.http.get<CustomCustomerHistory[]>( this.hosturl + 'Order?=' + id);
    // return this.http.get<CustomCustomerHistory[]>( 'https:localhost:44321/api/Order?='+id);
  }

  public GetAvailableServices() {
    // return this.http.get<CustomTbAvailServices[]>('https://localhost:44321/api/Service/GetAvailableServices');
    return this.http.get<CustomTbAvailServices[]>(this.hosturl + 'Service/GetAvailableServices');
  }

  ServiceDetails(service, date) {
    this.serviceInfo = service;
    this.selectedDate = date;
  }
  public AddCustomerAddress(customemail: CustomEmail) {
    // return this.http.post<CustomEmail>('https://localhost:44321/api/Order/Email', customemail);
    return this.http.post<CustomEmail>(this.hosturl + 'Order/Email', customemail);
  }
}
