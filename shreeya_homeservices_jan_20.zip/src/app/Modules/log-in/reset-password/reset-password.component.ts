import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validator, FormBuilder, Validators} from '@angular/forms';
import { LogInUserComponent } from 'src/app/Modules/log-in/log-in-user/log-in-user.component';
import { CustomerServiceService } from '../../../customer-service.service';
import { ResetPassword } from '../../../ResetPasswordCustomEntity';
import {MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HttpErrorResponse } from '../../../../../node_modules/@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {
private loginDiagRef: MatDialogRef<LogInUserComponent>;
flag: boolean;
flag1: boolean;
flag2: boolean;
flag3: boolean;
flag4: boolean;


  oldPassword: string;
  newPassword: string;
  confirmPassword: string;
  closeResult = '';
  msg: any;
  sucess: boolean;
  UpdateForm = new FormGroup({
    id: new FormControl(''),
    oldPassword : new FormControl(''),
    newPassword : new FormControl(''),
    confirmPassword: new FormControl('')
    });
constructor(private service: CustomerServiceService, private resetRef: MatDialogRef<ResetPasswordComponent>,
            private route: Router, private dialog: MatDialog) {
              this.resetRef.disableClose = true;
            }
reset = new ResetPassword();
  ngOnInit() {
  }
  StrongPassword(userPassword) {
    const testone = /[0-9]/;
    const testtwo = /[A-Z]/;
    const testthree =  /[a-z]/;
    if (testone.test(userPassword) && testtwo.test(userPassword) && testthree.test(userPassword)) {
      return true;
    }
    return false;
  }
  OnSubmit() {
    this.flag = false;
    this.flag1 = false;
    this.flag2 = false;
    this.flag3 = false;
    this.flag4 = false;
    this.oldPassword = this.UpdateForm.get('oldPassword').value;
    this.newPassword = this.UpdateForm.get('newPassword').value;
    this.confirmPassword = this.UpdateForm.get('confirmPassword').value;
    if (this.oldPassword === '' || this.newPassword === ''  || this.confirmPassword === '' ) {
    this.flag = true;
    // alert('All the Fields are Required');
  } else {
  if (this.newPassword.length < 8 || this.newPassword.length > 15 ) {
    this.flag1 = true;
    // alert('Password must contain minimum 8 and maximum 15 characters');
  } else {
  if (this.StrongPassword(this.newPassword)) {
  this.reset = this.UpdateForm.value;
  if (this.newPassword !==  this.confirmPassword) {
    this.flag2 = true;
    // alert('Confrim Password and New Password must be same');
  } else {
    this.reset.id = Number(localStorage.getItem('token'));
    this.reset = this.UpdateForm.value;
    this.service.update(this.reset).subscribe(
     res => {},
      (error: HttpErrorResponse) => {
        if (error.status === 200) {
          localStorage.clear();
          this.resetRef.close();
          alert('Password Reset Successfully Redirecting to Login Page');
          this.openLogInDialog();
     }  if (error.status === 400) {
       this.flag3 = true;
      // alert('Old Password is Incorrect');
}
      });
  }
} else {
  this.flag4 = true;
  // alert('Password must contain One capital letter,small letter and digit');
}
  }
}
  }
OnCancel() {
  this.resetRef.close();
}
openLogInDialog() {
  this.loginDiagRef = this.dialog.open(LogInUserComponent, {
    height: '500px',
    width: '350px',
  }
);
}
}
