import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ResetPasswordComponent } from './reset-password.component';
import { ReactiveFormsModule } from '../../../../../node_modules/@angular/forms';
import { HttpClientModule } from '../../../../../node_modules/@angular/common/http';
import { MatCardModule, MatInputModule, MatIconModule } from '../../../../../node_modules/@angular/material';
import { CustomerServiceService } from '../../../customer-service.service';
import {MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RouterTestingModule } from '../../../../../node_modules/@angular/router/testing';

describe('ResetPasswordComponent', () => {
 let component: ResetPasswordComponent;
 let fixture: ComponentFixture<ResetPasswordComponent>;

 beforeEach(async(() => {
 TestBed.configureTestingModule({
 declarations: [ ResetPasswordComponent ],
 imports: [ReactiveFormsModule, HttpClientModule, MatCardModule, MatInputModule, MatIconModule, MatDialogModule,
 RouterTestingModule.withRoutes([])],
 providers: [ CustomerServiceService, { provide: MatDialogRef, useValue: {} },
 { provide: MAT_DIALOG_DATA, useValue: [] }]
 })
 .compileComponents();
 }));

 beforeEach(() => {
 fixture = TestBed.createComponent(ResetPasswordComponent);
 component = fixture.componentInstance;
 fixture.detectChanges();
 });

 it('should create', () => {
 expect(component).toBeTruthy();
 });
});
