import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {environment } from 'src/environments/environment.dev';
import { ForgotPassword } from '../../Shared/Models/CustomForgotPassword';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ForgotPaswordService {
  hosturl: string;
  url: string;
    constructor(private http: HttpClient) {
      this.hosturl = environment.postUrl;
     }
   check(user: string): Observable<string> {
      // return this.http.get<string>('https://localhost:44321/api/Auth/CheckEmail?=' + user);
      return this.http.get<string>(this.hosturl + 'Auth/CheckEmail?=' + user);
  }
  SendEmail(user: string): Observable<number> {
    // return this.http.get<number>('https://localhost:44321/api/Auth/SendMail?=' + user);
    return this.http.get<number>(this.hosturl + 'Auth/SendMail?=' + user);
  }
  UpdatePassword(user: ForgotPassword) {
    // return this.http.put<ForgotPassword>('https://localhost:44321/api/Auth/UpdatePassword', user);
    return this.http.put<ForgotPassword>(this.hosturl + 'Auth/UpdatePassword', user);
  }
}
