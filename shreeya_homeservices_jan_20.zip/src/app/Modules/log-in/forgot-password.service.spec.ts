import { TestBed } from '@angular/core/testing';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import { ForgotPaswordService } from './forgot-password.service';
import { ForgotPassword } from '../../Shared/Models/CustomForgotPassword';
import {environment } from 'src/environments/environment.dev';

import {MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
describe('ForgotPasswordService', () => {
  let service: ForgotPaswordService;
  let httpMock: HttpTestingController;
  const email = 'jainsid987@gmail.com';
  const id =  20;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ForgotPaswordService]
    });
    service = TestBed.get(ForgotPaswordService);
    httpMock = TestBed.get(HttpTestingController);
  });
  it('should be created', () => {
    const user: ForgotPassword = { otp: 1234 , email: 'jainsid987@gmail.com', password: 'Siddhant@12', confirmPassword: 'Siddhant@12' };
    service.UpdatePassword(user).subscribe((Response) => {
      expect(Response.password).toEqual('Siddhant@12');
    });
    const req2 = httpMock.expectOne(service.hosturl + 'Auth/UpdatePassword');
    expect(req2.request.method).toBeTruthy('PUT');
    req2.flush(user);
  });
  it('Check', () => {
    service.check(email).subscribe(data => {
      expect(data.length).toBe(20);
      expect(data).toEqual(email);
     });
    const req2 = httpMock.expectOne(service.hosturl + 'Auth/CheckEmail?=' + email);
    expect(req2.request.method).toBeTruthy('GET');
    req2.flush(email);
  });
  it('Check SendEmail', () => {
    service.SendEmail(email).subscribe(data => {
      expect(data).toBe(20);
      expect(data).toEqual(id);
     });
    const req2 = httpMock.expectOne(service.hosturl + 'Auth/SendMail?=' + email);
    expect(req2.request.method).toBeTruthy('GET');
    req2.flush(id);
  });
});
