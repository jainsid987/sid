import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {HttpTestingController, HttpClientTestingModule} from '@angular/common/http/testing';
import { SignUpComponent } from './sign-up.component';
import { MatCardModule} from '@angular/material/card';
import {HttpClientModule} from '@angular/common/http';
import { LogInService } from 'src/app/Modules/log-in/log-in.service';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { HttpErrorResponse } from '../../../../../node_modules/@angular/common/http';
import { LogInUserComponent } from 'src/app/Modules/log-in/log-in-user/log-in-user.component';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { RouterTestingModule } from '../../../../../node_modules/@angular/router/testing';
import { TbUsers } from '../../../Shared/Models/TbUsers';
import { of } from '../../../../../node_modules/rxjs';
import { PostService } from '../../post/post.service';
describe('SignUpComponent', () => {
  let component: SignUpComponent;
  let fixture: ComponentFixture<SignUpComponent>;
  let signupservice: LogInService;
  const dialogMock = {
    close: () => { }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FormsModule,
        HttpClientTestingModule,
        HttpClientModule,
        MatDialogModule,
        MatCardModule,
        RouterTestingModule.withRoutes([]),
        ReactiveFormsModule ],
      declarations: [ SignUpComponent],
      providers: [{ provide: MatDialogRef, useValue: {} },
        { provide: MAT_DIALOG_DATA, useValue: [] },
        LogInService
      ]
    })
    .compileComponents();
    signupservice = TestBed.get(LogInService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SignUpComponent);
    component = fixture.componentInstance;
    signupservice = TestBed.get(LogInService);
    fixture.detectChanges();

    fit('should create', () => {
    expect(component).toBeTruthy();
  });

    fit('should return true for valid email format' , () => {
expect(component.EmailValidation('Satyam@gmail.com')).toBe(true);
});

    fit('it should return true for correct mobile number' , () => {
    expect(component.MobileNumberValidation('9876543210')).toBe(true);
});
    fit('it should return true when password and confirm password are same' , () => {
  expect(component.PasswordValidation('ASq11111', 'ASq11111')).toBe(true);

});
    fit('it should return true signupsuccessful' , () => {
  const tbusers: TbUsers = { userId: 0, userPassword: 'ASq11111',
 name: 'satyam', email: 'satyam@gmail.com', contactNo: '9876543210'};
  spyOn(signupservice , 'addDetail').and.returnValue(of(tbusers));
  component.onSubmit('ASq11111');
  expect(component.value).toEqual(tbusers);
  // expect(component.logInService.addDetail).toHaveBeenCalled();
});
});



});
