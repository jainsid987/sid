import { Component, OnInit } from '@angular/core';
import { TbUsers } from '../../../Shared/Models/TbUsers';
import { FormGroup, FormControl } from '@angular/forms';
import { LogInService } from 'src/app/Modules/log-in/log-in.service';
import {MatDialog, MatDialogRef } from '@angular/material/dialog';
import { HttpErrorResponse } from '../../../../../node_modules/@angular/common/http';
import { LogInUserComponent } from 'src/app/Modules/log-in/log-in-user/log-in-user.component';
@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  loginDiagRef: MatDialogRef<LogInUserComponent>;
  closeResult = '';
  signupForm: FormGroup;
  constructor(private logInService: LogInService, private signUpref: MatDialogRef<SignUpComponent>, private dialog: MatDialog) {
    this.signupForm = new FormGroup({
      userId: new FormControl('0'),
      name: new FormControl(''),
      userPassword: new FormControl(''),
      confirmpassword: new FormControl(''),
      email: new FormControl(''),
      contactNo: new FormControl('')
    });
    this.signUpref.disableClose = true;
  }
  flag: boolean; flag1: boolean; flag2: boolean; flag3: boolean;
  flag4: boolean; flag5: boolean; flag6: boolean;
value: TbUsers;
error = null;

  ngOnInit() {
  }
  onSubmit(confirmpassword: string) {
    this.flag = false; this.flag1 = false; this.flag2 = false; this.flag3 = false; this.flag4 = false; this.flag5 = false;
    this.flag6 = false;
    this.value = this.signupForm.value;
    if (this.value.name === '' || this.value.email === '' || this.value.contactNo === '') {
      this.flag6 = true;
      // alert('All the fields are required');
    } else {
      if (/^[a-zA-Z-,]+(\s{0,1}[a-zA-Z-, ])*$/.test(this.value.name) && this.value.name.length <= 30) {
    if (this.PasswordValidation(confirmpassword, this.value.userPassword)) {
    if (this.StrongPassword(this.value.userPassword)) {
    if (this.EmailValidation(this.value.email)) {
      if (this.MobileNumberValidation(this.value.contactNo)) {
      this.logInService.addDetail(this.value).subscribe(data => {
        alert('successfully signed up,go to login page');
        // this.openLogInDialog();
        // this.signupForm.reset();
        this.signUpref.close();
       },
      ((error: HttpErrorResponse) => {
        if (error.status === 400) {
          this.flag5 = true;
        }
      })
      );
    } else {
      this.flag4 = true;
      // alert('mobile number is not valid');
    }
  } else {
    this.flag3 = true;
    // alert ('Email is not valid');
  }
} else {
this.flag2 = true;
// alert('Password should consist of atleast one capital letteratleast
// one number and length should be minimum 8 and maximum 15 characters.');
}
} else {
  this.flag1 = true;
  // alert('Password and confirm password are not same');
  }
      } else {
        this.flag = true;
        // alert('Enter name as alphabet,no number, no character  and should be atmost 30 character');
      }
}
  }


    EmailValidation(Email: any) {
      const re = /\S+@\S+\.\S+/;
      return re.test(Email);
    }
    PasswordValidation(confirm, userPassword) {
      if (confirm === userPassword) {
        return true;
      } else {
        return false;
      }
    }
    StrongPassword(userPassword) {
      const testone = /[0-9]/;
      const testtwo = /[A-Z]/;
      const testthree = /[a-z]/;
      if (testone.test(userPassword) && testtwo.test(userPassword) && testthree.test(userPassword) &&
       this.value.userPassword.length >= 8 && this.value.userPassword.length <= 15) {
        return true;
      }
      return false;
    }
    OnCancel() {
      this.signUpref.close();
    }
  //   openLogInDialog() {
  //     this.signUpref.close();
  //     this.loginDiagRef = this.dialog.open(LogInUserComponent, {
  //       height: '500px',
  //       width: '350px',
  //     }
  //   );
  // }
    MobileNumberValidation(contactnumber) {
      const mobNumberPattern = /^((\\+91-?)|0)?[0-9]{10}$/;
      if (mobNumberPattern.test(contactnumber)) {
        return true;
      } else {
        return false;
      }
    }
  }
