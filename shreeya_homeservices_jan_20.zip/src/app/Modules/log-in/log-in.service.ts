import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { TbUsers } from '../../Shared/Models/TbUsers';
import { Observable } from '../../../../node_modules/rxjs';
import {environment } from 'src/environments/environment.dev';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class LogInService {
hosturl: string;
  constructor(private http: HttpClient, private router: Router) {
    this.hosturl = environment.postUrl;
    }
  // private url = 'https://localhost:44321/api/Auth';
  // private url1 = 'https://localhost:44321/api/User';
  logInUser(user) {
     return this.http.post<any>(this.hosturl + 'Auth', user);
    //  return this.http.post<any>(this.url, user);
    }

    LoggedIn() {
      return !!localStorage.getItem('token');
    }

    logOutUser() {
      localStorage.clear();
      this.router.navigate(['']);
    }
    addDetail(add: TbUsers) {
      return this.http.post<TbUsers>(this.hosturl + 'User', add);
    }
}
