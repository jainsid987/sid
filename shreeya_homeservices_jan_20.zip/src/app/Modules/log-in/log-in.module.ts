import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogInUserComponent } from './log-in-user/log-in-user.component';
import { SignUpComponent } from './sign-up/sign-up.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';



@NgModule({
  declarations: [LogInUserComponent, SignUpComponent, ResetPasswordComponent, ForgotPasswordComponent],
  imports: [
    CommonModule,
    AppRoutingModule
  ]
})
export class LogInModule { }
