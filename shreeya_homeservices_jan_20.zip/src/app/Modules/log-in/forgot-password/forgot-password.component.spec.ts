
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {MatIconModule} from '@angular/material';
import { ForgotPasswordComponent } from './forgot-password.component';
import { ReactiveFormsModule } from '../../../../../node_modules/@angular/forms';
import { HttpClient, HttpClientModule } from '../../../../../node_modules/@angular/common/http';
import { MatCard, MatCardModule, MatIcon, MatInputModule, MatDialogModule } from '../../../../../node_modules/@angular/material';
import { ForgotPaswordService } from '../forgot-password.service';
import {MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { of } from '../../../../../node_modules/rxjs';
describe('ForgotPasswordComponent', () => {
  let component: ForgotPasswordComponent;
  let fixture: ComponentFixture<ForgotPasswordComponent>;
  let service: ForgotPaswordService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ForgotPasswordComponent ],
      imports: [ReactiveFormsModule, HttpClientModule, MatCardModule, MatInputModule, MatIconModule, MatDialogModule],
      providers: [ForgotPaswordService, { provide: MatDialogRef, useValue: {} },
        { provide: MAT_DIALOG_DATA, useValue: [] }]
    })
    .compileComponents();
    service = TestBed.get(ForgotPaswordService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ForgotPasswordComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('Send Otp', () => {
    const OTP = 1234;
    spyOn(service , 'SendEmail').and.returnValue(of(OTP));
    component.SendOtp();
    expect(component.Otp).toEqual(OTP);
  });
});
