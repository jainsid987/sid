import { Component, OnInit, ɵSWITCH_RENDERER2_FACTORY__POST_R3__ } from '@angular/core';
import { FormControl, FormGroup, Validator, FormBuilder, Validators } from '@angular/forms';
import { ForgotPaswordService } from '../forgot-password.service';
import { HttpErrorResponse } from '../../../../../node_modules/@angular/common/http';
import { ForgotPassword } from './../../../Shared/Models/CustomForgotPassword';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { LogInUserComponent } from 'src/app/Modules/log-in/log-in-user/log-in-user.component';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
  hide = true;
  hide1 = true;
  Otp: number;
  email: string;
  oop: number;
  flag: boolean;
  flag1: boolean;
  same: boolean;
  length: boolean;
  mandatory: boolean;
  strong: boolean;
  IncorrectEmail: boolean;
  InvalidOtp: boolean;
  userPassword: string;
  confirmPaasword: string;
  reset = new ForgotPassword();
  UpdateForm = new FormGroup({
    email: new FormControl(''),
    otp: new FormControl('0'),
    password: new FormControl(''),
    confirmpassword: new FormControl(''),
  });
  VerifyForm = new FormGroup({
    otps: new FormControl(''),
  });
  constructor(private service: ForgotPaswordService, private forgotref: MatDialogRef<ForgotPasswordComponent>, private dialog: MatDialog) {
    this.forgotref.disableClose = true;
  }
  ngOnInit() {
  }
  StrongPassword(userPassword) {
    const testone = /[0-9]/;
    const testtwo = /[A-Z]/;
    const testthree = /[a-z]/;
    if (testone.test(userPassword) && testtwo.test(userPassword) && testthree.test(userPassword)) {
      return true;
    }
    return false;
  }
  ValidationOfEmail(): any {
    this.IncorrectEmail = false;
    this.reset.email = this.UpdateForm.get('email').value;
    this.service.check(this.reset.email).subscribe(
      res => { },
      (error: HttpErrorResponse) => {
        if (error.status === 200) {
          this.flag1 = true;
          this.SendOtp();
        }
        if (error.status === 400) {
          this.IncorrectEmail = true;
        }
      });
  }
  SendOtp(): any {
    this.email = this.UpdateForm.get('email').value;
    this.service.SendEmail(this.email).subscribe((data) => {
      this.Otp = data;
    });
  }
  ValidateOtp(): any {
    this.InvalidOtp = false;
    if (this.Otp === this.VerifyForm.get('otps').value) {
      this.flag = true;
    } else {
      this.InvalidOtp = true;
    }
  }
  password(): any {
    this.same = false;
    this.mandatory = false;
    this.length = false;
    this.strong = false;
    this.userPassword = this.UpdateForm.get('password').value;
    this.confirmPaasword = this.UpdateForm.get('confirmpassword').value;
    if (this.userPassword === '' || this.confirmPaasword === '') {
      this.mandatory = true;
    } else {
      if (this.userPassword.length < 8 || this.userPassword.length > 15) {
        this.length = true;
      } else {
        if (!this.StrongPassword(this.userPassword)) {
          this.strong = true;
        } else {
          if (this.userPassword === this.confirmPaasword) {
            this.reset.password = this.UpdateForm.get('password').value;
            this.reset.otp = this.Otp;
            this.reset.email = this.UpdateForm.get('email').value;
            this.reset.confirmPassword = this.UpdateForm.get('confirmpassword').value;
            this.service.UpdatePassword(this.reset).subscribe(
              res => { },
              (error: HttpErrorResponse) => {
                if (error.status === 200) {
                  alert('Password Updated Succesfully');
                  this.forgotref.close();
                }
                if (error.status === 400) {
                  alert('Password Not Updated');
                }
              });
          } else {
            this.same = true;
          }
        }
      }
    }
  }
  OnCancel() {
    this.forgotref.close();
  }
}
