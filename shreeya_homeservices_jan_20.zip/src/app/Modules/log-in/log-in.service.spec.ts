import { TestBed } from '@angular/core/testing';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import { LogInService } from './log-in.service';
import {TbUsers} from 'src/app/Shared/Models/TbUsers';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';

describe('LogInService', () => {

  let httpMock: HttpTestingController;
  let Service: LogInService;

  // tslint:disable-next-line:no-unused-expression


  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [LogInService]
    });

    Service = TestBed.get(LogInService);
    httpMock = TestBed.get(HttpTestingController);

  });


  it('should be created', () => {
    const services: LogInService = TestBed.get(LogInService);
    expect(services).toBeTruthy();
  });

  it('SignUp service testing' , () => {
    const user: TbUsers = {userId: 1,
      userPassword: 'satyam',
      name: 'string',
      email: 'xyz@gmail.com',
      contactNo: 'string'};
    Service.addDetail(user).subscribe((response) => {
        expect(response.email).not.toBe('abc@gmail.com');
      });
    const req2 = httpMock.expectOne(Service.hosturl + 'User');
    expect(req2.request.method).toBe('POST');
    req2.flush(user);
  });

  it('should check crendentials of user for logIn', () => {
const user: TbUsers = {  userId: 342,
  userPassword: 'Manisha@13',
  name: 'Manisha',
  email: 'manishajajra13@gmail',
  contactNo: '987654321'
};
const users: any = { userId: 342};
Service.logInUser(user).subscribe((Response) => {
  expect(Response).toEqual(users);
  });
const request2 = httpMock.expectOne(Service.hosturl + 'Auth', users);
expect(request2.request.method).toBe('POST');
request2.flush(users);
  });

  it('should check if user is loggedIn', () => {
    localStorage.setItem('token', '342');
    const flag: boolean = Service.LoggedIn();
    expect(flag).toBeTruthy();
  });


});
