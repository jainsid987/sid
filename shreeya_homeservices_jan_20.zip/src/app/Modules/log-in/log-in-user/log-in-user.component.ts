import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { TbUsers } from '../../../Shared/Models/TbUsers';
import { LogInService } from '../log-in.service';
import { Router } from '@angular/router';
import {MatDialog, MatDialogRef } from '@angular/material/dialog';
import {SignUpComponent} from 'src/app/Modules/log-in/sign-up/sign-up.component';
import {ForgotPasswordComponent} from 'src/app/Modules/log-in/forgot-password/forgot-password.component';

@Component({
  selector: 'app-log-in-user',
  templateUrl: './log-in-user.component.html',
  styleUrls: ['./log-in-user.component.css']
})
export class LogInUserComponent implements OnInit {
  hide = true;
  flag: boolean;
  flag1: boolean;
  singUpDiagRefe: MatDialogRef<SignUpComponent>;
  forgotDiagRefe: MatDialogRef<ForgotPasswordComponent>;
  user: TbUsers;
  loginForm = new FormGroup({
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  }) ;
  closeResult: string;

  LogInUserData = { };
  // tslint:disable-next-line:max-line-length
  constructor(private auth: LogInService, private route: Router, private dialogref: MatDialogRef<LogInUserComponent>, private dialog: MatDialog) {
    this.dialogref.disableClose = true;
   }

  ngOnInit() {
  }

  logInUser() {
    this.flag1 = false;
    this.flag = false;
    this.user = new TbUsers();
    // if (this.EmailValidation(this.user.email)) {
    this.user.email = this.loginForm.value.email;
    this.user.userPassword = this.loginForm.value.password;
    if (this.user.email === '' || this.user.userPassword === '' ) {
      this.flag1 = true;
      // alert('All the Fields are Required');
    } else {
    this.auth.logInUser(this.user).subscribe(
      res => {
         localStorage.setItem('token', res.userId);
         this.dialogref.close();
      },
      err => {
        console.log(err), this.flag = true;
      });
    // } else {
    //   this.flag = true;
    // }
    }
  }
    OnCancel() {
    this.dialogref.close();
}
  EmailValidation(Email: any) {
    const re = /\S+@\S+\.\S+/;
    return re.test(Email);
  }
  openSignInDialog() {
    this.dialogref.close();
    this.singUpDiagRefe = this.dialog.open(SignUpComponent, {
      height: '500px',
      width: '350px',
     }
  );
  }
  openForgotDialog() {
    this.dialogref.close();
    this.forgotDiagRefe = this.dialog.open(ForgotPasswordComponent, {
      height: '500px',
      width: '350px',
     }
  );
  }

  isSet() {
    return !!localStorage.getItem('sid');
  }
}
