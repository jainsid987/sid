import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '../../../../../node_modules/@angular/forms';
import { HttpClientTestingModule } from '../../../../../node_modules/@angular/common/http/testing';
import { RouterTestingModule } from '../../../../../node_modules/@angular/router/testing';
import {MatInputModule} from '@angular/material/input';
import { LogInUserComponent } from './log-in-user.component';
import { LogInService} from '../log-in.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatCardModule} from '@angular/material';
import {MatDialogModule } from '@angular/material/dialog';
import { of } from '../../../../../node_modules/rxjs';

describe('LogInUserComponent', () => {
  let component: LogInUserComponent;
  let fixture: ComponentFixture<LogInUserComponent>;
  let service: LogInService;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LogInUserComponent ],
      // tslint:disable-next-line:max-line-length
      imports: [ReactiveFormsModule, MatCardModule, MatDialogModule, MatInputModule, HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      providers: [ LogInService,
        { provide: MatDialogRef, useValue: {} },
        { provide: MAT_DIALOG_DATA, useValue: [] }]
    })
    .compileComponents();
    service = TestBed.get(LogInService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LogInUserComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('user should be able to logIn and session must be established for a user',  () => {
    const users: any = { userId: 342};
    spyOn(service, 'logInUser').and.returnValue(of(users));
    component.logInUser();
    expect(localStorage.getItem('token')).toBe('342');
  });
});
