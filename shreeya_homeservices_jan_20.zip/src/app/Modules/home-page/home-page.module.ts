import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home/home.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoggedInHomeComponent } from './logged-in-home/logged-in-home.component';
import { FooterComponent } from 'src/app/Shared/Components/footer/footer.component';
import { NavigationBarModule} from 'src/app/Shared/Components/navigation-bar/navigation-bar.module';
import { RouterModule} from '@angular/router';
import { AboutComponent } from './about/about.component';
@NgModule({
  declarations: [HomeComponent, LoggedInHomeComponent, FooterComponent, AboutComponent],
  imports: [
    CommonModule,
    NgbModule,
    NavigationBarModule,
    RouterModule
  ],

  exports: [HomeComponent, LoggedInHomeComponent, FooterComponent]
})
export class HomePageModule { }
