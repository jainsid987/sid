import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreatePostComponent } from './create-post/create-post.component';
import { ManagePostComponent } from './manage-post/manage-post.component';
import {ReactiveFormsModule} from '@angular/forms';
import {MatInputModule} from '@angular/material/input';
import { NavBarComponent } from 'src/app/Shared/Components/navigation-bar/nav-bar/nav-bar.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { FooterComponent } from 'src/app/Shared/Components/footer/footer.component';



@NgModule({
  declarations: [CreatePostComponent, ManagePostComponent, NavBarComponent, FooterComponent],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatInputModule,
    NgbModule,
  ],
  exports: [CreatePostComponent, ManagePostComponent, FooterComponent]
})
export class PostModule { }
