import { TestBed } from '@angular/core/testing';

import { PostService } from './post.service';
import {TbServiceProvider} from 'src/app/Shared/Models/TbServiceProvider';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import {environment } from 'src/environments/environment.dev';
import { CutomManagePost} from '../../CustomManagePost';
import { constants } from 'zlib';


describe('PostService', () => {
  let postService: PostService;
  let httpMock: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [PostService]
    });

    postService = TestBed.get(PostService);
    httpMock = TestBed.get(HttpTestingController);

  });

  it('should create service', () => {
    const add: TbServiceProvider = {sNo: 1, userId: 1, price: 200, timings: '9am-12pm', serviceId: 1, locationId: 1, rating: 5};
    postService.addService(add).subscribe((Response) => {
    expect(Response.price).toEqual(200);
  });

    const req2 = httpMock.expectOne( environment.postUrl + 'User/createpost');

    expect(req2.request.method).toBe('POST');
    req2.flush(add);

    });

  it(' should get list of posts created  by srvice providers', () => {
    const postTest: CutomManagePost[] = [
         {
          sNo: 1,
          userId: 342,
          timings: '9am-12pm',
          price: 600,
          serviceName: 'gasservice',
          location: 'bengaluru',
          rating: 5
         },
         {
          sNo: 2,
          userId: 342,
          timings: '12pm-6pm',
          price: 800,
          serviceName: 'gasservice',
          location: 'bengaluru',
          rating: 4
         }
        ];

    postService.GetPostList(342).subscribe((Response) => {
    expect(Response).toEqual(postTest);
    });
    const request = httpMock.expectOne(postService.hosturl + 'ManagePost/GetServiceProviders/' + 342);
    expect(request.request.method).toBe('GET');
    request.flush(postTest);
    });

  it(' should delete the post created  by service providers', () => {
      postService.DeletePost(10).subscribe();
      const request1 = httpMock.expectOne(postService.hosturl + 'ManagePost/DeleteProviderPost/' + 10);
      expect(request1.request.method).toBe('DELETE');
 });

  it('should update the post created  by service providers', () => {
    const postTest: CutomManagePost = { sNo: 1, userId: 342, timings: '9am-12pm', price: 600,
       serviceName: 'gasservice',
       location: 'bengaluru',
       rating: 5
      };
    const add: TbServiceProvider = {sNo: 1, userId: 342, price: 600, timings: '9am-12pm', serviceId: 1, locationId: 1, rating: 5};
    postService.updatePost(10, add).subscribe((Response) => {
    expect(Response).toEqual(postTest);
    });
    const request2 = httpMock.expectOne(postService.hosturl + 'ManagePost/UpdateProviderPost/' + 10);
    expect(request2.request.method).toBe('PUT');
    request2.flush(postTest);
});

  });
