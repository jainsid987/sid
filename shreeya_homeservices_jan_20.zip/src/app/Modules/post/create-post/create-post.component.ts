import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators} from '@angular/forms';
import { TbServiceProvider } from 'src/app/Shared/Models/TbServiceProvider';
import {PostService} from 'src/app/Modules/post/post.service';
import { HttpErrorResponse } from '../../../../../node_modules/@angular/common/http';


@Component({
  selector: 'app-create-post',
  templateUrl: './create-post.component.html',
  styleUrls: ['./create-post.component.css']
})

export class CreatePostComponent implements OnInit {
flag: boolean;

errorMessage: string;
  ServiceDetails = new TbServiceProvider();

  CreatePost = new FormGroup({
    serviceId: new FormControl('', Validators.required),
    locationId: new FormControl('', Validators.required),
    timings: new FormControl('', Validators.required),
    price: new FormControl('', Validators.required),
    });

    onSubmit() {
        this.ServiceDetails = this.CreatePost.value;
        if (this.ServiceDetails.price < 0 || this.ServiceDetails.price > 1000) {
          this.flag = true;
          this.errorMessage = 'Price cannot be less than 0 and greater than 1000';

          // alert('Price cannot be less than 0 and greater than 1000');
        } else {
          this.ServiceDetails.userId  =  Number(localStorage.getItem('token'));
          this.postService.addService(this.ServiceDetails).subscribe(data => {
            this.ServiceDetails = data;
          },
          ((error: HttpErrorResponse) => {
            if (error.status === 400) {
              // alert (error.error);
              this.flag = true;
              this.errorMessage = error.error;
            }
            if (error.status === 200) {
              alert (error.error.text);
              window.location.reload();
            }
          })
        );

      }
    }

  constructor(public postService: PostService) { }

  ngOnInit() {
  }

}
