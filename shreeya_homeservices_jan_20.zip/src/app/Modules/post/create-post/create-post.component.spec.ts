import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatePostComponent } from './create-post.component';
import { TbServiceProvider } from 'src/app/Shared/Models/TbServiceProvider';
import {PostService} from 'src/app/Modules/post/post.service';
import {MatInputModule} from '@angular/material/input';
import {ReactiveFormsModule} from '@angular/forms';
import { FooterComponent } from 'src/app/Shared/Components/footer/footer.component';
import {HttpClientTestingModule} from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpResponse } from '../../../../../node_modules/@angular/common/http';
import { of } from '../../../../../node_modules/rxjs/internal/observable/of';

describe('CreatePostComponent', () => {
  let component: CreatePostComponent;
  let fixture: ComponentFixture<CreatePostComponent>;
  let testPostService: PostService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreatePostComponent, FooterComponent ],

      imports: [MatInputModule, ReactiveFormsModule, HttpClientTestingModule, BrowserAnimationsModule],

      providers: [PostService]
    })
    .compileComponents();
    testPostService = TestBed.get(PostService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatePostComponent);
    component = fixture.componentInstance;
    testPostService = TestBed.get(PostService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('add service details', () => {
    // tslint:disable-next-line:max-line-length
    const tbServiceProvider: TbServiceProvider = {sNo: 1, userId: 1, serviceId: 1, locationId: 1, timings: '9am-12pm', rating: 3, price: 500};
    spyOn(testPostService, 'addService').and.returnValue(of(tbServiceProvider));

    // component.CreatePost.setValue(
    //   {
    //     serviceId: 1,
    //     locationId: 2,
    //     timings: '9am-10pm',
    //     price: 500
    //   }
    // );

    component.onSubmit();
    expect(component.ServiceDetails).toEqual(tbServiceProvider);
    expect(component.postService.addService).toHaveBeenCalled();

  });

});
