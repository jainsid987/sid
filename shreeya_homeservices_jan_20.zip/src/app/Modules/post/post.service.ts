import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { TbServiceProvider } from 'src/app/Shared/Models/TbServiceProvider';
import {environment } from 'src/environments/environment.dev';
import { CutomManagePost } from '../../CustomManagePost';

@Injectable({
  providedIn: 'root'
})
export class PostService {
hosturl: string;
constructor(private http: HttpClient ) {
  this.hosturl = environment.postUrl;
}
 // private url = 'https://localhost:44321/api/ManagePost/GetServiceProviders?id=136';
addService(service: TbServiceProvider) {
  return this.http.post<TbServiceProvider>( this.hosturl + 'User/createpost', service);
}

GetPostList(id) {
// return this.http.get<CutomManagePost[]>(this.hosturl + 'ManagePost/GetServiceProviders' + id);
// return this.http.get<CutomManagePost[]>('https://localhost:44321/api/ManagePost/GetServiceProviders/' + id);
return this.http.get<CutomManagePost[]>(this.hosturl + 'ManagePost/GetServiceProviders/' + id);
}

DeletePost(id) {
// return this.http.delete('https://localhost:44321/api/ManagePost/DeleteProviderPost/' + id);
return this.http.delete(this.hosturl + 'ManagePost/DeleteProviderPost/' + id);
}

updatePost(id, tbServiceProvider) {
// return this.http.put<CutomManagePost>('https://localhost:44321/api/ManagePost/UpdateProviderPost/' + id, tbServiceProvider);
return this.http.put<CutomManagePost>(this.hosturl + 'ManagePost/UpdateProviderPost/' + id, tbServiceProvider);
}

}
