import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ManagePostComponent } from './manage-post.component';
import { ReactiveFormsModule } from '../../../../../node_modules/@angular/forms';
import { HttpClientTestingModule } from '../../../../../node_modules/@angular/common/http/testing';
import { RouterTestingModule } from '../../../../../node_modules/@angular/router/testing';
import {MatInputModule} from '@angular/material/input';
import {PostService} from 'src/app/Modules/post/post.service';
import { CutomManagePost} from '../../../CustomManagePost';
import { of } from '../../../../../node_modules/rxjs';
import { TbServiceProvider } from '../../../Shared/Models/TbServiceProvider';
 
describe('ManagePostComponent', () => {
  let component: ManagePostComponent;
  let fixture: ComponentFixture<ManagePostComponent>;
  let testPostService: PostService;
  localStorage.setItem('token', '342');
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagePostComponent ],
      imports: [ReactiveFormsModule, MatInputModule, HttpClientTestingModule, RouterTestingModule.withRoutes([])],
      providers: [PostService]
    })
    .compileComponents();
    testPostService = TestBed.get(PostService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagePostComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });



  it('should create', () => {
  const posttest: CutomManagePost[] = [
     {
      sNo: 1,
      userId: 342,
      timings: '9am-12pm',
      price: 600,
      serviceName: 'gasservice',
      location: 'bengaluru',
      rating: 5
     },
     {
      sNo: 2,
      userId: 342,
      timings: '12pm-6pm',
      price: 800,
      serviceName: 'gasservice',
      location: 'bengaluru',
      rating: 4
     }
    ];
  localStorage.setItem('token', '342');
  spyOn(testPostService, 'GetPostList').and.returnValue(of(posttest));
  expect(component).toBeTruthy();

  });

  it('should get the list of posts created', () => {
    const postTest: CutomManagePost[] = [{ sNo: 1, userId: 342, timings: '9am-12pm', price: 600,
    serviceName: 'gasservice',
    location: 'bengaluru',
    rating: 5
   }];
    const add: TbServiceProvider = {sNo: 1, userId: 342, price: 600, timings: '9am-12pm', serviceId: 1, locationId: 1, rating: 5};
    localStorage.setItem('token' , '342');
    spyOn(testPostService, 'GetPostList').and.returnValue(of(postTest));
    component.loadList();
    expect(component.posts).toEqual(postTest);
  });


  it('should update post', () => {
    const sNo = 1;
    const postTest: CutomManagePost = { sNo: 1, userId: 342, timings: '9am-12pm', price: 600,
       serviceName: 'gasservice',
       location: 'bengaluru',
       rating: 5
      };
    const newpostTest: CutomManagePost[] = [{ sNo: 1, userId: 342, timings: '9am-12pm', price: 600,
       serviceName: 'gasservice',
       location: 'bengaluru',
       rating: 5
      }];
    spyOn(testPostService, 'updatePost').and.returnValue(of(postTest));
    spyOn(component, 'loadList');
    component.updatePost(sNo);
    expect(component.loadList).toHaveBeenCalled();
  });

});
