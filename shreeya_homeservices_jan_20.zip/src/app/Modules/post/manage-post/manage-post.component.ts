import { isEmpty } from 'rxjs/internal/operators';
import { Component, OnInit } from '@angular/core';
import { PostService } from '../post.service';
import { CutomManagePost } from '../../../CustomManagePost';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { TbServiceProvider } from '../../../Shared/Models/TbServiceProvider';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-manage-post',
  templateUrl: './manage-post.component.html',
  styleUrls: ['./manage-post.component.css']
})
export class ManagePostComponent implements OnInit {
  flag: boolean;
posts: CutomManagePost[];
id: number;
serviceId: number;
locationId: number;
closeResult: string;
newPost: TbServiceProvider;
isListNull: boolean;
updatePostForm = new FormGroup({
  sNo: new FormControl(''),
  serviceId: new FormControl('', Validators.required),
  locationId: new FormControl('', Validators.required),
  timings: new FormControl('', Validators.required),
  price: new FormControl('', Validators.required),
  });

  constructor(private service: PostService, private modalService: NgbModal, private SpinnerService: NgxSpinnerService) { }

  ngOnInit() {

    this.loadList();

  }


loadList() {
// this.id = Number(localStorage.getItem('token'));
this.SpinnerService.show();
this.id = Number(localStorage.getItem('token'));
this.service.GetPostList(this.id).subscribe(u => {
    this.posts = u;
    this.SpinnerService.hide();
  },
  error => {
    this.isListNull = true;
    this.SpinnerService.hide();
  }

) ;
}



deletePost(sNo) {
this.service.DeletePost(sNo).subscribe((data) => {
  window.location.reload();
});

}

open(content, post) {
  this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  });
  if (post.service === 'Gas') {
this.serviceId = 2;
   } else if (post.service === 'Furniture') {
    this.serviceId = 1;
   } else if (post.service === 'Plumber') {
    this.serviceId = 3;
   }

  if (post.location === 'Bhubaneshwar') {
    this.locationId = 1;
       } else if (post.location === 'Bengaluru') {
        this.locationId = 2;
       } else if (post.location === 'Hyderabad') {
        this.locationId = 3;
       }

  this.updatePostForm.patchValue({
  sNo: post.sNo,
  timings: post.timings,
  price: post.price,
  serviceId: this.serviceId,
  locationId: this.locationId
  });
}

private getDismissReason(reason: any): string {
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on a backdrop';
  } else {
    return  `with: ${reason}`;
  }
}

updatePost(sNo: number) {
this.newPost = this.updatePostForm.value;
if (this.newPost.price < 0 || this.newPost.price > 1000) {
  this.flag = true;
} else {
this.service.updatePost(sNo, this.newPost).subscribe((data) => {
  this.loadList();
});
this.modalService.dismissAll();
}
}

}
