import { CustomerDetailComponent } from './Modules/customer/customer-detail/customer-detail.component';
import { CustomerHistoryComponent } from './Modules/customer/customer-history/customer-history.component';
import { CreatePostComponent } from './Modules/post/create-post/create-post.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './auth.guard';
import { LogInService } from './Modules/log-in/log-in.service';
import { SignUpComponent} from '../app/Modules/log-in/sign-up/sign-up.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {NgbPaginationModule, NgbAlertModule} from '@ng-bootstrap/ng-bootstrap';
import { ManagePostComponent } from '../app/Modules/post/manage-post/manage-post.component';
import { ServiceListComponent } from '../app/Modules/customer/avail-services/service-list/service-list.component';

import { HomePageModule } from 'src/app/Modules/home-page/home-page.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule } from '../../node_modules/@angular/forms';
import {MatInputModule} from '@angular/material/input';
import {NavigationBarModule} from 'src/app/Shared/Components/navigation-bar/navigation-bar.module';
// import { LogInModule } from './Modules/log-in/log-in.module';
import {ResetPasswordComponent} from 'src/app/Modules/log-in/reset-password/reset-password.component';
import {HttpClientModule } from '@angular/common/http';
import { LogInUserComponent } from 'src/app/Modules/log-in/log-in-user/log-in-user.component';


import {MatDialogModule} from '@angular/material/dialog';
import {MatCardModule} from '@angular/material/card';
import {MatCheckboxModule} from '@angular/material/checkbox';
import {MatSliderModule} from '@angular/material/slider';
import {MatSelectModule} from '@angular/material/select';
import {MatSidenavModule} from '@angular/material/sidenav';
import {MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule, MatFormFieldModule, MatIconModule} from '@angular/material';
import { NgxSpinnerModule } from "ngx-spinner";  
import { ProviderListComponent } from 'src/app/Modules/customer/avail-services/provider-list/provider-list.component';
import { FiltersComponent} from 'src/app/Modules/customer/avail-services/filters/filters.component';
import { DatePipe } from '@angular/common';
import { ForgotPasswordComponent } from './Modules/log-in/forgot-password/forgot-password.component';

@NgModule({
  declarations: [
    AppComponent,
    CustomerHistoryComponent,
    ResetPasswordComponent,
    LogInUserComponent,
    SignUpComponent,
    CreatePostComponent,
    ManagePostComponent,
    ProviderListComponent,
    FiltersComponent,
    ForgotPasswordComponent,
    CustomerDetailComponent,
    ServiceListComponent
      ],

  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    NgbPaginationModule,
    NgbAlertModule,
    HomePageModule,
    BrowserAnimationsModule,
    ReactiveFormsModule,
    MatInputModule,
    HttpClientModule,
    ReactiveFormsModule,
    NavigationBarModule,
    MatDialogModule,
    MatCardModule,
    MatCheckboxModule,
    MatSliderModule,
    MatSelectModule,
    MatSidenavModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatIconModule,
    NgxSpinnerModule  
],
  providers: [AuthGuard, LogInService, DatePipe],
  bootstrap: [AppComponent],
  entryComponents: [ ForgotPasswordComponent ]
})
export class AppModule { }
