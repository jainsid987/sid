export class CutomManagePost {
sNo: number;
userId: number;
timings: string;
price: number;
serviceName: string;
location: string;
rating: number;
}
