import { TestBed } from '@angular/core/testing';
import { ResetPassword } from './ResetPasswordCustomEntity';
import {HttpClientTestingModule, HttpTestingController} from '@angular/common/http/testing';
import { CustomerServiceService } from './customer-service.service';

describe('CustomerServiceService' , () => {
  let service: CustomerServiceService;
  let httpMock: HttpTestingController;
  beforeEach(()  => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [CustomerServiceService]
    });
    service = TestBed.get(CustomerServiceService);
    httpMock = TestBed.get(HttpTestingController);
  });
  it('update password'  , () => {
    const user: ResetPassword = {id: 1, oldPassword: 'siddhant', newPassword: 'siddhant@1', confirmPassword: 'siddhant@1'};
    service.update(user).subscribe((response) =>  {
       expect(response.oldPassword).toEqual('siddhant');
     });
    const req2 = httpMock.expectOne(service.hosturl + 'User/ResetPassword');
    expect(req2.request.method).toBe('PUT');
    req2.flush(user);
  });
});
