import { Injectable } from '@angular/core';
import { ResetPassword } from './ResetPasswordCustomEntity';
import {HttpClient} from '@angular/common/http';
import {environment } from 'src/environments/environment.dev';


@Injectable({
  providedIn: 'root'
})
export class CustomerServiceService {
hosturl: string;
  constructor(private http: HttpClient) {
    this.hosturl = environment.postUrl;
   }
update(user: ResetPassword) {
  return this.http.put<ResetPassword>( this.hosturl + 'User/ResetPassword', user );
  }
}
